/** @author YellowAfterlife */
var __fish = ["2303:uch:f","2299:*:s","2290:*:*","2436:ch:*","2317:uch:h","2305:*:b","2304:s:f"];