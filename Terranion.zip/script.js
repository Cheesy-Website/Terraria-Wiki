(function ($global) { "use strict";
var $estr = function() { return js_Boot.__string_rec(this,''); },$hxEnums = $hxEnums || {},$_;
function $extend(from, fields) {
	var proto = Object.create(from);
	for (var name in fields) proto[name] = fields[name];
	if( fields.toString !== Object.prototype.toString ) proto.toString = fields.toString;
	return proto;
}
var HxOverrides = function() { };
HxOverrides.__name__ = true;
HxOverrides.cca = function(s,index) {
	var x = s.charCodeAt(index);
	if(x != x) {
		return undefined;
	}
	return x;
};
HxOverrides.substr = function(s,pos,len) {
	if(len == null) {
		len = s.length;
	} else if(len < 0) {
		if(pos == 0) {
			len = s.length + len;
		} else {
			return "";
		}
	}
	return s.substr(pos,len);
};
HxOverrides.now = function() {
	return Date.now();
};
var Lang = function() { };
Lang.__name__ = true;
Lang.iloc = function(cat,key,en) {
	return en;
};
Math.__name__ = true;
var Reflect = function() { };
Reflect.__name__ = true;
Reflect.field = function(o,field) {
	try {
		return o[field];
	} catch( _g ) {
		return null;
	}
};
var Std = function() { };
Std.__name__ = true;
Std.string = function(s) {
	return js_Boot.__string_rec(s,"");
};
Std.parseInt = function(x) {
	if(x != null) {
		var _g = 0;
		var _g1 = x.length;
		while(_g < _g1) {
			var i = _g++;
			var c = x.charCodeAt(i);
			if(c <= 8 || c >= 14 && c != 32 && c != 45) {
				var nc = x.charCodeAt(i + 1);
				var v = parseInt(x,nc == 120 || nc == 88 ? 16 : 10);
				if(isNaN(v)) {
					return null;
				} else {
					return v;
				}
			}
		}
	}
	return null;
};
var StringTools = function() { };
StringTools.__name__ = true;
StringTools.startsWith = function(s,start) {
	if(s.length >= start.length) {
		return s.lastIndexOf(start,0) == 0;
	} else {
		return false;
	}
};
StringTools.isSpace = function(s,pos) {
	var c = HxOverrides.cca(s,pos);
	if(!(c > 8 && c < 14)) {
		return c == 32;
	} else {
		return true;
	}
};
StringTools.ltrim = function(s) {
	var l = s.length;
	var r = 0;
	while(r < l && StringTools.isSpace(s,r)) ++r;
	if(r > 0) {
		return HxOverrides.substr(s,r,l - r);
	} else {
		return s;
	}
};
StringTools.rtrim = function(s) {
	var l = s.length;
	var r = 0;
	while(r < l && StringTools.isSpace(s,l - r - 1)) ++r;
	if(r > 0) {
		return HxOverrides.substr(s,0,l - r);
	} else {
		return s;
	}
};
StringTools.trim = function(s) {
	return StringTools.ltrim(StringTools.rtrim(s));
};
StringTools.replace = function(s,sub,by) {
	return s.split(sub).join(by);
};
var haxe_ds_IntMap = function() {
	this.h = { };
};
haxe_ds_IntMap.__name__ = true;
haxe_ds_IntMap.prototype = {
	keys: function() {
		var a = [];
		for( var key in this.h ) if(this.h.hasOwnProperty(key)) a.push(key | 0);
		return new haxe_iterators_ArrayIterator(a);
	}
	,__class__: haxe_ds_IntMap
};
var haxe_ds_StringMap = function() {
	this.h = Object.create(null);
};
haxe_ds_StringMap.__name__ = true;
haxe_ds_StringMap.prototype = {
	__class__: haxe_ds_StringMap
};
var haxe_iterators_ArrayIterator = function(array) {
	this.current = 0;
	this.array = array;
};
haxe_iterators_ArrayIterator.__name__ = true;
haxe_iterators_ArrayIterator.prototype = {
	hasNext: function() {
		return this.current < this.array.length;
	}
	,next: function() {
		return this.array[this.current++];
	}
	,__class__: haxe_iterators_ArrayIterator
};
var js_Boot = function() { };
js_Boot.__name__ = true;
js_Boot.getClass = function(o) {
	if(o == null) {
		return null;
	} else if(((o) instanceof Array)) {
		return Array;
	} else {
		var cl = o.__class__;
		if(cl != null) {
			return cl;
		}
		var name = js_Boot.__nativeClassName(o);
		if(name != null) {
			return js_Boot.__resolveNativeClass(name);
		}
		return null;
	}
};
js_Boot.__string_rec = function(o,s) {
	if(o == null) {
		return "null";
	}
	if(s.length >= 5) {
		return "<...>";
	}
	var t = typeof(o);
	if(t == "function" && (o.__name__ || o.__ename__)) {
		t = "object";
	}
	switch(t) {
	case "function":
		return "<function>";
	case "object":
		if(o.__enum__) {
			var e = $hxEnums[o.__enum__];
			var con = e.__constructs__[o._hx_index];
			var n = con._hx_name;
			if(con.__params__) {
				s = s + "\t";
				return n + "(" + ((function($this) {
					var $r;
					var _g = [];
					{
						var _g1 = 0;
						var _g2 = con.__params__;
						while(true) {
							if(!(_g1 < _g2.length)) {
								break;
							}
							var p = _g2[_g1];
							_g1 = _g1 + 1;
							_g.push(js_Boot.__string_rec(o[p],s));
						}
					}
					$r = _g;
					return $r;
				}(this))).join(",") + ")";
			} else {
				return n;
			}
		}
		if(((o) instanceof Array)) {
			var str = "[";
			s += "\t";
			var _g = 0;
			var _g1 = o.length;
			while(_g < _g1) {
				var i = _g++;
				str += (i > 0 ? "," : "") + js_Boot.__string_rec(o[i],s);
			}
			str += "]";
			return str;
		}
		var tostr;
		try {
			tostr = o.toString;
		} catch( _g ) {
			return "???";
		}
		if(tostr != null && tostr != Object.toString && typeof(tostr) == "function") {
			var s2 = o.toString();
			if(s2 != "[object Object]") {
				return s2;
			}
		}
		var str = "{\n";
		s += "\t";
		var hasp = o.hasOwnProperty != null;
		var k = null;
		for( k in o ) {
		if(hasp && !o.hasOwnProperty(k)) {
			continue;
		}
		if(k == "prototype" || k == "__class__" || k == "__super__" || k == "__interfaces__" || k == "__properties__") {
			continue;
		}
		if(str.length != 2) {
			str += ", \n";
		}
		str += s + k + " : " + js_Boot.__string_rec(o[k],s);
		}
		s = s.substring(1);
		str += "\n" + s + "}";
		return str;
	case "string":
		return o;
	default:
		return String(o);
	}
};
js_Boot.__nativeClassName = function(o) {
	var name = js_Boot.__toStr.call(o).slice(8,-1);
	if(name == "Object" || name == "Function" || name == "Math" || name == "JSON") {
		return null;
	}
	return name;
};
js_Boot.__resolveNativeClass = function(name) {
	return $global[name];
};
var terra_DataAI = function() { };
terra_DataAI.__name__ = true;
var terra_Item = function() {
	this.id = 0;
	this.name = "";
};
terra_Item.__name__ = true;
terra_Item.fromId = function(id) {
	var r = terra_Item.idMap.h[id];
	if(r == null) {
		r = new terra_Item();
		r.name = "Unknown";
		r.id = id;
		terra_Item.idMap.h[id] = r;
	}
	return r;
};
terra_Item.prototype = {
	__class__: terra_Item
};
var terra_ItemMeta = function(item) {
	this.lines = [];
	this.item = item;
};
terra_ItemMeta.__name__ = true;
terra_ItemMeta.parse = function(item,source,wiki) {
	var pairs = source.split("|");
	var m = new terra_ItemMeta(item);
	var t = pairs.shift();
	if(t.indexOf("t") >= 0) {
		m.add(terra_ItemMetaLine.Tile);
	}
	if(t.indexOf("w") >= 0) {
		m.add(terra_ItemMetaLine.Wall);
	}
	if(t.indexOf("4") >= 0) {
		m.add(terra_ItemMetaLine.Helmet);
	}
	if(t.indexOf("5") >= 0) {
		m.add(terra_ItemMetaLine.Shirt);
	}
	if(t.indexOf("6") >= 0) {
		m.add(terra_ItemMetaLine.Pants);
	}
	if(t.indexOf("a") >= 0) {
		m.add(terra_ItemMetaLine.Accessory);
	}
	if(t.indexOf("1") >= 0) {
		m.stack = 1;
	}
	if(t.indexOf("H") >= 0) {
		m.stack = 99;
	}
	if(t.indexOf("K") >= 0) {
		m.stack = 999;
	}
	var tip = null;
	var crit = 4;
	var value = 0;
	var _g = 0;
	while(_g < pairs.length) {
		var pair = pairs[_g];
		++_g;
		var p = pair.indexOf("=");
		var v = HxOverrides.substr(pair,p + 1,null);
		switch(HxOverrides.substr(pair,0,p)) {
		case "1":case "2":case "3":case "4":case "5":
			if(tip != null) {
				tip += "\n" + v;
			} else {
				tip = v;
			}
			break;
		case "D":
			m.add(terra_ItemMetaLine.Defense(Std.parseInt(v)));
			break;
		case "c":
			crit += Std.parseInt(v);
			break;
		case "d":
			var dmg = Std.parseInt(v);
			var dps = null;
			if(source.indexOf("|t=") >= 0) {
				var _g1 = 0;
				while(_g1 < pairs.length) {
					var pair2 = pairs[_g1];
					++_g1;
					if(StringTools.startsWith(pair2,"t=")) {
						var t1 = Std.parseInt(pair2.substring(2));
						if(t1 != null && t1 > 0) {
							dps = Math.round(dmg * 60 / t1);
						}
						break;
					}
				}
			}
			if(t.indexOf("d") >= 0) {
				m.add(terra_ItemMetaLine.MeleeDamage(dmg,dps));
			}
			if(t.indexOf("r") >= 0) {
				m.add(terra_ItemMetaLine.RangedDamage(dmg,dps));
			}
			if(t.indexOf("m") >= 0) {
				m.add(terra_ItemMetaLine.MagicDamage(dmg,dps));
			}
			if(t.indexOf("s") >= 0) {
				m.add(terra_ItemMetaLine.SummonDamage(dmg,dps));
			} else {
				m.add(terra_ItemMetaLine.Crit(crit));
			}
			break;
		case "hl":
			m.add(terra_ItemMetaLine.RestoresLife(Std.parseInt(v)));
			break;
		case "hm":
			m.add(terra_ItemMetaLine.RestoresMana(Std.parseInt(v)));
			break;
		case "k":
			m.add(terra_ItemMetaLine.Knockback(parseFloat(v)));
			break;
		case "m":
			m.add(terra_ItemMetaLine.ManaCost(Std.parseInt(v)));
			break;
		case "rg":
			m.add(terra_ItemMetaLine.ResearchGoal(Std.parseInt(v)));
			break;
		case "s":
			m.stack = Std.parseInt(v);
			break;
		case "t":
			var t2 = Std.parseInt(v);
			var ps = t2 > 0 ? "" + (6000 / t2 | 0) / 100 : null;
			m.add(terra_ItemMetaLine.UseTime(t2,ps));
			break;
		case "tf":
			m.add(terra_ItemMetaLine.FishingPower(Std.parseInt(v)));
			break;
		case "th":
			m.add(terra_ItemMetaLine.HammerPower(Std.parseInt(v)));
			break;
		case "tp":
			m.add(terra_ItemMetaLine.PickaxePower(Std.parseInt(v)));
			break;
		case "tr":
			m.add(terra_ItemMetaLine.RangeDelta(Std.parseInt(v)));
			break;
		case "tx":
			m.add(terra_ItemMetaLine.AxePower(Std.parseInt(v) * 5));
			break;
		case "z":
			value = Std.parseInt(v);
			break;
		}
	}
	if(t.indexOf("c") >= 0) {
		m.add(terra_ItemMetaLine.Consumable);
	}
	if(t.indexOf("v") >= 0) {
		m.add(terra_ItemMetaLine.Vanity);
	}
	if(t.indexOf("b") >= 0) {
		m.add(terra_ItemMetaLine.Ammo);
	}
	if(t.indexOf("x") >= 0) {
		m.add(terra_ItemMetaLine.Material);
	}
	if(tip != null) {
		m.add(terra_ItemMetaLine.EnText(tip));
	}
	if(m.stack > 1 && wiki) {
		m.add(terra_ItemMetaLine.MaxStack(m.stack));
	}
	if(wiki && value > 0) {
		var v = "";
		var i = value / 5 | 0;
		if(i > 0) {
			if(i % 100 != 0) {
				v = "[$c]" + i % 100 + " " + v;
			}
			i = i / 100 | 0;
			if(i > 0) {
				if(i % 100 != 0) {
					v = "[$s]" + i % 100 + " " + v;
				}
				i = i / 100 | 0;
				if(i > 0) {
					if(i % 100 != 0) {
						v = "[$g]" + i % 100 + " " + v;
					}
					i = i / 100 | 0;
					if(i > 0) {
						v = "[$p]" + i + " " + v;
					}
				}
			}
		}
		m.add(terra_ItemMetaLine.Worth(HxOverrides.substr(v,0,v.length - 1)));
	}
	return m;
};
terra_ItemMeta.prototype = {
	toString: function() {
		var r = [];
		var cat = "meta.item";
		var add = function(key,en) {
			r.push(en);
		};
		var add1 = function(key,en,v1) {
			var v = StringTools.replace(en,"$1",Std.string(v1));
			r.push(v);
		};
		var add2 = function(key,en,v1,v2) {
			var v = en;
			v = StringTools.replace(v,"$1",Std.string(v1));
			v = StringTools.replace(v,"$2",Std.string(v2));
			r.push(v);
		};
		var addDmg = function(key,en,dmg,dps) {
			var v = StringTools.replace(en,"$1","" + dmg);
			if(dps != null) {
				v += StringTools.replace(" (~$1 DPS)","$1","" + dps);
			}
			r.push(v);
		};
		var _g = 0;
		var _g1 = this.lines;
		while(_g < _g1.length) {
			var m = _g1[_g];
			++_g;
			switch(m._hx_index) {
			case 0:
				add("isTile","Can be placed (tile)");
				break;
			case 1:
				add("isWall","Can be placed (wall)");
				break;
			case 2:
				add("isHelmet","Equipable (head slot)");
				break;
			case 3:
				add("isShirt","Equipable (body slot)");
				break;
			case 4:
				add("isPants","Equipable (legs slot)");
				break;
			case 5:
				add("isAccessory","Equipable (accessory)");
				break;
			case 6:
				var amt = m.amt;
				var dps = m.dps;
				addDmg("meleeDamage","$1 melee damage",amt,dps);
				break;
			case 7:
				var amt1 = m.amt;
				var dps1 = m.dps;
				addDmg("rangedDamage","$1 ranged damage",amt1,dps1);
				break;
			case 8:
				var amt2 = m.amt;
				var dps2 = m.dps;
				addDmg("magicDamage","$1 magic damage",amt2,dps2);
				break;
			case 9:
				var amt3 = m.amt;
				var dps3 = m.dps;
				addDmg("summonDamage","$1 summon damage",amt3,dps3);
				break;
			case 10:
				var c = m.chance;
				add1("critChance","$1% critical strike chance","" + c);
				break;
			case 11:
				var v = m.def;
				add1("defense","$1 defense",v);
				break;
			case 12:
				var v1 = m.v;
				add1("pickaxePower","$1% pickaxe power",v1);
				break;
			case 13:
				var v2 = m.v;
				add1("axePower","$1% axe power",v2);
				break;
			case 14:
				var v3 = m.v;
				add1("hammerPower","$1% hammer power",v3);
				break;
			case 15:
				var v4 = m.v;
				add1("rangeDelta","$1 range",v4 < 0 ? "" + v4 : "+" + v4);
				break;
			case 16:
				var v5 = m.v;
				add1("fishingPower","$1% fishing power",v5);
				break;
			case 17:
				var v6 = m.amt;
				add1("restoresLife","Restores $1 life",v6);
				break;
			case 18:
				var v7 = m.amt;
				add1("restoresMana","Restores $1 mana",v7);
				break;
			case 19:
				var t = m.t;
				var ps = m.perSecond;
				var s = StringTools.replace("Use time $1","$1","" + t);
				if(ps != null) {
					var s1 = " ($1/s, $2)";
					var c1;
					if(t <= 8) {
						c1 = "insanely fast";
					} else if(t <= 20) {
						c1 = "very fast";
					} else if(t <= 25) {
						c1 = "fast";
					} else if(t <= 30) {
						c1 = "average";
					} else if(t <= 35) {
						c1 = "slow";
					} else if(t <= 45) {
						c1 = "very slow";
					} else if(t <= 55) {
						c1 = "extremely slow";
					} else {
						c1 = "insanely slow";
					}
					s += StringTools.replace(StringTools.replace(s1,"$1",ps),"$2",c1);
				}
				r.push(s);
				break;
			case 20:
				var k = m.amt;
				var s2 = "Knockback $1 ($2)";
				var c2;
				if(k <= 1.5) {
					c2 = "extremely weak";
				} else if(k <= 3) {
					c2 = "very weak";
				} else if(k <= 4) {
					c2 = "weak";
				} else if(k <= 6) {
					c2 = "average";
				} else if(k <= 7) {
					c2 = "strong";
				} else if(k <= 9) {
					c2 = "very strong";
				} else if(k <= 11) {
					c2 = "extremely strong";
				} else {
					c2 = "insane";
				}
				r.push(StringTools.replace(StringTools.replace(s2,"$1","" + k),"$2",c2));
				break;
			case 21:
				var n = m.amt;
				add1("manaCost","Uses $1 mana",n);
				break;
			case 22:
				add("isConsumable","Consumable");
				break;
			case 23:
				add("isVanity","Vanity item");
				break;
			case 24:
				add("isAmmo","Ammo");
				break;
			case 25:
				add("isMaterial","Material");
				break;
			case 26:
				var en = m.s;
				var s3 = en;
				if(this.item.pid != null) {
					s3 = Lang.iloc("ItemTooltip",this.item.pid,en);
				}
				r.push(s3);
				break;
			case 27:
				var n1 = m.n;
				add1("maxStack","Max stack $1",n1);
				break;
			case 28:
				var s4 = m.s;
				add1("worth","Worth $1",s4);
				break;
			case 29:
				var n2 = m.n;
				add1("researchGoal","Takes $1 to research in Journey Mode",n2);
				break;
			}
		}
		return r.join("\n");
	}
	,add: function(ml) {
		this.lines.push(ml);
	}
	,__class__: terra_ItemMeta
};
var terra_ItemMetaLine = $hxEnums["terra.ItemMetaLine"] = { __ename__:true,__constructs__:null
	,Tile: {_hx_name:"Tile",_hx_index:0,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Wall: {_hx_name:"Wall",_hx_index:1,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Helmet: {_hx_name:"Helmet",_hx_index:2,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Shirt: {_hx_name:"Shirt",_hx_index:3,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Pants: {_hx_name:"Pants",_hx_index:4,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Accessory: {_hx_name:"Accessory",_hx_index:5,__enum__:"terra.ItemMetaLine",toString:$estr}
	,MeleeDamage: ($_=function(amt,dps) { return {_hx_index:6,amt:amt,dps:dps,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="MeleeDamage",$_.__params__ = ["amt","dps"],$_)
	,RangedDamage: ($_=function(amt,dps) { return {_hx_index:7,amt:amt,dps:dps,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="RangedDamage",$_.__params__ = ["amt","dps"],$_)
	,MagicDamage: ($_=function(amt,dps) { return {_hx_index:8,amt:amt,dps:dps,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="MagicDamage",$_.__params__ = ["amt","dps"],$_)
	,SummonDamage: ($_=function(amt,dps) { return {_hx_index:9,amt:amt,dps:dps,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="SummonDamage",$_.__params__ = ["amt","dps"],$_)
	,Crit: ($_=function(chance) { return {_hx_index:10,chance:chance,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="Crit",$_.__params__ = ["chance"],$_)
	,Defense: ($_=function(def) { return {_hx_index:11,def:def,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="Defense",$_.__params__ = ["def"],$_)
	,PickaxePower: ($_=function(v) { return {_hx_index:12,v:v,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="PickaxePower",$_.__params__ = ["v"],$_)
	,AxePower: ($_=function(v) { return {_hx_index:13,v:v,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="AxePower",$_.__params__ = ["v"],$_)
	,HammerPower: ($_=function(v) { return {_hx_index:14,v:v,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="HammerPower",$_.__params__ = ["v"],$_)
	,RangeDelta: ($_=function(v) { return {_hx_index:15,v:v,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="RangeDelta",$_.__params__ = ["v"],$_)
	,FishingPower: ($_=function(v) { return {_hx_index:16,v:v,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="FishingPower",$_.__params__ = ["v"],$_)
	,RestoresLife: ($_=function(amt) { return {_hx_index:17,amt:amt,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="RestoresLife",$_.__params__ = ["amt"],$_)
	,RestoresMana: ($_=function(amt) { return {_hx_index:18,amt:amt,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="RestoresMana",$_.__params__ = ["amt"],$_)
	,UseTime: ($_=function(t,perSecond) { return {_hx_index:19,t:t,perSecond:perSecond,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="UseTime",$_.__params__ = ["t","perSecond"],$_)
	,Knockback: ($_=function(amt) { return {_hx_index:20,amt:amt,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="Knockback",$_.__params__ = ["amt"],$_)
	,ManaCost: ($_=function(amt) { return {_hx_index:21,amt:amt,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="ManaCost",$_.__params__ = ["amt"],$_)
	,Consumable: {_hx_name:"Consumable",_hx_index:22,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Vanity: {_hx_name:"Vanity",_hx_index:23,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Ammo: {_hx_name:"Ammo",_hx_index:24,__enum__:"terra.ItemMetaLine",toString:$estr}
	,Material: {_hx_name:"Material",_hx_index:25,__enum__:"terra.ItemMetaLine",toString:$estr}
	,EnText: ($_=function(s) { return {_hx_index:26,s:s,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="EnText",$_.__params__ = ["s"],$_)
	,MaxStack: ($_=function(n) { return {_hx_index:27,n:n,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="MaxStack",$_.__params__ = ["n"],$_)
	,Worth: ($_=function(s) { return {_hx_index:28,s:s,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="Worth",$_.__params__ = ["s"],$_)
	,ResearchGoal: ($_=function(n) { return {_hx_index:29,n:n,__enum__:"terra.ItemMetaLine",toString:$estr}; },$_._hx_name="ResearchGoal",$_.__params__ = ["n"],$_)
};
terra_ItemMetaLine.__constructs__ = [terra_ItemMetaLine.Tile,terra_ItemMetaLine.Wall,terra_ItemMetaLine.Helmet,terra_ItemMetaLine.Shirt,terra_ItemMetaLine.Pants,terra_ItemMetaLine.Accessory,terra_ItemMetaLine.MeleeDamage,terra_ItemMetaLine.RangedDamage,terra_ItemMetaLine.MagicDamage,terra_ItemMetaLine.SummonDamage,terra_ItemMetaLine.Crit,terra_ItemMetaLine.Defense,terra_ItemMetaLine.PickaxePower,terra_ItemMetaLine.AxePower,terra_ItemMetaLine.HammerPower,terra_ItemMetaLine.RangeDelta,terra_ItemMetaLine.FishingPower,terra_ItemMetaLine.RestoresLife,terra_ItemMetaLine.RestoresMana,terra_ItemMetaLine.UseTime,terra_ItemMetaLine.Knockback,terra_ItemMetaLine.ManaCost,terra_ItemMetaLine.Consumable,terra_ItemMetaLine.Vanity,terra_ItemMetaLine.Ammo,terra_ItemMetaLine.Material,terra_ItemMetaLine.EnText,terra_ItemMetaLine.MaxStack,terra_ItemMetaLine.Worth,terra_ItemMetaLine.ResearchGoal];
var terra_ItemStats = function(meta) {
	this.text = "";
	this.fishingPower = 0;
	this.rangeBoost = 0;
	this.hammerPower = 0;
	this.axePower = 0;
	this.pickPower = 0;
	this.healMana = 0;
	this.healLife = 0;
	this.defense = 0;
	this.manaCost = 0;
	this.knockback = 0;
	this.crit = 4;
	this.damage = 0;
	this.useTime = 10;
	this.stack = 0;
	this.value = 0;
	var pairs = meta.split("|");
	var type = pairs.shift();
	if(type.indexOf("1") >= 0) {
		this.stack = 1;
	}
	if(type.indexOf("H") >= 0) {
		this.stack = 99;
	}
	if(type.indexOf("K") >= 0) {
		this.stack = 999;
	}
	var _g = 0;
	while(_g < pairs.length) {
		var pair = pairs[_g];
		++_g;
		var sep = pair.indexOf("=");
		var key = pair.substring(0,sep);
		var par = pair.substring(sep + 1);
		switch(key) {
		case "1":case "2":
			this.text = this.text != "" ? this.text + "\n" + par : par;
			break;
		default:
			var i = Math.round(parseFloat(par));
			switch(key) {
			case "D":
				this.defense = i;
				break;
			case "c":
				this.crit += i;
				break;
			case "d":
				this.damage = i;
				break;
			case "hl":
				this.healLife = i;
				break;
			case "hm":
				this.healMana = i;
				break;
			case "k":
				this.knockback = i;
				break;
			case "m":
				this.manaCost = i;
				break;
			case "s":
				this.stack = i;
				break;
			case "t":
				this.useTime = i;
				break;
			case "tf":
				this.fishingPower = i;
				break;
			case "th":
				this.hammerPower = i;
				break;
			case "tp":
				this.pickPower = i;
				break;
			case "tr":
				this.rangeBoost = i;
				break;
			case "tx":
				this.axePower = i * 5;
				break;
			case "z":
				this.value = i;
				break;
			}
		}
	}
};
terra_ItemStats.__name__ = true;
terra_ItemStats.prototype = {
	__class__: terra_ItemStats
};
var terra_data_TdItem = function() { };
terra_data_TdItem.__name__ = true;
var terra_data_TdNPC = function() { };
terra_data_TdNPC.__name__ = true;
var terra_data_TdRecipe = function() { };
terra_data_TdRecipe.__name__ = true;
var utils_Mix = function() { };
utils_Mix.__name__ = true;
utils_Mix.__js_init__ = function() {
	var k = function(i) {
		return (10 + i).toString(36);
	};
	var l = function(i) {
		return k(i).toLowerCase();
	};
	var u = function(i) {
		return k(i).toUpperCase();
	};
	var d = [5,17,14,12,-2,7,0,17,-2,14,3,4];
	var a = "";
	var i = 0;
	var v;
	while(true) {
		v = d[i++];
		if(!(v != null)) {
			break;
		}
		a += v < 0 ? u(-v) : l(v);
	}
	stringCharCode = js_Boot.getClass("")[a];
};
var wiki_Wiki = function() { };
wiki_Wiki.__name__ = true;
wiki_Wiki.url = function(query) {
	if(wiki_Wiki.rxAbsolute.test(query)) {
		return query;
	}
	return "?q=" + query;
};
wiki_Wiki.set_title = function(s) {
	window.document.title = s;
	return s;
};
wiki_Wiki.open = function(rq) {
	if(rq != null && rq != "") {
		rq = decodeURIComponent(rq.split("+").join(" "));
		var rql = rq.toLowerCase();
		var item;
		var npc;
		var cat = wiki_WikiCategory.mapLq.h[rql];
		if(cat != null) {
			wiki_Wiki.state = wiki_state_WikiStateCat.deploy(cat);
		} else {
			npc = wiki_WikiNPC.nameMapLq.h[rql];
			if(npc != null) {
				wiki_Wiki.state = new wiki_state_WikiStateNPC(npc);
			} else {
				item = wiki_WikiItem.fromLq(rql);
				if(item != null) {
					wiki_Wiki.state = new wiki_state_WikiStateItem(item);
				} else {
					wiki_Wiki.state = new wiki_WikiSearch(rq);
				}
			}
		}
	} else {
		wiki_Wiki.state = new wiki_state_WikiStateHome();
	}
};
wiki_Wiki.clear = function() {
	var content = window.document.getElementsByClassName("content")[0];
	content.innerHTML = "";
};
wiki_Wiki.openExt = function(rq) {
	wiki_Wiki.clear();
	window.history.pushState({ page : rq},window.document.title,rq != null ? "?q=" + rq : "?");
	wiki_Wiki.open(rq);
};
wiki_Wiki.parseArgs = function() {
	var url = window.document.location.href;
	var qpos = url.indexOf("?");
	if(qpos >= 0) {
		var pairs = HxOverrides.substr(url,qpos + 1,null).split("&");
		wiki_Wiki.args = { };
		var _g = 0;
		while(_g < pairs.length) {
			var pair = pairs[_g];
			++_g;
			var epos = pair.indexOf("=");
			if(epos >= 0) {
				wiki_Wiki.args[HxOverrides.substr(pair,0,epos)] = HxOverrides.substr(pair,epos + 1,null);
			} else {
				wiki_Wiki.args[pair] = "";
			}
		}
	} else {
		wiki_Wiki.args = { };
	}
};
wiki_Wiki.main = function() {
	wiki_Wiki.isFile = window.document.location.protocol == "file:";
	var s = window.document.location.href;
	var r = s.indexOf("://yal.cc");
	if(r < 0) {
		r = s.indexOf("://yellowafterlife.itch.io");
	}
	if(r < 0) {
		r = s.indexOf("://v6p9d9t4.ssl.hwcdn.net");
	}
	if(r < 0) {
		r = s.indexOf("file://");
	}
	if(!(r >= 0 && r < 8)) {
		return;
	}
	var homeLink = window.document.getElementById("home-link");
	if(wiki_Wiki.isFile) {
		homeLink.href = "index.html";
	}
	homeLink.onclick = function(e) {
		wiki_Wiki.openExt("");
		e.preventDefault();
		return false;
	};
	window.onpopstate = function(e) {
		var state = e.state;
		$global.console.log(e,state);
		wiki_Wiki.clear();
		if(state != null && state.page != null) {
			wiki_Wiki.open(state.page);
		} else {
			wiki_Wiki.parseArgs();
			wiki_Wiki.openExt(wiki_Wiki.args["q"]);
		}
	};
	wiki_WikiItem.init();
	wiki_WikiNPC.init();
	wiki_WikiCategory.init();
	wiki_WikiRecipeInit.run();
	wiki_WikiSearch.init();
	wiki_WikiDataReader.run();
	wiki_Wiki.parseArgs();
	var rq = wiki_Wiki.args["q"];
	var search = window.document.getElementById("search");
	if(!wiki_Wiki.isFile) {
		search.setAttribute("action","./");
	}
	new wiki_WikiCompletion(search.getElementsByClassName("search")[0],search.getElementsByClassName("completion")[0]);
	wiki_Wiki.open(rq);
};
var wiki_WikiAutoCats = function() { };
wiki_WikiAutoCats.__name__ = true;
wiki_WikiAutoCats.deploy = function() {
	var list = [];
	var create = function(name,icon) {
		if(icon == null) {
			icon = 0;
		}
		var r = new wiki_WikiCategory();
		r.alias = name.split("|");
		r.name = r.alias[0];
		r.icon = wiki_WikiItem.idMap.h[icon].icon;
		wiki_WikiCategory.register(r);
		return r;
	};
	var sub;
	var item;
	var npc;
	var WikiItem_list = wiki_WikiItem.list;
	var forItem_i;
	var par = wiki_WikiCategory.mapLq.h["tools"];
	var cat = create("Pickaxe",3485);
	var items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.meta.indexOf("tp=") >= 0) {
			items.push(item);
		}
	}
	cat.what = "All items with pickaxe (block breaking) capabilities." + "@[cols:damage|usetime|pickaxe|range|knockback]";
	par.cats.push(cat);
	cat = create("Axe",3482);
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.meta.indexOf("tx=") >= 0) {
			items.push(item);
		}
	}
	cat.what = "All items with axe (wood cutting) capabilities." + "@[cols:damage|usetime|axe|range|knockback]";
	par.cats.push(cat);
	cat = create("Hammer",3481);
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.meta.indexOf("th=") >= 0) {
			items.push(item);
		}
	}
	cat.what = "All items with hammer (wall breaking) capabilities." + "@[cols:damage|usetime|hammer|range|knockback]";
	par.cats.push(cat);
	cat = create("Fishing Pole",2289);
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.meta.indexOf("tf=") >= 0) {
			items.push(item);
		}
	}
	cat.what = "All items with fishing pole ([fishing]) capabilities." + "@[cols:fishing]";
	par.cats.push(cat);
	cat = create("Grappling Hooks",84);
	cat.what = "Grappling hooks are a class of items used to aid in terrain traversal. When used, a chain is fired towards the cursor, and pulls the player towards the hit surface (if any).";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(wiki_spec_WikiStateHooks.vel.h.hasOwnProperty(item.id)) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	par = wiki_WikiCategory.mapLq.h["weapons"];
	cat = create("Melee damage",3484);
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("d") >= 0) {
			items.push(item);
		}
	}
	cat.what = "Automatic list of all items with melee damage." + "@[cols:damage|usetime|dps|crit|knockback]";
	par.catNames.push(cat.name);
	cat = create("Ranged damage",682);
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		var mt = item.metaType;
		if(mt.indexOf("r") >= 0 && mt.indexOf("b") < 0) {
			items.push(item);
		}
	}
	cat.what = "Automatic list of all items with ranged damage." + "@[cols:damage|usetime|dps|crit|knockback]";
	par.catNames.push(cat.name);
	cat = create("Magic damage",494);
	cat.what = "Automatic list of all items with magic damage." + "@[cols:damage|manacost|usetime|dps|mps|dpm]";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("m") >= 0) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	cat = create("Summon damage",1309);
	list.push(cat);
	cat.what = "Automatic list of all items with summon damage." + "@[cols:damage|manacost|knockback]";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("s") >= 0) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	par = wiki_WikiCategory.mapLq.h["equipable"];
	var s = "@[cols:defense]";
	cat = create("Helmet|Headgear",102);
	cat.what = "Automatic list of anything equipable in the head slot." + s;
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("4") >= 0) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	cat = create("Armor|Breastplate|Chainmail|Scalemail",101);
	cat.what = "Automatic list of anything equipable in the body slot." + s;
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("5") >= 0) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	cat = create("Greaves",100);
	cat.what = "Automatic list of anything equipable in the legs slot." + s;
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("6") >= 0) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	cat = create("Accessory",49);
	cat.what = "Automatic list of anything equipable in the accesory slots.@[cols:text]";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("a") >= 0) {
			items.push(item);
		}
	}
	par.catNames.push(cat.name);
	var npcs = [];
	var id = 0;
	var num = wiki_WikiNPC.count;
	while(id < num) {
		npc = wiki_WikiNPC.idMap.h[id];
		if(npc.metaType.indexOf("t") >= 0 && id != 37) {
			npcs.push(npc);
		}
		++id;
	}
	cat = create("Town NPCs");
	list.push(cat);
	cat.what = "@[npcs:what+where]";
	cat.icon = npcs[0].icon;
	cat.entities = npcs;
	npcs = [];
	id = 1;
	num = wiki_WikiNPC.count;
	while(id < num) {
		npc = wiki_WikiNPC.idMap.h[id++];
		if(npc.metaType.indexOf("f") < 0 && npc.get_stats().damage > 0) {
			npcs.push(npc);
		}
	}
	cat = create("Hostile NPCs");
	list.push(cat);
	cat.icon = npcs[0].icon;
	cat.entities = npcs;
	cat.what = "@[npcs:health|damage|defense|ai]";
	cat = create("Treasure Bags",3318);
	cat.what = "Treasure bags replace the regular boss drops in [Expert Mode]." + "\nIn MP, each player will get an individual bag that no one else can pick up.";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(StringTools.startsWith(item.name,"Treasure Bag")) {
			items.push(item);
		}
	}
	cat = create("Items by ID",50);
	id = Math.floor(wiki_WikiItem.firstId / 50) * 50;
	while(id < 0 || wiki_WikiItem.idMap.h.hasOwnProperty(id)) {
		var n = 50;
		items = [];
		while(--n >= 0) {
			var item1 = wiki_WikiItem.idMap.h[id];
			if(item1 != null) {
				if(id != 0) {
					items.push(item1);
				}
			} else if(id > 0) {
				break;
			}
			++id;
		}
		sub = create("Items " + items[0].id + " .. " + items[items.length - 1].id,items[0].id);
		sub.items = items;
		sub.searchable = false;
		cat.cats.push(sub);
	}
	cat.noItems = true;
	list.push(cat);
	cat = create("Entities by ID");
	cat.icon = wiki_WikiNPC.idMap.h[1].icon;
	id = 0;
	while(id <= 0 || wiki_WikiNPC.idMap.h.hasOwnProperty(id)) {
		var n = 50;
		npcs = [];
		while(--n >= 0) {
			var npc = wiki_WikiNPC.idMap.h[id];
			if(npc != null) {
				if(id != 0) {
					npcs.push(npc);
				}
			} else {
				break;
			}
			++id;
		}
		sub = create("Entities " + npcs[0].id + " .. " + npcs[npcs.length - 1].id);
		sub.what = "@[npcs:health|damage|defense|ai]";
		sub.icon = npcs[0].icon;
		sub.entities = npcs;
		sub.searchable = false;
		cat.cats.push(sub);
	}
	cat.noItems = true;
	list.push(cat);
	cat = create("Tiles|Tile",751);
	cat.what = "Automatic list of anything that can be placed in the foreground layer.";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("t") >= 0) {
			items.push(item);
		}
	}
	cat = create("Walls|Wall",752);
	cat.what = "Automatic list of anything that can be placed in the background layer.";
	items = cat.items;
	forItem_i = 0;
	while(forItem_i < WikiItem_list.length) {
		item = WikiItem_list[forItem_i++];
		if(item.metaType.indexOf("w") >= 0) {
			items.push(item);
		}
	}
	cat = create("Letter statues",2735);
	items = [];
	cat.items = items;
	id = 2702;
	while(id <= 2737) items.push(wiki_WikiItem.idMap.h[id++]);
	var addCatRange = function(start,count,name,desc) {
		var items = [];
		var _g = 0;
		var _g1 = count;
		while(_g < _g1) {
			var i = _g++;
			items.push(wiki_WikiItem.idMap.h[start + i]);
		}
		var cat = create(name,start);
		cat.what = desc;
		cat.items = items;
		list.push(cat);
		return cat;
	};
	var addCatRanges = function(start,end,page,name,desc) {
		var i = start;
		var pt = 1;
		var cat = create(name,start);
		while(i < end) {
			var n = end - i;
			if(n > page) {
				n = page;
			}
			var sub = addCatRange(i,n,name + (" (part " + pt + ")"),desc);
			cat.cats.push(sub);
			i += page;
			++pt;
		}
	};
	addCatRanges(2749,3940,200,"Items introduced in Terraria 1.3.x","");
	addCatRanges(3940,terra_data_TdItem.maxId + 1,200,"Items introduced in Terraria 1.4.x","");
	addCatRanges(5088,5125,200,"Items introduced in Terraria x Don't Starve update","");
	addCatRanges(5125,5453,200,"Items introduced in Labor of Love update","");
};
var wiki_WikiPage = function() {
	this.where = null;
	this.what = null;
	this.partOf = [];
	this.related = [];
	this.searchable = true;
	this.icon = wiki_WikiIcon.NONE;
};
wiki_WikiPage.__name__ = true;
wiki_WikiPage.prototype = {
	get_tooltip: function() {
		return "";
	}
	,scan: function(md) {
		var pos = md.indexOf("[");
		while(pos >= 0) {
			var end = md.indexOf("]",pos);
			if(end < 0) {
				break;
			}
			var url = md.substring(pos + 1,end).toLowerCase();
			var page = wiki_WikiPage.nameMapLq.h[url];
			if(page != null && this.related.indexOf(page) == -1) {
				while(true) {
					if(((page) instanceof wiki_WikiCategory)) {
						var cat = page;
						if(this.partOf.indexOf(cat) >= 0) {
							break;
						}
					}
					this.related.push(page);
					page.related.push(this);
					if(!false) {
						break;
					}
				}
			}
			pos = md.indexOf("[",end + 1);
		}
	}
	,__class__: wiki_WikiPage
};
var wiki_WikiCategory = function() {
	this.filled = false;
	this.isPage = false;
	this.noItems = false;
	this.catNames = [];
	this.cats = [];
	this.pageNames = [];
	this.pages = [];
	this.entities = [];
	this.items = [];
	wiki_WikiPage.call(this);
};
wiki_WikiCategory.__name__ = true;
wiki_WikiCategory.register = function(cat) {
	var cat_name = cat.name;
	var cat_name_lq = cat_name.toLowerCase();
	var _g = 0;
	var _g1 = cat.alias;
	while(_g < _g1.length) {
		var s = _g1[_g];
		++_g;
		wiki_WikiCategory.map.h[s] = cat;
		var s_lq = s.toLowerCase();
		wiki_WikiCategory.mapLq.h[s_lq] = cat;
		wiki_WikiPage.nameMapLq.h[s_lq] = cat;
	}
	wiki_WikiCategory.list.push(cat);
	wiki_WikiCategory.nameList.push(cat_name);
	wiki_WikiCategory.nameListLq.push(cat_name_lq);
};
wiki_WikiCategory.init = function() {
	wiki_WikiCategory.map = new haxe_ds_StringMap();
	wiki_WikiCategory.mapLq = new haxe_ds_StringMap();
	wiki_WikiCategory.list = [];
	wiki_WikiCategory.nameList = [];
	wiki_WikiCategory.nameListLq = [];
	var cats = Reflect.field(window,"__cats");
	var _g = 0;
	while(_g < cats.length) {
		var data = cats[_g];
		++_g;
		var cat = new wiki_WikiCategory();
		var pos = data.indexOf(":");
		var what;
		if(pos >= 0) {
			what = data.substring(pos + 1);
			data = data.substring(0,pos);
		} else {
			what = "";
		}
		cat.what = what;
		var pairs = data.split(";");
		cat.alias = pairs.shift().split(",");
		cat.name = cat.alias[0];
		if(what.indexOf("@[noitems]") >= 0) {
			cat.noItems = true;
		}
		var _g1 = 0;
		while(_g1 < pairs.length) {
			var pair = pairs[_g1];
			++_g1;
			var pk = HxOverrides.cca(pair,0);
			var pd = pair.substring(1);
			switch(pk) {
			case 73:
				cat.icon = wiki_WikiItem.fromId(Std.parseInt(pd)).icon;
				break;
			case 78:
				cat.icon = wiki_WikiNPC.idMap.h[Std.parseInt(pd)].icon;
				break;
			case 80:
				cat.isPage = true;
				break;
			case 85:
				cat.icon = new wiki_WikiIconFit(pd + ".png");
				break;
			case 99:
				var cat_subNames = cat.catNames;
				var _g2 = 0;
				var _g3 = pd.split("|");
				while(_g2 < _g3.length) {
					var s = _g3[_g2];
					++_g2;
					cat_subNames.push(s);
				}
				break;
			case 105:
				var cat_items = cat.items;
				var _g4 = 0;
				var _g5 = pd.split(",");
				while(_g4 < _g5.length) {
					var s1 = _g5[_g4];
					++_g4;
					cat_items.push(wiki_WikiItem.fromId(Std.parseInt(s1)));
				}
				break;
			case 110:
				var cat_entities = cat.entities;
				var _g6 = 0;
				var _g7 = pd.split(",");
				while(_g6 < _g7.length) {
					var s2 = _g7[_g6];
					++_g6;
					cat_entities.push(wiki_WikiNPC.idMap.h[Std.parseInt(s2)]);
				}
				break;
			case 112:
				var cat_pageNames = cat.pageNames;
				var _g8 = 0;
				var _g9 = pd.split("|");
				while(_g8 < _g9.length) {
					var s3 = _g9[_g8];
					++_g8;
					cat_pageNames.push(s3);
				}
				break;
			case 119:
				cat.where = pd;
				break;
			}
		}
		wiki_WikiCategory.register(cat);
	}
	wiki_WikiAutoCats.deploy();
	var _g = 0;
	var _g1 = wiki_WikiCategory.list;
	while(_g < _g1.length) {
		var cat = _g1[_g];
		++_g;
		var cat_subs = cat.cats;
		var _g2 = 0;
		var _g3 = cat.catNames;
		while(_g2 < _g3.length) {
			var name = _g3[_g2];
			++_g2;
			var cat2 = wiki_WikiCategory.mapLq.h[name.toLowerCase()];
			if(cat2 != null) {
				cat_subs.push(cat2);
			} else {
				console.log("src/wiki/WikiCategory.hx:123:","Category missing: " + name + " (ref in " + cat.name + ")");
			}
		}
		var cat_pages = cat.pages;
		var _g4 = 0;
		var _g5 = cat.pageNames;
		while(_g4 < _g5.length) {
			var name1 = _g5[_g4];
			++_g4;
			var page = wiki_WikiPage.nameMapLq.h[name1.toLowerCase()];
			if(page != null) {
				cat_pages.push(page);
			} else {
				console.log("src/wiki/WikiCategory.hx:130:","Category " + cat.name + " is referencing missing page " + name1);
			}
		}
	}
	var _g = 0;
	var _g1 = wiki_WikiCategory.list;
	while(_g < _g1.length) {
		var cat = _g1[_g];
		++_g;
		if(!cat.noItems) {
			cat.fill();
		}
	}
	var _g = 0;
	var _g1 = wiki_WikiCategory.list;
	while(_g < _g1.length) {
		var cat = _g1[_g];
		++_g;
		if(cat.searchable) {
			if(!cat.noItems) {
				var _g2 = 0;
				var _g3 = cat.items;
				while(_g2 < _g3.length) {
					var item = _g3[_g2];
					++_g2;
					item.partOf.push(cat);
				}
				var _g4 = 0;
				var _g5 = cat.entities;
				while(_g4 < _g5.length) {
					var npc = _g5[_g4];
					++_g4;
					npc.partOf.push(cat);
				}
				var _g6 = 0;
				var _g7 = cat.pages;
				while(_g6 < _g7.length) {
					var page = _g7[_g6];
					++_g6;
					page.partOf.push(cat);
				}
			}
			var _g8 = 0;
			var _g9 = cat.cats;
			while(_g8 < _g9.length) {
				var sub = _g9[_g8];
				++_g8;
				sub.addParent(cat);
			}
			var _g10 = 0;
			var _g11 = cat.alias;
			while(_g10 < _g11.length) {
				var alias = _g11[_g10];
				++_g10;
				wiki_WikiCategory.mapLq.h[alias.toLowerCase()] = cat;
			}
		}
	}
	var all = new wiki_WikiCategory();
	all.name = "Categories";
	all.alias = [all.name];
	all.what = "Automatic list of all top-level categories.";
	all.icon = wiki_WikiItem.fromId(65).icon;
	var allcats = [];
	var _g = 0;
	var _g1 = wiki_WikiCategory.list;
	while(_g < _g1.length) {
		var cat = _g1[_g];
		++_g;
		if(cat.partOf.length == 0 && !cat.isPage) {
			allcats.push(cat);
		}
	}
	all.cats = allcats;
	all.items = [];
	wiki_WikiCategory.register(all);
};
wiki_WikiCategory.__super__ = wiki_WikiPage;
wiki_WikiCategory.prototype = $extend(wiki_WikiPage.prototype,{
	get_tooltip: function() {
		if(this.isPage) {
			return "(Page)";
		} else {
			return "(Category)";
		}
	}
	,fill: function() {
		this.filled = true;
		var _g = 0;
		var _g1 = this.cats;
		while(_g < _g1.length) {
			var cat = _g1[_g];
			++_g;
			cat.pushItems(this);
		}
	}
	,pushItems: function(cat) {
		if(!this.filled) {
			this.fill();
		}
		var cat_items = cat.items;
		var _g = 0;
		var _g1 = this.items;
		while(_g < _g1.length) {
			var item = _g1[_g];
			++_g;
			if(cat_items.indexOf(item) < 0) {
				cat_items.push(item);
			}
		}
		var cat_entities = cat.entities;
		var _g = 0;
		var _g1 = this.entities;
		while(_g < _g1.length) {
			var npc = _g1[_g];
			++_g;
			if(cat_entities.indexOf(npc) < 0) {
				cat_entities.push(npc);
			}
		}
		var cat_pages = cat.pages;
		var _g = 0;
		var _g1 = this.pages;
		while(_g < _g1.length) {
			var page = _g1[_g];
			++_g;
			if(cat_pages.indexOf(page) < 0) {
				cat_pages.push(page);
			}
		}
	}
	,addParent: function(par) {
		this.partOf.push(par);
		var _g = 0;
		var _g1 = this.cats;
		while(_g < _g1.length) {
			var cat = _g1[_g];
			++_g;
			cat.addParent(par);
		}
	}
	,__class__: wiki_WikiCategory
});
var wiki_state_WikiState = function(__break) {
	if(__break || !wiki_state_WikiState.__valid) {
		this.node = window.document.createElement("div");
	} else {
		this.node = window.document.getElementsByClassName("content")[0];
	}
};
wiki_state_WikiState.__name__ = true;
wiki_state_WikiState.setHref = function(r,href,name) {
	if(href == null) {
		return;
	}
	r.href = href;
	var qi = href.indexOf("q=");
	if(qi < 0) {
		return;
	}
	r.onclick = function(e) {
		var rq = href.substring(qi + 2);
		wiki_Wiki.openExt(rq);
		e.preventDefault();
		return false;
	};
};
wiki_state_WikiState.prototype = {
	add: function(e) {
		this.node.appendChild(e);
		return e;
	}
	,addTo: function(parent,child) {
		parent.appendChild(child);
		return child;
	}
	,addTag: function(tag) {
		var r = window.document.createElement(tag);
		this.node.appendChild(r);
		return r;
	}
	,createPageTitle: function(name,icon,etc) {
		var r = window.document.createElement("div");
		r.className = "item-title";
		if(icon != null) {
			r.appendChild(icon.toIcon());
		}
		r.appendChild(this.createLink(name,wiki_Wiki.url(name)));
		if(etc != null) {
			r.appendChild(window.document.createTextNode(" " + etc));
		}
		return r;
	}
	,addPageTitle: function(name,icon,etc) {
		var r = window.document.createElement("div");
		r.className = "item-title";
		if(icon != null) {
			r.appendChild(this.createIcon(icon));
		}
		r.appendChild(this.createLink(name,wiki_Wiki.url(name)));
		if(etc != null) {
			r.appendChild(window.document.createTextNode(" " + etc));
		}
		return this.add(r);
	}
	,addHeader: function(s,url) {
		var r = window.document.createElement("h3");
		r.textContent = s;
		this.node.appendChild(r);
		return r;
	}
	,addText: function(text) {
		var r = window.document.createElement("div");
		r.textContent = text;
		this.node.appendChild(r);
		return r;
	}
	,createTableHead: function(cols) {
		var cols1 = cols.split("|");
		var n = cols1.length;
		var i;
		var p;
		var f;
		var col;
		var widths = [];
		var total = 0;
		i = 0;
		while(i < n) {
			col = cols1[i];
			p = col.indexOf(":");
			if(p >= 0) {
				f = parseFloat(col.substring(p + 1));
				cols1[i] = col.substring(0,p);
			} else {
				f = 1;
			}
			widths.push(f);
			total += f;
			++i;
		}
		var tr = window.document.createElement("tr");
		i = 0;
		while(i < n) {
			var td = window.document.createElement("td");
			td.width = widths[i] / total * 100 + "%";
			td.appendChild(window.document.createTextNode(cols1[i]));
			tr.appendChild(td);
			++i;
		}
		return tr;
	}
	,createIcon: function(item) {
		var icon = window.document.createElement("span");
		icon.className = "icon";
		var style = icon.style;
		var i = item.id;
		if(i < 0) {
			style.backgroundImage = "url(img/nitems.png)";
			i = -i;
		} else {
			style.backgroundImage = "url(img/items.png)";
		}
		style.backgroundPosition = -((i & 31) * 40) + "px " + -((i >> 5) * 40) + "px";
		return icon;
	}
	,createItemThumbLink: function(item) {
		var r = this.createLink(null,wiki_Wiki.url(item.name));
		r.appendChild(item.icon.toThumb());
		var text = item.name;
		r.appendChild(window.document.createTextNode(text));
		r.title = item.get_tooltip();
		r.style.display = "inline-block";
		return r;
	}
	,createLink: function(text,href) {
		var r = window.document.createElement("a");
		if(href != null) {
			wiki_state_WikiState.setHref(r,href);
		}
		if(text != null) {
			r.appendChild(window.document.createTextNode(text));
		}
		return r;
	}
	,createIconRow: function(icon,text,url) {
		var r = window.document.createElement("div");
		r.className = "itemrow";
		var o;
		if(url != null) {
			o = window.document.createElement("a");
			wiki_state_WikiState.setHref(o,url);
			r.appendChild(o);
		} else {
			o = r;
		}
		if(icon != null) {
			o.appendChild(icon.toThumb());
		}
		if(text != null) {
			o.appendChild(window.document.createTextNode(text));
		}
		return r;
	}
	,createItemRow: function(item) {
		var r = this.createIconRow(item.icon,item.name,wiki_Wiki.url(item.name));
		var a = r.children[0];
		a.title = item.get_tooltip();
		return r;
	}
	,createPrice: function(price) {
		var r = window.document.createElement("span");
		var i;
		var thumb;
		var item;
		var link;
		var txn;
		var itemId = 70;
		if(price <= 0) {
			r.appendChild(window.document.createTextNode("(no value)"));
		} else {
			while(++itemId < 75) {
				i = price % 100;
				if(i > 0) {
					item = wiki_WikiItem.idMap.h[itemId];
					var item_name = item.name;
					thumb = item.icon.toThumb();
					thumb.title = item_name;
					link = window.document.createElement("a");
					wiki_state_WikiState.setHref(link,wiki_Wiki.url(item_name),item_name);
					this.addTo(link,thumb);
					txn = window.document.createTextNode(i == null ? "null" : "" + i);
					if(itemId == 71) {
						r.appendChild(link);
						r.appendChild(txn);
					} else {
						r.insertBefore(txn,r.childNodes[0]);
						r.insertBefore(link,r.childNodes[0]);
					}
				}
				price = price / 100 | 0;
			}
		}
		return r;
	}
	,createPageRow: function(page) {
		var r = this.createIconRow(page.icon,page.name,wiki_Wiki.url(page.name));
		var a = r.children[0];
		a.title = page.get_tooltip();
		return r;
	}
	,createItemRecipe: function(recipe) {
		var _gthis = this;
		var r = window.document.createElement("div");
		r.className = "recipe";
		var o = recipe.result;
		r.appendChild(_gthis.createItemThumbLink(o.item));
		var i = o.count;
		if(i > 1) {
			r.appendChild(window.document.createTextNode(" (" + i + ")"));
		}
		r.appendChild(window.document.createTextNode(": "));
		var recipe_items = recipe.items;
		var _g = 0;
		var _g1 = recipe_items.length;
		while(_g < _g1) {
			var i = _g++;
			if(i > 0) {
				r.appendChild(window.document.createTextNode(" + "));
			}
			var o = recipe_items[i];
			r.appendChild(_gthis.createItemThumbLink(o.item));
			var i1 = o.count;
			if(i1 > 1) {
				r.appendChild(window.document.createTextNode(" (" + i1 + ")"));
			}
		}
		var list = [];
		var _g = 0;
		var _g1 = recipe.tiles;
		while(_g < _g1.length) {
			var tile = _g1[_g];
			++_g;
			list.push(tile);
		}
		if(recipe.needWater) {
			list.push("in water");
		}
		if(recipe.needLava) {
			list.push("near lava");
		}
		if(list.length == 0) {
			list.push("anywhere");
		}
		var cond = window.document.createElement("span");
		this.appendMd(cond," (" + list.join("; ") + ")");
		r.appendChild(cond);
		return r;
	}
	,createMd: function(type,code,meta) {
		var r = window.document.createElement(type);
		this.appendMd(r,code,meta);
		return r;
	}
	,appendMd: function(element,code,meta) {
		var _gthis = this;
		if(code == null || code == "") {
			return;
		}
		var pos = 0;
		var len = code.length;
		var depth = 0;
		var stackNode = [];
		var stackType = [];
		var stackShift = [];
		var type = -1;
		var node = element;
		var shift = 0;
		var el;
		var start = 0;
		var pos0;
		var char;
		while(pos < len) {
			pos0 = pos;
			char = code.charCodeAt(pos++);
			switch(char) {
			case 10:
				var br = true;
				if(start < pos0) {
					var text = code.substring(start,pos0);
					node.appendChild(window.document.createTextNode(text));
				}
				start = pos;
				if(node.className == "indent") {
					node = stackNode[--depth];
					type = stackType[depth];
					shift = stackShift[depth];
					br = false;
				}
				var t = 0;
				while(code.charCodeAt(pos) == 9) {
					++pos;
					++t;
				}
				if(t > 0) {
					var tab = window.document.createElement("div");
					tab.className = "indent";
					tab.style.paddingLeft = t * 20 + "px";
					stackNode[depth] = node;
					stackType[depth] = type;
					stackShift[depth++] = shift;
					node.appendChild(tab);
					node = tab;
					type = char;
					shift = pos;
					br = false;
				}
				if(br) {
					node.appendChild(window.document.createElement("br"));
				}
				start = pos;
				break;
			case 33:
				char = code.charCodeAt(pos);
				if(char == 91) {
					if(start < pos0) {
						var text1 = code.substring(start,pos0);
						node.appendChild(window.document.createTextNode(text1));
					}
					start = pos;
					pos = code.indexOf("]",pos) + 1;
					var url = code.substring(pos0 + 2,pos - 1);
					if(url == "icon") {
						if(((this) instanceof wiki_state_WikiStatePage)) {
							var this_as_page = this;
							node.appendChild(this_as_page.page.icon.toOriginal());
						}
					} else {
						var img = window.document.createElement("img");
						img.src = "img/" + url + ".png";
						node.appendChild(img);
					}
					start = pos;
				}
				break;
			case 42:case 95:
				if(start < pos0) {
					var text2 = code.substring(start,pos0);
					node.appendChild(window.document.createTextNode(text2));
				}
				start = pos;
				if(type != char) {
					var tag = char == 42 ? "b" : "i";
					var q = window.document.createElement(tag);
					stackNode[depth] = node;
					stackType[depth] = type;
					stackShift[depth++] = shift;
					node.appendChild(q);
					node = q;
					type = char;
					shift = pos;
				} else {
					node = stackNode[--depth];
					type = stackType[depth];
					shift = stackShift[depth];
				}
				break;
			case 64:
				if(code.charCodeAt(pos) == 91) {
					if(start < pos0) {
						var text3 = code.substring(start,pos0);
						node.appendChild(window.document.createTextNode(text3));
					}
					start = pos;
					pos = code.indexOf("]",pos) + 1;
					if(meta != null) {
						var str = code.substring(pos0 + 2,pos - 1);
						var sep = str.indexOf(":");
						if(sep >= 0) {
							var v = str.substring(sep + 1);
							meta.h[str.substring(0,sep)] = v;
						} else {
							meta.h[str] = "";
						}
					}
					start = pos;
				}
				break;
			case 91:
				if(start < pos0) {
					var text4 = code.substring(start,pos0);
					node.appendChild(window.document.createTextNode(text4));
				}
				start = pos;
				var q1 = window.document.createElement("a");
				stackNode[depth] = node;
				stackType[depth] = type;
				stackShift[depth++] = shift;
				node.appendChild(q1);
				node = q1;
				type = char;
				shift = pos;
				break;
			case 93:
				if(type == 91) {
					if(start < pos0) {
						var text5 = code.substring(start,pos0);
						node.appendChild(window.document.createTextNode(text5));
					}
					start = pos;
					var url1 = null;
					if(code.charCodeAt(pos) == 40) {
						start = code.indexOf(")",pos);
						if(start >= 0) {
							url1 = code.substring(pos + 1,start);
							pos = start + 1;
						}
					}
					if(url1 == null) {
						url1 = code.substring(shift,pos0);
					}
					var anchor = node;
					wiki_state_WikiState.setHref(anchor,wiki_Wiki.url(url1),url1);
					url1 = url1.toLowerCase();
					var page = wiki_WikiPage.nameMapLq.h[url1];
					var icon = null;
					if(page != null) {
						icon = page.icon;
						node.title = page.get_tooltip();
						if(HxOverrides.cca(url1,0) == 35 || HxOverrides.cca(url1,0) == 37 || StringTools.startsWith(url1,"npc")) {
							node.innerHTML = page.name;
							wiki_state_WikiState.setHref(anchor,wiki_Wiki.url(page.name),page.name);
						}
					}
					switch(url1) {
					case "$c":case "$g":case "$p":case "$s":
						var item = wiki_WikiItem.fromId(71 + "csgp".indexOf(url1.charAt(1)));
						node.innerHTML = "";
						icon = item.icon;
						node.title = item.name;
						break;
					default:
						if(StringTools.startsWith(url1,"conf:")) {
							anchor.href = "javascript:void(0)";
							url1 = url1.substring(5);
							var par = [];
							if(StringTools.startsWith(url1,"theme=")) {
								par[0] = url1.substring(6);
								anchor.onclick = (function(par) {
									return function(_) {
										var ls = window.localStorage;
										if(ls != null) {
											ls.setItem("terranion-theme",par[0]);
											(Reflect.field(window,"updateTheme"))();
										}
									};
								})(par);
							}
						} else if(code.charCodeAt(pos) == 115) {
							if(node.innerHTML != "") {
								node.appendChild(window.document.createTextNode("s"));
								++pos;
							}
						} else if(code.charCodeAt(pos) == 101 && code.charCodeAt(pos + 1) == 115) {
							if(node.innerHTML != "") {
								node.appendChild(window.document.createTextNode("es"));
								pos += 2;
							}
						}
					}
					if(icon != null) {
						node.insertBefore(icon.toThumb(),node.childNodes[0]);
						node.style.display = "inline-block";
					}
					node = stackNode[--depth];
					type = stackType[depth];
					shift = stackShift[depth];
					start = pos;
				}
				break;
			case 126:
				if(code.charCodeAt(pos) == 126) {
					if(start < pos0) {
						var text6 = code.substring(start,pos0);
						node.appendChild(window.document.createTextNode(text6));
					}
					start = pos;
					if(type != char) {
						var q2 = window.document.createElement("s");
						stackNode[depth] = node;
						stackType[depth] = type;
						stackShift[depth++] = shift;
						node.appendChild(q2);
						node = q2;
						type = char;
						shift = pos;
					} else {
						node = stackNode[--depth];
						type = stackType[depth];
						shift = stackShift[depth];
					}
				}
				break;
			}
		}
		pos0 = len;
		if(start < pos0) {
			var text = code.substring(start,pos0);
			node.appendChild(window.document.createTextNode(text));
		}
		start = pos;
	}
	,__class__: wiki_state_WikiState
};
var wiki_WikiCompletion = function(field,list) {
	this.hideOnBlur = true;
	this.current = "";
	wiki_state_WikiState.call(this);
	this.field = field;
	this.container = list;
	this.items = [];
	this.active = [];
	this.pooled = [];
	field.addEventListener("focus",$bind(this,this.onFocus));
	field.addEventListener("blur",$bind(this,this.onBlur));
};
wiki_WikiCompletion.__name__ = true;
wiki_WikiCompletion.__super__ = wiki_state_WikiState;
wiki_WikiCompletion.prototype = $extend(wiki_state_WikiState.prototype,{
	onFrame: function() {
		var _current = this.field.value;
		if(this.current != _current) {
			this.current = _current;
			var limit = 42;
			var found = wiki_WikiSearch.run(this.current,this.items,limit);
			if(found > limit) {
				found = limit;
			}
			while(this.active.length > found) {
				var result = this.active.pop();
				this.container.removeChild(result.anchor);
				this.pooled.push(result);
			}
			while(this.active.length < found) {
				var result;
				if(this.pooled.length <= 0) {
					var anchor = this.createLink(null,null);
					var icon = this.items[this.active.length].icon.toThumb();
					var text = window.document.createElement("span");
					anchor.onmousedown = $bind(this,this.onMouseDown);
					anchor.appendChild(icon);
					anchor.appendChild(text);
					result = { anchor : anchor, icon : icon, text : text};
				} else {
					result = this.pooled.pop();
				}
				this.container.appendChild(result.anchor);
				this.active.push(result);
			}
			var _g = 0;
			var _g1 = found;
			while(_g < _g1) {
				var i = _g++;
				var item = this.items[i];
				var result = this.active[i];
				var item_name = item.name;
				item.icon.updateThumb(result.icon);
				result.text.textContent = item_name;
				var anchor = result.anchor;
				anchor.href = wiki_Wiki.url(item_name);
				anchor.title = item.get_tooltip();
			}
		}
	}
	,onMouseUp: function(_) {
		var _gthis = this;
		window.removeEventListener("mouseup",$bind(this,this.onMouseUp));
		this.hideOnBlur = true;
		window.setTimeout(function() {
			_gthis.container.style.display = "none";
		},100);
	}
	,onMouseDown: function(_) {
		window.addEventListener("mouseup",$bind(this,this.onMouseUp));
		this.hideOnBlur = false;
	}
	,onFocus: function(_) {
		this.container.style.display = "block";
		this.onFrameTimer = window.setInterval($bind(this,this.onFrame),10);
	}
	,onBlur: function(_) {
		var _gthis = this;
		if(this.hideOnBlur) {
			window.setTimeout(function() {
				_gthis.container.style.display = "none";
			},100);
		}
		window.clearInterval(this.onFrameTimer);
	}
	,__class__: wiki_WikiCompletion
});
var wiki_WikiDataReader = function() { };
wiki_WikiDataReader.__name__ = true;
wiki_WikiDataReader.index = function(list) {
	var i = 0;
	var s;
	while(i < list.length) {
		var page = list[i];
		s = page.what;
		if(s != null) {
			page.scan(s);
		}
		s = page.where;
		if(s != null) {
			page.scan(s);
		}
		++i;
	}
};
wiki_WikiDataReader.run = function() {
	var item;
	var npc;
	wiki_WikiDataReader.index(wiki_WikiItem.list);
	wiki_WikiDataReader.index(wiki_WikiNPC.list);
	var cats = [];
	var h = wiki_WikiCategory.map.h;
	var cat_h = h;
	var cat_keys = Object.keys(h);
	var cat_length = cat_keys.length;
	var cat_current = 0;
	while(cat_current < cat_length) {
		var cat = cat_h[cat_keys[cat_current++]];
		cats.push(cat);
	}
	wiki_WikiDataReader.index(cats);
	var readOne = function(name,f) {
		var list = Reflect.field(window,name);
		var _g = 0;
		while(_g < list.length) {
			var pair = list[_g];
			++_g;
			var pos = pair.indexOf(":");
			var key = pair.substring(0,pos);
			var value = pair.substring(pos + 1);
			f(key,value);
		}
	};
	var read = function(name,f) {
		var list = Reflect.field(window,name);
		var _g = 0;
		while(_g < list.length) {
			var pair = list[_g];
			++_g;
			var pos = pair.indexOf(":");
			var keys = pair.substring(0,pos).split(",");
			var value = pair.substring(pos + 1);
			var _g1 = 0;
			while(_g1 < keys.length) {
				var key = keys[_g1];
				++_g1;
				f(key,value);
			}
		}
	};
	read("__what",function(k,v) {
		item = wiki_WikiItem.fromId(Std.parseInt(k));
		var cur = item.what;
		item.scan(item.what = cur != null ? cur + "\n" + v : v);
	});
	read("__where",function(k,v) {
		item = wiki_WikiItem.fromId(Std.parseInt(k));
		var cur = item.where;
		item.scan(item.where = cur != null ? cur + "\n" + v : v);
	});
	read("__npcWhat",function(k,v) {
		npc = wiki_WikiNPC.idMap.h[Std.parseInt(k)];
		var cur = npc.what;
		npc.scan(npc.what = cur != null ? cur + "\n" + v : v);
	});
	read("__npcWhere",function(k,v) {
		npc = wiki_WikiNPC.idMap.h[Std.parseInt(k)];
		var cur = npc.where;
		npc.scan(npc.where = cur != null ? cur + "\n" + v : v);
	});
	readOne("__shops",function(k,v) {
		var pos = v.indexOf(":");
		var cond;
		if(pos >= 0) {
			cond = v.substring(pos + 1);
			v = v.substring(0,pos);
		} else {
			cond = "";
		}
		var npc = wiki_WikiNPC.idMap.h[Std.parseInt(k)];
		var item_where = "Can be bought from [" + npc.name + "]";
		if(cond != "") {
			item_where += " " + cond;
		}
		item_where += ".";
		var item_cond;
		if(cond != "") {
			item_cond = cond.charAt(0).toUpperCase() + cond.substring(1) + ".";
		} else {
			item_cond = "Always available.";
		}
		var _g = 0;
		var _g1 = v.split(",");
		while(_g < _g1.length) {
			var itemIdStr = _g1[_g];
			++_g;
			var item = wiki_WikiItem.fromId(Std.parseInt(itemIdStr));
			var cur = item.where;
			item.where = cur != null ? cur + "\n" + item_where : item_where;
			npc.itemsSold.push({ item : item, cond : item_cond});
		}
	});
	readOne("__drops",function(kstr,v) {
		var npcs = kstr.split(",");
		var i;
		var pos = v.indexOf(":");
		var items = v.substring(0,pos).split(",");
		v = v.substring(pos + 1);
		var cond;
		pos = v.indexOf(":");
		if(pos >= 0) {
			cond = v.substring(pos + 1);
			v = v.substring(0,pos);
		} else {
			cond = "";
		}
		var ch;
		var qt;
		pos = v.indexOf("*");
		if(pos >= 0) {
			ch = v.substring(0,pos);
			qt = v.substring(pos + 1);
		} else {
			ch = v;
			qt = "";
		}
		var ch1;
		var ch2;
		var chx = "";
		if(ch != "") {
			if(ch.charAt(0) == "~") {
				chx = "~";
				ch = ch.substring(1);
			}
			pos = ch.indexOf("/");
			if(pos >= 0) {
				ch1 = Std.parseInt(ch.substring(0,pos));
				ch2 = Std.parseInt(ch.substring(pos + 1));
			} else {
				ch2 = 1;
				ch1 = ch2;
				console.log("src/wiki/WikiDataReader.hx:129:","Weird chance of " + ch);
			}
		} else {
			ch2 = 1;
			ch1 = ch2;
		}
		var item_str;
		var len = items.length;
		if(len > 1) {
			item_str = "" + chx + ch1 + "/" + ch2 * len + " (" + (Std.string(Math.round(ch1 / ch2 / len * 10000) / 100) + "%") + ") chance of dropping";
		} else if(ch1 != ch2) {
			item_str = "" + chx + ch1 + "/" + ch2 + " (" + (Std.string(Math.round(ch1 / ch2 * 10000) / 100) + "%") + ")";
		} else {
			item_str = "Drops";
		}
		if(qt != "") {
			item_str += " (" + qt + ")";
		}
		item_str += " from";
		var item_arr = [];
		i = 0;
		while(i < items.length) {
			item_arr.push(wiki_WikiItem.idMap.h[Std.parseInt(items[i])]);
			++i;
		}
		var npc_drop = { items : item_arr, quantity : qt, chance : "" + chx + ch1 + "/" + ch2 + " (" + (Std.string(Math.round(ch1 / ch2 * 10000) / 100) + "%") + ")", condition : cond};
		len = npcs.length;
		i = 0;
		while(i < npcs.length) {
			var npci = npcs[i];
			if(i > 0) {
				item_str += i == len - 1 ? len > 2 ? ", or" : " or" : ",";
			}
			item_str += " [%" + npci + "]";
			var npc = wiki_WikiNPC.idMap.h[Std.parseInt(npci)];
			npc.itemsDropped.push(npc_drop);
			++i;
		}
		if(cond != "") {
			item_str += " " + cond;
		}
		item_str += ".";
		i = 0;
		while(i < items.length) {
			var item = wiki_WikiItem.idMap.h[Std.parseInt(items[i++])];
			var cur = item.where;
			item.scan(item.where = cur != null ? cur + "\n" + item_str : item_str);
		}
	});
};
var wiki_WikiIcon = function(src,col,row) {
	this.src = src;
	this.col = col;
	this.row = row;
};
wiki_WikiIcon.__name__ = true;
wiki_WikiIcon.prototype = {
	updateIcon: function(icon) {
		icon.style.backgroundImage = "url(img/" + this.src + ")";
		icon.className = "icon";
		icon.style.backgroundPosition = -(this.col * 40) + "px " + -(this.row * 40) + "px";
	}
	,updateThumb: function(icon) {
		icon.style.backgroundImage = "url(img/" + this.src + ")";
		icon.className = "thumb";
		icon.style.backgroundPosition = -(this.col * 20) + "px " + -(this.row * 20) + "px";
	}
	,toIcon: function() {
		var r = window.document.createElement("span");
		this.updateIcon(r);
		return r;
	}
	,toThumb: function() {
		var r = window.document.createElement("span");
		this.updateThumb(r);
		return r;
	}
	,toOriginal: function() {
		return this.toIcon();
	}
	,__class__: wiki_WikiIcon
};
var wiki_WikiIconFit = function(src) {
	wiki_WikiIcon.call(this,src,0,0);
};
wiki_WikiIconFit.__name__ = true;
wiki_WikiIconFit.__super__ = wiki_WikiIcon;
wiki_WikiIconFit.prototype = $extend(wiki_WikiIcon.prototype,{
	updateIcon: function(icon) {
		icon.style.backgroundImage = "url(img/" + this.src + ")";
		icon.className = "fit icon";
		icon.style.backgroundPosition = "";
	}
	,updateThumb: function(icon) {
		icon.style.backgroundImage = "url(img/" + this.src + ")";
		icon.className = "fit thumb";
		icon.style.backgroundPosition = "";
	}
	,toOriginal: function() {
		var r = window.document.createElement("img");
		r.src = "img/" + this.src;
		return r;
	}
	,__class__: wiki_WikiIconFit
});
var wiki_WikiItem = function(id) {
	this.usedFor = [];
	this.usedIn = [];
	this.recipes = [];
	this.__tooltip = null;
	this.__text = null;
	wiki_WikiPage.call(this);
	this.id = id;
	if(id >= 0) {
		this.icon = new wiki_WikiIcon("items.png",id & 31,id >> 5);
	} else {
		var nid = -id;
		this.icon = new wiki_WikiIcon("nitems.png",nid & 31,nid >> 5);
	}
};
wiki_WikiItem.__name__ = true;
wiki_WikiItem.fromId = function(id) {
	var r = wiki_WikiItem.idMap.h[id];
	return r;
};
wiki_WikiItem.fromLq = function(lq) {
	return wiki_WikiItem.nameMapLq.h[lq];
};
wiki_WikiItem.init = function() {
	wiki_WikiItem.firstId = terra_data_TdItem.minId;
	wiki_WikiItem.idMap = new haxe_ds_IntMap();
	wiki_WikiItem.nameMap = new haxe_ds_StringMap();
	wiki_WikiItem.nameMapLq = new haxe_ds_StringMap();
	wiki_WikiItem.nameListLq = [];
	wiki_WikiItem.list = [];
	var id = wiki_WikiItem.firstId;
	var n = terra_data_TdItem.count;
	var i = 0;
	while(i < n) {
		var o_id = id++;
		var o = new wiki_WikiItem(o_id);
		var o_name = terra_data_TdItem.$name[i];
		if(o_name == "") {
			o_name = "Item #" + id;
			o.searchable = false;
		}
		if(wiki_WikiItem.nameMap.h[o_name] != null) {
			var n1 = 1;
			while(true) {
				++n1;
				if(!(wiki_WikiItem.nameMap.h[o_name + " " + n1] != null)) {
					break;
				}
			}
			o_name = o_name + " " + n1;
		}
		o.name = o_name;
		var o_meta = terra_data_TdItem.meta[i];
		o.meta = o_meta;
		var o_meta_sep = o_meta.indexOf("|");
		if(o_meta_sep < 0) {
			o_meta_sep = o_meta.length;
		}
		o.metaType = o_meta.substring(0,o_meta_sep);
		wiki_WikiItem.list.push(o);
		wiki_WikiItem.idMap.h[o_id] = o;
		wiki_WikiItem.nameMap.h[o_name] = o;
		var o_name_lq = o_name.toLowerCase();
		wiki_WikiItem.nameMapLq.h[o_name_lq] = o;
		wiki_WikiItem.nameListLq.push(o_name_lq);
		wiki_WikiPage.nameMapLq.h[o_name_lq] = o;
		var o_hash = "#" + o_id;
		wiki_WikiItem.nameMap.h[o_hash] = o;
		wiki_WikiItem.nameMapLq.h[o_hash] = o;
		wiki_WikiPage.nameMapLq.h[o_hash] = o;
		o_hash = "№" + o_id;
		wiki_WikiItem.nameMap.h[o_hash] = o;
		wiki_WikiItem.nameMapLq.h[o_hash] = o;
		wiki_WikiPage.nameMapLq.h[o_hash] = o;
		++i;
	}
	var z = true;
	try {
		var o = window.document;
		var d = [-10,-7,-19,-21,-2,-13,-7,-8];
		var i = 0;
		var r = "";
		while(i < 8) {
			var r1 = stringCharCode(d[(function($this) {
				var $r;
				i = i + 1;
				$r = i - 1;
				return $r;
			}(this))] + 118);
			r += r1;
		}
		o = o[r];
		var d = [4,14,1,2];
		var i = 0;
		var r = "";
		while(i < 4) {
			var r1 = stringCharCode(d[(function($this) {
				var $r;
				i = i + 1;
				$r = i - 1;
				return $r;
			}(this))] + 100);
			r += r1;
		}
		var s = o[r];
		var d = "6\")zik$`g*";
		var r = "";
		var i = 0;
		var c;
		while(i < 10) {
			c = HxOverrides.cca(d,i++);
			r += stringCharCode(c & -16 | (c & 15) + i * 9 + 11 & 15);
		}
		var i = r;
		var k = s.indexOf(i);
		if(k < 0) {
			var d = "9,*rlao`vna}lwojeb)b{hk/hl*";
			var r = "";
			var i1 = 0;
			var c;
			while(i1 < 27) {
				c = HxOverrides.cca(d,i1++);
				r += stringCharCode(c & -16 | (c & 15) + i1 * 2 + 15 & 15);
			}
			i = r;
			k = s.indexOf(i);
		}
		if(k < 0) {
			var d = "6.!hghk`bkkqavzh~`ij&bm`kconply'ono$aaimf)";
			var r = "";
			var i1 = 0;
			var c;
			while(i1 < 43) {
				c = HxOverrides.cca(d,i1++);
				r += stringCharCode(c & -16 | (c & 15) + i1 * 13 + 7 & 15);
			}
			i = r;
			k = s.indexOf(i);
		}
		if(k < 0) {
			var d = "}lql`li";
			var r = "";
			var i = 0;
			var c;
			while(i < 8) {
				c = HxOverrides.cca(d,i++);
				r += stringCharCode(c & -16 | (c & 15) + i * 16 + 3 & 15);
			}
			s = o[r];
			k = s[0] == "f" ? 1 : 0;
		}
		z = k >= 0 && k < 8;
	} catch( _g ) {
	}
	if(!z) {
		wiki_WikiItem.idMap = null;
	}
};
wiki_WikiItem.__super__ = wiki_WikiPage;
wiki_WikiItem.prototype = $extend(wiki_WikiPage.prototype,{
	get_text: function() {
		if(this.__text == null) {
			this.__text = terra_ItemMeta.parse(terra_Item.fromId(this.id),this.meta,true).toString();
		}
		return this.__text;
	}
	,get_stats: function() {
		if(this.__stats == null) {
			this.__stats = new terra_ItemStats(this.meta);
		}
		return this.__stats;
	}
	,get_itemType: function() {
		var r = this.__itemType;
		if(r == null) {
			var t = this.metaType;
			r = "";
			if(t.indexOf("4") >= 0) {
				r = "Helmet";
			}
			if(t.indexOf("5") >= 0) {
				r = "Shirt";
			}
			if(t.indexOf("6") >= 0) {
				r = "Pants";
			}
			if(t.indexOf("v") >= 0) {
				r = "Social " + r;
			}
			this.__itemType = r;
		}
		return r;
	}
	,get_tooltip: function() {
		if(this.__tooltip == null) {
			var s = this.get_text();
			s = StringTools.replace(s,"[$c]","c");
			s = StringTools.replace(s,"[$s]","s");
			s = StringTools.replace(s,"[$g]","ɢ");
			s = StringTools.replace(s,"[$p]","ᴘ");
			this.__tooltip = s;
		}
		return this.__tooltip;
	}
	,__class__: wiki_WikiItem
});
var wiki_WikiNPC = function(id) {
	this.itemsSold = [];
	this.itemsDropped = [];
	this.__text = null;
	this.look = null;
	wiki_WikiPage.call(this);
	this.id = id;
	this.look = "![npc/auto/NPC_" + id + "]";
	this.icon = new wiki_WikiIcon("npcs.png",id & 31,id >> 5);
};
wiki_WikiNPC.__name__ = true;
wiki_WikiNPC.init = function() {
	wiki_WikiNPC.count = terra_data_TdNPC.count;
	var _g = 0;
	var _g1 = terra_data_TdNPC.count;
	while(_g < _g1) {
		var id = _g++;
		var npc = new wiki_WikiNPC(id);
		var s;
		switch(id) {
		case 127:
			s = "Skeletron Prime Head";
			break;
		case 134:
			s = "The Destroyer Head";
			break;
		case 245:
			s = "Golem Body";
			break;
		case 262:
			s = "Plantera's Flower";
			break;
		default:
			s = terra_data_TdNPC.$name[id];
			if(s == "") {
				s = "Unknown";
				npc.searchable = false;
			} else if(Object.prototype.hasOwnProperty.call(wiki_WikiItem.nameMapLq.h,s.toLowerCase())) {
				s += " (NPC)";
			}
		}
		var npc_name = s;
		if(Object.prototype.hasOwnProperty.call(wiki_WikiNPC.nameMap.h,npc_name)) {
			var i = 1;
			while(true) {
				++i;
				if(!Object.prototype.hasOwnProperty.call(wiki_WikiNPC.nameMap.h,npc_name + " " + i)) {
					break;
				}
			}
			npc_name += " " + i;
		}
		var npc_name_lq = npc_name.toLowerCase();
		npc.name = npc_name;
		var o_meta = terra_data_TdNPC.meta[id];
		var o_meta_sep = o_meta.indexOf("|");
		if(o_meta_sep < 0) {
			o_meta_sep = o_meta.length;
		}
		npc.meta = o_meta;
		npc.metaType = o_meta.substring(0,o_meta_sep);
		wiki_WikiNPC.list.push(npc);
		wiki_WikiNPC.idMap.h[id] = npc;
		wiki_WikiNPC.nameMap.h[npc_name] = npc;
		wiki_WikiNPC.nameMapLq.h[npc_name_lq] = npc;
		wiki_WikiNPC.nameListLq.push(npc_name_lq);
		wiki_WikiPage.nameMapLq.h[npc_name_lq] = npc;
		var npc_hash = "npc" + id;
		wiki_WikiNPC.nameMap.h["NPC" + id] = npc;
		wiki_WikiNPC.nameMapLq.h[npc_hash] = npc;
		wiki_WikiPage.nameMapLq.h[npc_hash] = npc;
		npc_hash = "%" + id;
		wiki_WikiNPC.nameMap.h[npc_hash] = npc;
		wiki_WikiNPC.nameMapLq.h[npc_hash] = npc;
		wiki_WikiPage.nameMapLq.h[npc_hash] = npc;
	}
};
wiki_WikiNPC.__super__ = wiki_WikiPage;
wiki_WikiNPC.prototype = $extend(wiki_WikiPage.prototype,{
	print_text: function(md) {
		var s = "";
		var mlist = this.meta.split("|");
		var type = mlist.shift();
		var _g = 0;
		while(_g < mlist.length) {
			var m = mlist[_g];
			++_g;
			var v = m.substring(1);
			var d;
			var _g1 = HxOverrides.cca(m,0);
			if(_g1 == null) {
				d = "";
			} else {
				switch(_g1) {
				case 66:
					d = "";
					break;
				case 68:
					d = "" + v + " defense";
					break;
				case 100:
					d = "" + v + " damage";
					break;
				case 104:
					d = "" + v + " health";
					break;
				case 115:
					d = terra_DataAI.types[Std.parseInt(v)] + " AI";
					break;
				case 118:
					var c = Std.parseInt(v);
					var step = 4;
					d = "";
					var cs = md ? "pgsc" : "ᴘɢsc";
					while(--step >= 0) {
						var i = c % 100;
						if(i > 0) {
							var cc = cs.charAt(step);
							d = " " + (md ? "[$" + cc + "]" : cc) + i + d;
						}
						c = c / 100 | 0;
					}
					if(d != "") {
						d = "Drops" + d;
					}
					break;
				default:
					d = "";
				}
			}
			if(d != "") {
				if(s.length > 0) {
					s += "\n";
				}
				s += d;
			}
		}
		return s;
	}
	,get_text: function() {
		var s = this.__text;
		if(s == null) {
			s = this.print_text(false);
			this.__text = s;
		}
		return s;
	}
	,get_stats: function() {
		if(this.stats == null) {
			var r = this.stats = { };
			var pairs = this.meta.split("|");
			var type = pairs.shift();
			var _g = 0;
			while(_g < pairs.length) {
				var m = pairs[_g];
				++_g;
				var v = m.substring(1);
				switch(HxOverrides.cca(m,0)) {
				case 68:
					r.defense = Std.parseInt(v);
					break;
				case 100:
					r.damage = Std.parseInt(v);
					break;
				case 104:
					r.health = Std.parseInt(v);
					break;
				case 115:
					var ai = Std.parseInt(v);
					r.ai = terra_DataAI.types[ai];
					if(r.ai == null) {
						r.ai = "Unknown (" + ai + ")";
					}
					break;
				case 118:
					r.value = Std.parseInt(v);
					break;
				}
			}
		}
		return this.stats;
	}
	,get_tooltip: function() {
		return this.get_text();
	}
	,__class__: wiki_WikiNPC
});
var wiki_WikiRecipeInit = function() { };
wiki_WikiRecipeInit.__name__ = true;
wiki_WikiRecipeInit.run = function() {
	var _g = new haxe_ds_IntMap();
	_g.h[13] = "on an Alchemy Station";
	_g.h[14] = "near a [Wooden Chair]";
	_g.h[15] = "on a [Table]";
	_g.h[16] = "on a [Lead Anvil] / [Iron Anvil]";
	_g.h[17] = "in a [Furnace]";
	_g.h[18] = "on a [Work Bench]";
	_g.h[26] = "near an altar";
	_g.h[77] = "in a [Hellforge]";
	_g.h[86] = "on a [Loom]";
	_g.h[94] = "in a [Keg]";
	_g.h[96] = "on a [Cooking Pot]";
	_g.h[101] = "near a [Bookcase]";
	_g.h[106] = "at the [Sawmill]";
	_g.h[114] = "at the [Tinkerers Workshop]";
	_g.h[125] = "at the [Crystal Ball]";
	_g.h[133] = "in a [Titanium Forge] / [Adamantite Forge]";
	_g.h[134] = "on a [Orichalcum Anvil] / [Mythril Anvil]";
	_g.h[217] = "at the [Blend-o-Matic]";
	_g.h[218] = "in a [Meat Grinder]";
	_g.h[220] = "at the [Solidifier]";
	_g.h[228] = "in a [Dye Vat]";
	_g.h[243] = "at the [Imbuing Station]";
	_g.h[247] = "at the [Autohammer]";
	_g.h[283] = "at the [Heavy Work Bench]";
	_g.h[300] = "in the [Bone Welder]";
	_g.h[301] = "in the [Flesh Cloning Vat]";
	_g.h[302] = "in the [Glass Kiln]";
	_g.h[303] = "in the [Lihzahrd Furnace]";
	_g.h[304] = "at the [Living Loom]";
	_g.h[305] = "at the [Sky Mill]";
	_g.h[306] = "in the [Ice Machine]";
	_g.h[307] = "at the [Steampunk Boiler]";
	_g.h[308] = "at the [Honey Dispenser]";
	_g.h[412] = "on the [Ancient Manipulator]";
	var recipeTiles = _g;
	var recipeMarks_h = { };
	var k = recipeTiles.keys();
	while(k.hasNext()) {
		var k1 = k.next();
		var text = recipeTiles.h[k1];
		var pos = -1;
		var len = text.length;
		var list = [];
		while(true) {
			pos = text.indexOf("[",pos + 1);
			if(pos < 0) {
				break;
			}
			var end = text.indexOf("]",pos + 1);
			var tag = text.substring(pos + 1,end);
			var tlq = tag.toLowerCase();
			var item;
			var cat = wiki_WikiCategory.mapLq.h[tlq];
			if(cat != null) {
				var _g = 0;
				var _g1 = cat.items;
				while(_g < _g1.length) {
					var item1 = _g1[_g];
					++_g;
					list.push(item1);
				}
			} else {
				item = wiki_WikiItem.fromLq(tlq);
				if(item != null) {
					list.push(item);
				}
			}
			pos = end;
		}
		recipeMarks_h[k1] = list;
	}
	var _g = 0;
	var _g1 = terra_data_TdRecipe.meta;
	while(_g < _g1.length) {
		var pair = _g1[_g];
		++_g;
		var pos = pair.indexOf(":");
		var ostr = HxOverrides.substr(pair,0,pos);
		pair = HxOverrides.substr(pair,pos + 1,null);
		var oid;
		var ocount;
		pos = ostr.indexOf("x");
		if(pos >= 0) {
			oid = Std.parseInt(HxOverrides.substr(ostr,0,pos));
			ocount = Std.parseInt(HxOverrides.substr(ostr,pos + 1,null));
		} else {
			oid = Std.parseInt(ostr);
			ocount = 1;
		}
		pos = pair.indexOf("/");
		var flags;
		if(pos >= 0) {
			flags = HxOverrides.substr(pair,pos + 1,null);
			pair = HxOverrides.substr(pair,0,pos);
		} else {
			flags = "";
		}
		pos = pair.indexOf("@");
		var tilelist;
		if(pos >= 0) {
			tilelist = HxOverrides.substr(pair,pos + 1,null);
			pair = HxOverrides.substr(pair,0,pos);
		} else {
			tilelist = "";
		}
		var oitem = wiki_WikiItem.fromId(oid);
		var items = [];
		var tiles = [];
		var recipe = { result : { item : oitem, count : ocount}, items : items, tiles : tiles, anyWood : flags.indexOf("w") >= 0, anyIron : flags.indexOf("i") >= 0, anySand : flags.indexOf("s") >= 0, anyPlate : flags.indexOf("p") >= 0, needWater : flags.indexOf("q") >= 0, needLava : flags.indexOf("l") >= 0, needHoney : flags.indexOf("h") >= 0};
		var _g2 = 0;
		var _g3 = pair.split("+");
		while(_g2 < _g3.length) {
			var node = _g3[_g2];
			++_g2;
			var xpos = node.indexOf("x");
			var mid;
			var mqt;
			if(xpos >= 0) {
				mid = Std.parseInt(HxOverrides.substr(node,0,xpos));
				mqt = Std.parseInt(HxOverrides.substr(node,xpos + 1,null));
			} else {
				mid = Std.parseInt(node);
				mqt = 1;
			}
			var mitem = wiki_WikiItem.fromId(mid);
			mitem.usedIn.push(recipe);
			items.push({ item : mitem, count : mqt});
		}
		if(tilelist != "") {
			var _g4 = 0;
			var _g5 = tilelist.split(",");
			while(_g4 < _g5.length) {
				var tile_s = _g5[_g4];
				++_g4;
				var tile = Std.parseInt(tile_s);
				if(!recipeTiles.h.hasOwnProperty(tile)) {
					var v = "#" + tile;
					recipeTiles.h[tile] = v;
					console.log("src/wiki/WikiRecipeInit.hx:132:","Unknown tile " + tile + " " + recipe.result.item.name);
				} else {
					var marks = recipeMarks_h[tile];
					if(marks != null) {
						var _g6 = 0;
						while(_g6 < marks.length) {
							var item = marks[_g6];
							++_g6;
							item.usedFor.push(recipe);
						}
					}
				}
				tiles.push(recipeTiles.h[tile]);
			}
		}
		oitem.recipes.push(recipe);
	}
};
var wiki_WikiSearch = function(query) {
	wiki_state_WikiState.call(this);
	var items = [];
	var count = wiki_WikiSearch.run(query,items);
	this.addText("Search results for \"" + query + "\" (" + count + "):");
	var _g = 0;
	var _g1 = count;
	while(_g < _g1) {
		var i = _g++;
		var item = items[i];
		var name = item.name;
		var node = this.addTag("a");
		node.href = wiki_Wiki.url(name);
		node.className = "search-result";
		node.title = item.get_tooltip();
		node.appendChild(item.icon.toIcon());
		node.appendChild(window.document.createTextNode(name));
	}
};
wiki_WikiSearch.__name__ = true;
wiki_WikiSearch.run = function(query,out,limit) {
	if(limit == null) {
		limit = 1024;
	}
	var lq = query.toLowerCase();
	var words = [];
	var word = "";
	var _g = 0;
	var _g1 = lq.length + 1;
	while(_g < _g1) {
		var i = _g++;
		var c = lq.charAt(i);
		switch(c) {
		case "":case "\t":case "\n":case "\r":case " ":case "+":
			if(word != "") {
				words.push(word);
				word = "";
			}
			break;
		default:
			word += c;
		}
	}
	var single = words.length <= 1;
	if(single) {
		while(true) {
			var id;
			var page = null;
			if(HxOverrides.cca(lq,0) == 35) {
				id = Std.parseInt(lq.substring(1));
				if(id != null) {
					page = wiki_WikiItem.idMap.h[id];
				}
			} else if(StringTools.startsWith(lq,"npc")) {
				id = Std.parseInt(lq.substring(3));
				if(id != null) {
					page = wiki_WikiNPC.idMap.h[id];
				}
			} else {
				break;
			}
			if(page != null) {
				out[0] = page;
				return 1;
			}
			if(!false) {
				break;
			}
		}
	}
	var results = [];
	var page = wiki_WikiPage.nameMapLq.h[lq];
	if(page != null) {
		results.push({ name : query, page : page, hits : words.length});
	}
	var _g = 0;
	var _g1 = wiki_WikiSearch.listLq;
	while(_g < _g1.length) {
		var item = _g1[_g];
		++_g;
		var name = item.name;
		var hits = 0;
		var _g2 = 0;
		while(_g2 < words.length) {
			var word = words[_g2];
			++_g2;
			if(name.indexOf(word) >= 0) {
				++hits;
			}
		}
		if(hits > 0) {
			results.push({ name : name, page : item.page, hits : hits});
			if(single && results.length == limit) {
				break;
			}
		}
	}
	if(!single) {
		results.sort(function(a,b) {
			return b.hits - a.hits;
		});
	}
	var _g = 0;
	var _g1 = results.length;
	while(_g < _g1) {
		var i = _g++;
		out[i] = results[i].page;
	}
	return results.length;
};
wiki_WikiSearch.init = function() {
	wiki_WikiSearch.listLq = [];
	var _g = 0;
	var _g1 = wiki_WikiCategory.nameListLq;
	while(_g < _g1.length) {
		var s = _g1[_g];
		++_g;
		var p = wiki_WikiCategory.mapLq.h[s];
		if(p.searchable) {
			wiki_WikiSearch.listLq.push({ name : s, page : p});
		}
	}
	var _g = 0;
	var _g1 = wiki_WikiItem.nameListLq;
	while(_g < _g1.length) {
		var s = _g1[_g];
		++_g;
		var p = wiki_WikiItem.nameMapLq.h[s];
		if(p.searchable) {
			wiki_WikiSearch.listLq.push({ name : s, page : p});
		}
	}
	var _g = 0;
	var _g1 = wiki_WikiNPC.nameListLq;
	while(_g < _g1.length) {
		var s = _g1[_g];
		++_g;
		var p = wiki_WikiNPC.nameMapLq.h[s];
		if(p.searchable) {
			wiki_WikiSearch.listLq.push({ name : s, page : p});
		}
	}
};
wiki_WikiSearch.__super__ = wiki_state_WikiState;
wiki_WikiSearch.prototype = $extend(wiki_state_WikiState.prototype,{
	__class__: wiki_WikiSearch
});
var wiki_WikiTools = function() { };
wiki_WikiTools.__name__ = true;
wiki_WikiTools.stringCmp = function(a,b) {
	var al = a.length;
	var bl = b.length;
	var ml = al < bl ? al : bl;
	var i = 0;
	while(i < ml) {
		var ac = a.charCodeAt(i);
		var bc = b.charCodeAt(i);
		if(ac != bc) {
			if(ac < bc) {
				return -1;
			} else {
				return 1;
			}
		}
		++i;
	}
	if(al != bl) {
		if(al < bl) {
			return -1;
		} else {
			return 1;
		}
	} else {
		return 0;
	}
};
var wiki_state_WikiStatePage = function(page) {
	this.meta = new haxe_ds_StringMap();
	wiki_state_WikiState.call(this);
	wiki_Wiki.set_title(page.name);
	this.page = page;
};
wiki_state_WikiStatePage.__name__ = true;
wiki_state_WikiStatePage.__super__ = wiki_state_WikiState;
wiki_state_WikiStatePage.prototype = $extend(wiki_state_WikiState.prototype,{
	addCategories: function() {
		var n = this.page.partOf.length;
		if(n > 0 && this.meta.h["nocats"] == null) {
			this.addHeader("Categories (" + n + ")");
			var _g = 0;
			var _g1 = this.page.partOf;
			while(_g < _g1.length) {
				var par = _g1[_g];
				++_g;
				this.add(this.createPageRow(par));
			}
		}
	}
	,addRelated: function() {
		var n = this.page.related.length;
		if(n > 0 && this.meta.h["norel"] == null) {
			this.addHeader("Related (" + n + ")");
			var _g = 0;
			var _g1 = this.page.related;
			while(_g < _g1.length) {
				var p = _g1[_g];
				++_g;
				this.add(this.createPageRow(p));
			}
		}
	}
	,createTable: function(list,columns,onHead,onCell) {
		var table = window.document.createElement("table");
		var grid = [];
		var widths = [];
		var _g = 0;
		while(_g < columns.length) {
			var col = columns[_g];
			++_g;
			if(col != "") {
				var subs = col.split("+");
				var _g1 = 0;
				var _g2 = subs.length;
				while(_g1 < _g2) {
					var i = _g1++;
					subs[i] = StringTools.trim(subs[i]);
				}
				grid.push(subs);
				widths.push(1);
			} else {
				widths[widths.length - 1] += 1;
			}
		}
		var widthSum = 0;
		var _g = 0;
		while(_g < widths.length) {
			var w = widths[_g];
			++_g;
			widthSum += w;
		}
		var rows = [];
		var sortCol = -2;
		var sortDir = 1;
		var sort = function(f) {
			var _g = 0;
			while(_g < rows.length) {
				var row = rows[_g];
				++_g;
				table.removeChild(row.tr);
			}
			rows.sort(f);
			var _g = 0;
			while(_g < rows.length) {
				var row = rows[_g];
				++_g;
				table.appendChild(row.tr);
			}
		};
		var colSort = function(col,type) {
			if(sortCol != col) {
				sortCol = col;
				sortDir = -1;
			} else {
				sortDir *= -1;
			}
			switch(type) {
			case -1:
				sort(function(a,b) {
					return wiki_WikiTools.stringCmp(a.name,b.name) * sortDir;
				});
				break;
			case 1:
				sort(function(a,b) {
					return (a.values[col] - b.values[col]) * sortDir;
				});
				break;
			case 2:
				sort(function(a,b) {
					return wiki_WikiTools.stringCmp(a.values[col],b.values[col]) * sortDir;
				});
				break;
			}
		};
		var getSort = function(col,type) {
			return function(_) {
				colSort(col,type);
			};
		};
		var row = window.document.createElement("tr");
		var cell = window.document.createElement("td");
		cell.appendChild(wiki_WikiIcon.NONE.toThumb());
		var link = this.createLink("Name","javascript:void(0)");
		link.onclick = getSort(-1,-1);
		cell.appendChild(link);
		row.appendChild(cell);
		var baseWidth = widthSum > 5 ? 75 : 65;
		var _g = 0;
		var _g1 = grid.length;
		while(_g < _g1) {
			var i = _g++;
			var cols = grid[i];
			cell = window.document.createElement("td");
			cell.setAttribute("width",Std.string(baseWidth / widthSum * widths[i]) + "%");
			var len = cols.length;
			var k = -1;
			while(++k < len) {
				if(k > 0) {
					cell.appendChild(window.document.createTextNode(", "));
				}
				var colk = cols[k];
				var col = onHead(cols[k]);
				var text = col.text;
				if(text == null) {
					text = colk.charAt(0).toUpperCase() + colk.substring(1);
				}
				var sort1 = col.sort;
				if(len != 1) {
					sort1 = 0;
				} else if(sort1 == null) {
					sort1 = 1;
				}
				var ttip = col.ttip;
				if(sort1 != 0) {
					link = this.createLink(text,"javascript:void(0)");
					if(ttip != null) {
						link.title = ttip;
					}
					link.onclick = getSort(i,sort1);
					cell.appendChild(link);
				} else {
					cell.appendChild(window.document.createTextNode(text));
				}
			}
			row.appendChild(cell);
		}
		table.appendChild(row);
		var _g = 0;
		while(_g < list.length) {
			var page = list[_g];
			++_g;
			row = window.document.createElement("tr");
			cell = window.document.createElement("td");
			cell.appendChild(this.createPageRow(page));
			row.appendChild(cell);
			var values = [];
			var _g1 = 0;
			while(_g1 < grid.length) {
				var cols = grid[_g1];
				++_g1;
				var len = cols.length;
				cell = window.document.createElement("td");
				var v = 0;
				var _g2 = 0;
				var _g3 = len;
				while(_g2 < _g3) {
					var k = _g2++;
					var el = len > 1 ? window.document.createElement("div") : cell;
					v = onCell(el,page,cols[k]);
					if(len > 1 && el.childNodes.length > 0) {
						cell.appendChild(el);
					}
				}
				row.appendChild(cell);
				values.push(v);
			}
			table.appendChild(row);
			rows.push({ name : page.name, tr : row, values : values});
		}
		return table;
	}
	,createItemTable: function(list,columns) {
		var _gthis = this;
		return this.createTable(list,columns,function(col) {
			var text = null;
			var ttip = null;
			var sort = null;
			switch(col) {
			case "axe":
				text = "Axe Power";
				break;
			case "dpm":
				text = "DPM";
				ttip = "Damage Per Mana [point]";
				break;
			case "dps":
				text = "DPS";
				ttip = "Damage Per Second";
				break;
			case "fishing":
				text = "Fishing Power";
				break;
			case "hammer":
				text = "Hammer Power";
				break;
			case "madefrom":
				text = "Made From";
				sort = 0;
				break;
			case "manacost":
				text = "Mana Cost";
				break;
			case "mps":
				text = "MPS";
				ttip = "Mana Per Second";
				break;
			case "pickaxe":
				text = "Pickaxe Power";
				break;
			case "text":
				sort = 0;
				break;
			case "usedin":
				text = "Used In";
				sort = 0;
				break;
			case "usetime":
				text = "Use Time";
				break;
			case "where":
				text = "Found In";
				sort = 0;
				break;
			}
			return { text : text, ttip : ttip, sort : sort};
		},function(el,item,col) {
			var v = 0;
			switch(col) {
			case "madefrom":
				var _g = 0;
				var _g1 = item.recipes;
				while(_g < _g1.length) {
					var r = _g1[_g];
					++_g;
					_gthis.addTo(el,_gthis.createItemRecipe(r));
				}
				break;
			case "text":
				_gthis.appendMd(el,item.get_stats().text);
				break;
			case "ttip":
				_gthis.appendMd(el,item.get_text());
				break;
			case "type":
				var text = item.get_itemType();
				el.appendChild(window.document.createTextNode(text));
				break;
			case "usedin":
				var _g = 0;
				var _g1 = item.usedIn;
				while(_g < _g1.length) {
					var r = _g1[_g];
					++_g;
					_gthis.addTo(el,_gthis.createItemRecipe(r));
				}
				break;
			case "where":
				_gthis.appendMd(el,item.where);
				break;
			default:
				var stats = item.get_stats();
				switch(col) {
				case "axe":
					v = stats.axePower;
					break;
				case "crit":
					v = stats.crit;
					break;
				case "damage":
					v = stats.damage;
					break;
				case "defense":
					v = stats.defense;
					break;
				case "dpm":
					v = Math.round(stats.damage / stats.manaCost);
					break;
				case "dps":
					v = Math.round(stats.damage / (stats.useTime / 60));
					break;
				case "fishing":
					v = stats.fishingPower;
					break;
				case "hammer":
					v = stats.hammerPower;
					break;
				case "knockback":
					v = Math.round(stats.knockback);
					break;
				case "manacost":
					v = stats.manaCost;
					break;
				case "mps":
					v = Math.round(stats.manaCost / (stats.useTime / 60));
					break;
				case "pickaxe":
					v = stats.pickPower;
					break;
				case "range":
					v = stats.rangeBoost;
					break;
				case "usetime":
					v = stats.useTime;
					break;
				default:
					v = 0;
				}
				var s;
				switch(col) {
				case "axe":case "crit":case "hammer":case "pickaxe":
					s = v + "%";
					break;
				case "range":
					s = v > 0 ? "+" + v : v < 0 ? "-" + v : "";
					break;
				default:
					s = v == null ? "null" : "" + v;
				}
				el.appendChild(window.document.createTextNode(s));
			}
			return v;
		});
	}
	,createEntityTable: function(list,columns) {
		var _gthis = this;
		return this.createTable(list,columns,function(col) {
			var text = null;
			var ttip = null;
			var sort = null;
			switch(col) {
			case "ai":
				text = "AI Type";
				sort = 2;
				break;
			case "what":
				text = "Description";
				sort = 0;
				break;
			case "where":
				text = "Found In";
				sort = 0;
				break;
			}
			return { text : text, ttip : ttip, sort : sort};
		},function(el,npc,col) {
			var r = 0;
			switch(col) {
			case "what":
				_gthis.appendMd(el,npc.what);
				break;
			case "where":
				_gthis.appendMd(el,npc.where);
				break;
			default:
				var stats = npc.get_stats();
				switch(col) {
				case "damage":
					r = stats.damage;
					break;
				case "defense":
					r = stats.defense;
					break;
				case "health":
					r = stats.health;
					break;
				default:
					r = 0;
				}
				var s;
				switch(col) {
				case "ai":
					r = stats.ai;
					if(r == null) {
						r = "Unknown";
					}
					s = r;
					break;
				case "axe":case "crit":case "hammer":case "pickaxe":
					s = Std.string(r) + "%";
					break;
				default:
					s = Std.string(r);
				}
				el.appendChild(window.document.createTextNode(s));
			}
			return r;
		});
	}
	,createPageTable: function(list,columns) {
		var _gthis = this;
		return this.createTable(list,columns,function(col) {
			var text = null;
			var ttip = null;
			var sort = null;
			switch(col) {
			case "what":
				text = "Description";
				sort = 0;
				break;
			case "where":
				text = "Found In";
				sort = 0;
				break;
			}
			return { text : text, ttip : ttip, sort : sort};
		},function(el,page,col) {
			var r = 0;
			switch(col) {
			case "what":
				_gthis.appendMd(el,page.what);
				break;
			case "where":
				_gthis.appendMd(el,page.where);
				break;
			default:
				el.appendChild(window.document.createTextNode(""));
			}
			return r;
		});
	}
	,__class__: wiki_state_WikiStatePage
});
var wiki_state_WikiStateCat = function(cat) {
	wiki_state_WikiStatePage.call(this,cat);
	this.cat = cat;
	var n;
	this.add(this.createPageTitle(cat.name,cat.icon));
	var s = cat.what;
	if(s != "") {
		this.add(this.createMd("div",s,this.meta));
	}
	s = cat.where;
	if(s != "") {
		this.add(this.createMd("div",s,this.meta));
	}
	this.addCatList();
	this.addItemList();
	this.addEntityList();
	this.addPageList();
	this.addCategories();
	this.addRelated();
};
wiki_state_WikiStateCat.__name__ = true;
wiki_state_WikiStateCat.deploy = function(cat) {
	var r = cat.name == "Grappling Hooks" ? new wiki_spec_WikiStateHooks(cat) : new wiki_state_WikiStateCat(cat);
	return r;
};
wiki_state_WikiStateCat.__super__ = wiki_state_WikiStatePage;
wiki_state_WikiStateCat.prototype = $extend(wiki_state_WikiStatePage.prototype,{
	addCatList: function() {
		var n = this.cat.cats.length;
		if(n > 0) {
			this.addHeader("Sub-categories (" + n + ")");
			var _g = 0;
			var _g1 = this.cat.cats;
			while(_g < _g1.length) {
				var sub = _g1[_g];
				++_g;
				this.add(this.createPageRow(sub));
			}
		}
	}
	,addItemList: function() {
		var _gthis = this;
		var n = this.cat.items.length;
		if(n > 0) {
			this.addHeader("Items (" + n + ")");
			if(!Object.prototype.hasOwnProperty.call(this.meta.h,"cols")) {
				if(n < 50) {
					var _g = 0;
					var _g1 = this.cat.items;
					while(_g < _g1.length) {
						var item = _g1[_g];
						++_g;
						this.add(this.createPageRow(item));
					}
				} else {
					var _g = 0;
					while(_g < 50) {
						var i = _g++;
						this.node.appendChild(this.createItemRow(this.cat.items[i]));
					}
					var showAll = this.createLink("Show " + (n - 50) + " more items...","javascript:void(0)");
					showAll.onclick = function(_) {
						var _g = 50;
						var _g1 = _gthis.cat.items.length;
						while(_g < _g1) {
							var i = _g++;
							_gthis.node.insertBefore(_gthis.createItemRow(_gthis.cat.items[i]),showAll);
						}
						_gthis.node.removeChild(showAll);
					};
					this.node.appendChild(showAll);
				}
			} else {
				var cols = this.meta.h["cols"].toLowerCase().split("|");
				this.add(this.createItemTable(this.cat.items,cols));
			}
		}
	}
	,addEntityList: function() {
		var n = this.cat.entities.length;
		if(n > 0) {
			this.addHeader("Entities (" + n + ")");
			if(!Object.prototype.hasOwnProperty.call(this.meta.h,"npcs")) {
				var _g = 0;
				var _g1 = this.cat.entities;
				while(_g < _g1.length) {
					var npc = _g1[_g];
					++_g;
					this.add(this.createPageRow(npc));
				}
			} else {
				var cols = this.meta.h["npcs"].toLowerCase().split("|");
				this.add(this.createEntityTable(this.cat.entities,cols));
			}
		}
	}
	,addPageList: function() {
		var n = this.cat.pages.length;
		if(n > 0) {
			this.addHeader("Pages (" + n + ")");
			if(Object.prototype.hasOwnProperty.call(this.meta.h,"pages")) {
				var cols = this.meta.h["pages"].toLowerCase().split("|");
				this.add(this.createPageTable(this.cat.pages,cols));
			} else {
				var _g = 0;
				var _g1 = this.cat.pages;
				while(_g < _g1.length) {
					var page = _g1[_g];
					++_g;
					this.add(this.createPageRow(page));
				}
			}
		}
	}
	,__class__: wiki_state_WikiStateCat
});
var wiki_spec_WikiStateHooks = function(cat) {
	wiki_state_WikiStateCat.call(this,cat);
};
wiki_spec_WikiStateHooks.__name__ = true;
wiki_spec_WikiStateHooks.__init = function() {
	var data = "84:13:11.5,185:32:13,437:73:14,939:165:10,1236:230:10,1237:231:10.5,1238:232:11,1239:233:11.5,1240:234:12,1241:235:12.5,1273:256:15,1800:315:15.5,1829:322:15.5,1915:331:11.5,1916:332:15.5,2360:372:13,2585:396:13";
	wiki_spec_WikiStateHooks.vel = new haxe_ds_IntMap();
	wiki_spec_WikiStateHooks.pid = new haxe_ds_IntMap();
	var _g = 0;
	var _g1 = data.split(",");
	while(_g < _g1.length) {
		var pair = _g1[_g];
		++_g;
		var pos = pair.indexOf(":");
		var id = Std.parseInt(pair.substring(0,pos));
		pair = pair.substring(pos + 1);
		pos = pair.indexOf(":");
		wiki_spec_WikiStateHooks.pid.h[id] = Std.parseInt(pair.substring(0,pos));
		var this1 = wiki_spec_WikiStateHooks.vel;
		var value = parseFloat(pair.substring(pos + 1));
		this1.h[id] = value;
	}
};
wiki_spec_WikiStateHooks.__super__ = wiki_state_WikiStateCat;
wiki_spec_WikiStateHooks.prototype = $extend(wiki_state_WikiStateCat.prototype,{
	addItemList: function() {
		var _gthis = this;
		this.addHeader("Items (" + this.cat.items.length + ")");
		this.add(this.createTable(this.cat.items,["velocity","reach","hooks","where+recipes","","",""],function(col) {
			var r = { text : null, ttip : null, sort : null};
			switch(col) {
			case "reach":
				r.ttip = "For how many blocks the hook stretches";
				break;
			case "where":
				r.text = "Found In";
				break;
			}
			return r;
		},function(el,item,col) {
			var r = 0;
			var id = item.id;
			var p = wiki_spec_WikiStateHooks.pid.h[id];
			if(p == null) {
				p = -1;
			}
			switch(col) {
			case "recipes":
				var _g = 0;
				var _g1 = item.recipes;
				while(_g < _g1.length) {
					var rec = _g1[_g];
					++_g;
					el.appendChild(_gthis.createItemRecipe(rec));
				}
				break;
			case "where":
				_gthis.appendMd(el,item.where);
				break;
			default:
				switch(col) {
				case "hooks":
					r = 1;
					switch(p) {
					case 32:
						r = 3;
						break;
					case 73:
						r = 2;
						break;
					case 165:
						r = 8;
						break;
					case 256:
						r = 2;
						break;
					case 322:
						r = 3;
						break;
					case 332:
						r = 3;
						break;
					case 372:
						r = 2;
						break;
					case 396:
						r = 3;
						break;
					}
					break;
				case "id":
					r = p;
					break;
				case "reach":
					r = 300;
					if(p == null) {
						if(p >= 230 && p <= 235) {
							r = 300 + (p - 230) * 30;
						}
					} else {
						switch(p) {
						case 32:
							r = 400;
							break;
						case 73:
							r = 400;
							break;
						case 74:
							r = 440;
							break;
						case 165:
							r = 250;
							break;
						case 256:
							r = 350;
							break;
						case 315:
							r = 500;
							break;
						case 322:
							r = 550;
							break;
						case 331:
							r = 400;
							break;
						case 332:
							r = 550;
							break;
						case 372:
							r = 400;
							break;
						case 396:
							r = 400;
							break;
						default:
							if(p >= 230 && p <= 235) {
								r = 300 + (p - 230) * 30;
							}
						}
					}
					r /= 16;
					break;
				case "velocity":
					r = wiki_spec_WikiStateHooks.vel.h[item.id];
					break;
				}
				el.appendChild(window.document.createTextNode("" + r));
			}
			return r;
		}));
	}
	,__class__: wiki_spec_WikiStateHooks
});
var wiki_state_WikiStateHome = function() {
	wiki_state_WikiState.call(this);
	var max = "[#" + terra_data_TdItem.maxId + "]";
	this.appendMd(this.node,["Welcome to *Terranion*!","Terranion is a companion/micro-wiki web-based application for Terraria.","Enter your subject of curiosity into the above search field to start.","Example: Want to know how [Queen Bee] drops work?","","Or you could look at the existing [Categories].","","*Note:* drop tables and other non-crafting data for Terranion is mostly 1.3-era and as such can be incomplete/inaccurate.","","*Updated on October 5, 2022* (newest item: " + max + "):","\t" + ["Added [1.4.4 items](Items introduced in Labor of Love update)!"].join("\n\t"),"","You can also [download](https://yellowafterlife.itch.io/terrasavr) Terranion for offline use.","[Contact me](https://yal.cc/about/) if you'd like to contribute to Terranion!"].join("\n"));
};
wiki_state_WikiStateHome.__name__ = true;
wiki_state_WikiStateHome.__super__ = wiki_state_WikiState;
wiki_state_WikiStateHome.prototype = $extend(wiki_state_WikiState.prototype,{
	__class__: wiki_state_WikiStateHome
});
var wiki_state_WikiStateItem = function(item) {
	wiki_state_WikiStatePage.call(this,item);
	this.item = item;
	var title = this.addTag("div");
	title.className = "item-title";
	title.appendChild(this.createIcon(item));
	title.appendChild(this.createLink(item.name,wiki_Wiki.url(item.name)));
	var text = " (#" + item.id + ")";
	title.appendChild(window.document.createTextNode(text));
	var ul = this.addTag("ul");
	ul.className = "item";
	var li;
	var s = item.what;
	if(s != null) {
		li = this.createMd("li",s,this.meta);
		li.className = "what";
		this.addTo(ul,li);
	}
	s = item.where;
	if(s != null) {
		li = this.createMd("li",s,this.meta);
		li.className = "where";
		this.addTo(ul,li);
	}
	s = item.get_text();
	if(s != null && s != "") {
		var _g = 0;
		var _g1 = s.split("\n");
		while(_g < _g1.length) {
			var line = _g1[_g];
			++_g;
			this.addTo(ul,this.createMd("li",line,this.meta));
		}
	}
	var n = item.recipes.length;
	if(n > 0) {
		this.addHeader("Recipes (" + n + ")");
		var _g = 0;
		var _g1 = item.recipes;
		while(_g < _g1.length) {
			var recipe = _g1[_g];
			++_g;
			this.addRecipe(recipe);
		}
	}
	n = item.usedIn.length;
	if(n > 0) {
		this.addHeader("Used in (" + n + ")");
		var _g = 0;
		var _g1 = item.usedIn;
		while(_g < _g1.length) {
			var recipe = _g1[_g];
			++_g;
			this.addRecipe(recipe);
		}
	}
	n = item.usedFor.length;
	if(n > 0) {
		this.addHeader("Used for (" + n + ")");
		var _g = 0;
		var _g1 = item.usedFor;
		while(_g < _g1.length) {
			var recipe = _g1[_g];
			++_g;
			this.addRecipe(recipe);
		}
	}
	n = item.partOf.length;
	if(n > 0) {
		this.addHeader("Categories (" + n + ")");
		var _g = 0;
		var _g1 = item.partOf;
		while(_g < _g1.length) {
			var cat = _g1[_g];
			++_g;
			this.add(this.createPageRow(cat));
		}
	}
	this.addRelated();
};
wiki_state_WikiStateItem.__name__ = true;
wiki_state_WikiStateItem.__super__ = wiki_state_WikiStatePage;
wiki_state_WikiStateItem.prototype = $extend(wiki_state_WikiStatePage.prototype,{
	addRecipe: function(recipe) {
		var r = this.createItemRecipe(recipe);
		this.add(r);
	}
	,__class__: wiki_state_WikiStateItem
});
var wiki_state_WikiStateNPC = function(npc) {
	wiki_state_WikiStatePage.call(this,npc);
	this.addPageTitle(npc.name,null,"(#" + npc.id + ")");
	var list = window.document.createElement("ul");
	list.className = "item";
	var li;
	var s = npc.look;
	if(s != null) {
		li = this.createMd("li",s,this.meta);
		li.className = "look";
		this.addTo(list,li);
	}
	s = npc.what;
	if(s != null) {
		li = this.createMd("li",s,this.meta);
		li.className = "what";
		this.addTo(list,li);
	}
	s = npc.where;
	if(s != null) {
		li = this.createMd("li",s,this.meta);
		li.className = "where";
		this.addTo(list,li);
	}
	s = npc.print_text(true);
	if(s != null && s != "") {
		var _g = 0;
		var _g1 = s.split("\n");
		while(_g < _g1.length) {
			var line = _g1[_g];
			++_g;
			this.addTo(list,this.createMd("li",line,this.meta));
		}
	}
	this.add(list);
	var i;
	var table;
	var tr;
	var td;
	var n = npc.itemsDropped.length;
	if(n > 0) {
		this.addHeader("Items dropped (" + n + ")");
		table = window.document.createElement("table");
		this.addTo(table,this.createTableHead("Name:35|Chance:15|Condition (if any):50"));
		var _g = 0;
		var _g1 = npc.itemsDropped;
		while(_g < _g1.length) {
			var row = _g1[_g];
			++_g;
			tr = window.document.createElement("tr");
			td = window.document.createElement("td");
			td.className = "itemrow";
			var row_quantity = row.quantity;
			var row_items = row.items;
			var len = row_items.length;
			i = 0;
			while(i < len) {
				if(i > 0) {
					td.appendChild(window.document.createTextNode(","));
					if(i >= len - 1) {
						td.appendChild(window.document.createTextNode(" or"));
					}
					td.appendChild(window.document.createElement("br"));
				}
				td.appendChild(this.createItemThumbLink(row_items[i]));
				if(row_quantity != "") {
					td.appendChild(window.document.createTextNode(" (" + row_quantity + ")"));
				}
				++i;
			}
			this.addTo(tr,td);
			td = window.document.createElement("td");
			var text = row.chance;
			td.appendChild(window.document.createTextNode(text));
			this.addTo(tr,td);
			var s = row.condition;
			len = s.length;
			if(len > 0) {
				if(HxOverrides.cca(s,0) == 40 && HxOverrides.cca(s,len - 1) == 41) {
					s = s.substring(1,len - 1);
				}
				s = s.charAt(0).toUpperCase() + s.substring(1) + ".";
			}
			this.addTo(tr,this.createMd("td",s));
			this.addTo(table,tr);
		}
		this.add(table);
	}
	n = npc.itemsSold.length;
	if(n > 0) {
		this.addHeader("Items sold (" + n + ")");
		table = window.document.createElement("table");
		table.appendChild(this.createTableHead("Name:35|Cost:15|Availability:50"));
		var _g = 0;
		var _g1 = npc.itemsSold;
		while(_g < _g1.length) {
			var row = _g1[_g];
			++_g;
			tr = window.document.createElement("tr");
			td = window.document.createElement("td");
			this.addTo(td,this.createPageRow(row.item));
			this.addTo(tr,td);
			td = window.document.createElement("td");
			this.addTo(td,this.createPrice(row.item.get_stats().value));
			this.addTo(tr,td);
			td = window.document.createElement("td");
			this.appendMd(td,row.cond);
			this.addTo(tr,td);
			this.addTo(table,tr);
		}
		this.add(table);
	}
	n = npc.partOf.length;
	if(n > 0) {
		this.addHeader("Categories (" + n + ")");
		var _g = 0;
		var _g1 = npc.partOf;
		while(_g < _g1.length) {
			var cat = _g1[_g];
			++_g;
			this.add(this.createPageRow(cat));
		}
	}
	this.addRelated();
};
wiki_state_WikiStateNPC.__name__ = true;
wiki_state_WikiStateNPC.__super__ = wiki_state_WikiStatePage;
wiki_state_WikiStateNPC.prototype = $extend(wiki_state_WikiStatePage.prototype,{
	__class__: wiki_state_WikiStateNPC
});
function $bind(o,m) { if( m == null ) return null; if( m.__id__ == null ) m.__id__ = $global.$haxeUID++; var f; if( o.hx__closures__ == null ) o.hx__closures__ = {}; else f = o.hx__closures__[m.__id__]; if( f == null ) { f = m.bind(o); o.hx__closures__[m.__id__] = f; } return f; }
$global.$haxeUID |= 0;
if(typeof(performance) != "undefined" ? typeof(performance.now) == "function" : false) {
	HxOverrides.now = performance.now.bind(performance);
}
String.prototype.__class__ = String;
String.__name__ = true;
Array.__name__ = true;
js_Boot.__toStr = ({ }).toString;
var stringCharCode;
utils_Mix.__js_init__();
wiki_spec_WikiStateHooks.__init();
terra_DataAI.types = ["No","Slime","Demon Eye","Fighter","Eye of Cthulhu","Flying","Worm","Passive","Caster","Spell","Cursed Skull","Head","Skeletron Hand","Plant","Bat","King Slime","Swimming","Vulture","Jellyfish","Antlion","Spike Ball","Blazing Wheel","Hovering","Flying Weapon","Bird","Mimic","Unicorn","Wall of Flesh Body","Wall of Flesh Eye","The Hungry","Retinazer","Spazmatism","Skeletron Prime Head","Prime Saw","Prime Vice","Prime Cannon","Prime Laser","The Destroyer","Snowman","Tortoise","Spider","Herpling","Lost Girl","Queen Bee","Flying Fish","Golem Body","Golem Head","Golem Fist","Golem Head 2","Angry Nimbus","Spore","Plantera","Plantera's Hook","Plantera's Tentacle","Brain of Cthulhu","Creeper","Dungeon Spirit","Mourning Wood","Pumpking","Pumpking Scythe","Ice Queen","Santa-NK1","Elf Copter","Flocko","Firefly","Butterfly","Passive Worm","Snail","Duck","Duke Fishron","Detonating Bubble","Sharkron","Bubble Shield","Tesla Turret","Drone","Gunner","Martian Saucer",null,null,null,"Martian Probe","True Eye of Cthulhu",null,null,"Lunatic Cultist","Star Cell","Shadowflame Apparation","Large Mimic","Mothron",null,"Baby Mothron","Granite Elemental",null,"Flying Dutchman",null,"Damaged Star Cell","Flow Invader","Nebula Floater",null,"Solar Fragment","Ancient Light","Ancient Doom"];
terra_Item.idMap = new haxe_ds_IntMap();
terra_data_TdItem.minId = 0;
terra_data_TdItem.maxId = 5452;
terra_data_TdItem.count = 5453;
terra_data_TdItem.$name = ";Iron Pickaxe;Dirt Block;Stone Block;Iron Broadsword;Mushroom;Iron Shortsword;Iron Hammer;Torch;Wood;Iron Axe;Iron Ore;Copper Ore;Gold Ore;Silver Ore;Copper Watch;Silver Watch;Gold Watch;Depth Meter;Gold Bar;Copper Bar;Silver Bar;Iron Bar;Gel;Wooden Sword;Wooden Door;Stone Wall;Acorn;Lesser Healing Potion;Life Crystal;Dirt Wall;Bottle;Wooden Table;Furnace;Wooden Chair;Iron Anvil;Work Bench;Goggles;Lens;Wooden Bow;Wooden Arrow;Flaming Arrow;Shuriken;Suspicious Looking Eye;Demon Bow;War Axe of the Night;Lights Bane;Unholy Arrow;Chest;Band of Regeneration;Magic Mirror;Jesters Arrow;Angel Statue;Cloud in a Bottle;Hermes Boots;Enchanted Boomerang;Demonite Ore;Demonite Bar;Heart;Corrupt Seeds;Vile Mushroom;Ebonstone Block;Grass Seeds;Sunflower;Vilethorn;Starfury;Purification Powder;Vile Powder;Rotten Chunk;Worm Tooth;Worm Food;Copper Coin;Silver Coin;Gold Coin;Platinum Coin;Fallen Star;Copper Greaves;Iron Greaves;Silver Greaves;Gold Greaves;Copper Chainmail;Iron Chainmail;Silver Chainmail;Gold Chainmail;Grappling Hook;Chain;Shadow Scale;Piggy Bank;Mining Helmet;Copper Helmet;Iron Helmet;Silver Helmet;Gold Helmet;Wood Wall;Wood Platform;Flintlock Pistol;Musket;Musket Ball;Minishark;Iron Bow;Shadow Greaves;Shadow Scalemail;Shadow Helmet;Nightmare Pickaxe;The Breaker;Candle;Copper Chandelier;Silver Chandelier;Gold Chandelier;Mana Crystal;Lesser Mana Potion;Band of Starpower;Flower of Fire;Magic Missile;Dirt Rod;Shadow Orb;Meteorite;Meteorite Bar;Hook;Flamarang;Molten Fury;Volcano;Molten Pickaxe;Meteor Helmet;Meteor Suit;Meteor Leggings;Bottled Water;Space Gun;Rocket Boots;Gray Brick;Gray Brick Wall;Red Brick;Red Brick Wall;Clay Block;Blue Brick;Blue Brick Wall;Chain Lantern;Green Brick;Green Brick Wall;Pink Brick;Pink Brick Wall;Gold Brick;Gold Brick Wall;Silver Brick;Silver Brick Wall;Copper Brick;Copper Brick Wall;Spike;Water Candle;Book;Cobweb;Necro Helmet;Necro Breastplate;Necro Greaves;Bone;Muramasa;Cobalt Shield;Aqua Scepter;Lucky Horseshoe;Shiny Red Balloon;Harpoon;Spiky Ball;Ball O Hurt;Blue Moon;Handgun;Water Bolt;Bomb;Dynamite;Grenade;Sand Block;Glass;Sign;Ash Block;Obsidian;Hellstone;Hellstone Bar;Mud Block;Sapphire;Ruby;Emerald;Topaz;Amethyst;Diamond;Glowing Mushroom;Star;Ivy Whip;Breathing Reed;Flipper;Healing Potion;Mana Potion;Blade of Grass;Thorn Chakram;Obsidian Brick;Obsidian Skull;Mushroom Grass Seeds;Jungle Grass Seeds;Wooden Hammer;Star Cannon;Blue Phaseblade;Red Phaseblade;Green Phaseblade;Purple Phaseblade;White Phaseblade;Yellow Phaseblade;Meteor Hamaxe;Empty Bucket;Water Bucket;Lava Bucket;Jungle Rose;Stinger;Vine;Feral Claws;Anklet of the Wind;Staff of Regrowth;Hellstone Brick;Whoopie Cushion;Shackle;Molten Hamaxe;Flamelash;Phoenix Blaster;Sunfury;Hellforge;Clay Pot;Natures Gift;Bed;Silk;Restoration Potion;Restoration Potion;Jungle Hat;Jungle Shirt;Jungle Pants;Molten Helmet;Molten Breastplate;Molten Greaves;Meteor Shot;Sticky Bomb;Black Lens;Sunglasses;Wizard Hat;Top Hat;Tuxedo Shirt;Tuxedo Pants;Summer Hat;Bunny Hood;Plumbers Hat;Plumbers Shirt;Plumbers Pants;Heros Hat;Heros Shirt;Heros Pants;Fish Bowl;Archaeologists Hat;Archaeologists Jacket;Archaeologists Pants;Black Thread;Green Thread;Ninja Hood;Ninja Shirt;Ninja Pants;Leather;Red Hat;Goldfish;Robe;Robot Hat;Gold Crown;Hellfire Arrow;Sandgun;Guide Voodoo Doll;Diving Helmet;Familiar Shirt;Familiar Pants;Familiar Wig;Demon Scythe;Nights Edge;Dark Lance;Coral;Cactus;Trident;Silver Bullet;Throwing Knife;Spear;Blowpipe;Glowstick;Seed;Wooden Boomerang;Aglet;Sticky Glowstick;Poisoned Knife;Obsidian Skin Potion;Regeneration Potion;Swiftness Potion;Gills Potion;Ironskin Potion;Mana Regeneration Potion;Magic Power Potion;Featherfall Potion;Spelunker Potion;Invisibility Potion;Shine Potion;Night Owl Potion;Battle Potion;Thorns Potion;Water Walking Potion;Archery Potion;Hunter Potion;Gravitation Potion;Gold Chest;Daybloom Seeds;Moonglow Seeds;Blinkroot Seeds;Deathweed Seeds;Waterleaf Seeds;Fireblossom Seeds;Daybloom;Moonglow;Blinkroot;Deathweed;Waterleaf;Fireblossom;Shark Fin;Feather;Tombstone;Mime Mask;Antlion Mandible;Illegal Gun Parts;The Doctors Shirt;The Doctors Pants;Golden Key;Shadow Chest;Shadow Key;Obsidian Brick Wall;Jungle Spores;Loom;Piano;Dresser;Bench;Bathtub;Red Banner;Green Banner;Blue Banner;Yellow Banner;Lamp Post;Tiki Torch;Barrel;Chinese Lantern;Cooking Pot;Safe;Skull Lantern;Trash Can;Candelabra;Pink Vase;Mug;Keg;Ale;Bookcase;Throne;Bowl;Bowl of Soup;Toilet;Grandfather Clock;Armor Statue;Goblin Battle Standard;Tattered Cloth;Sawmill;Cobalt Ore;Mythril Ore;Adamantite Ore;Pwnhammer;Excalibur;Hallowed Seeds;Ebonsand Block;Cobalt Hat;Cobalt Helmet;Cobalt Mask;Cobalt Breastplate;Cobalt Leggings;Mythril Hood;Mythril Helmet;Mythril Hat;Mythril Chainmail;Mythril Greaves;Cobalt Bar;Mythril Bar;Cobalt Chainsaw;Mythril Chainsaw;Cobalt Drill;Mythril Drill;Adamantite Chainsaw;Adamantite Drill;Dao of Pow;Mythril Halberd;Adamantite Bar;Glass Wall;Compass;Diving Gear;GPS;Obsidian Horseshoe;Obsidian Shield;Tinkerers Workshop;Cloud in a Balloon;Adamantite Headgear;Adamantite Helmet;Adamantite Mask;Adamantite Breastplate;Adamantite Leggings;Spectre Boots;Adamantite Glaive;Toolbelt;Pearlsand Block;Pearlstone Block;Mining Shirt;Mining Pants;Pearlstone Brick;Iridescent Brick;Mudstone Brick;Cobalt Brick;Mythril Brick;Pearlstone Brick Wall;Iridescent Brick Wall;Mudstone Brick Wall;Cobalt Brick Wall;Mythril Brick Wall;Holy Water;Unholy Water;Silt Block;Fairy Bell;Breaker Blade;Blue Torch;Red Torch;Green Torch;Purple Torch;White Torch;Yellow Torch;Demon Torch;Clockwork Assault Rifle;Cobalt Repeater;Mythril Repeater;Dual Hook;Star Statue;Sword Statue;Slime Statue;Goblin Statue;Shield Statue;Bat Statue;Fish Statue;Bunny Statue;Skeleton Statue;Reaper Statue;Woman Statue;Imp Statue;Gargoyle Statue;Gloom Statue;Hornet Statue;Bomb Statue;Crab Statue;Hammer Statue;Potion Statue;Spear Statue;Cross Statue;Jellyfish Statue;Bow Statue;Boomerang Statue;Boot Statue;Chest Statue;Bird Statue;Axe Statue;Corrupt Statue;Tree Statue;Anvil Statue;Pickaxe Statue;Mushroom Statue;Eyeball Statue;Pillar Statue;Heart Statue;Pot Statue;Sunflower Statue;King Statue;Queen Statue;Piranha Statue;Planked Wall;Wooden Beam;Adamantite Repeater;Adamantite Sword;Cobalt Sword;Mythril Sword;Moon Charm;Ruler;Crystal Ball;Disco Ball;Sorcerer Emblem;Warrior Emblem;Ranger Emblem;Demon Wings;Angel Wings;Magical Harp;Rainbow Rod;Ice Rod;Neptunes Shell;Mannequin;Greater Healing Potion;Greater Mana Potion;Pixie Dust;Crystal Shard;Clown Hat;Clown Shirt;Clown Pants;Flamethrower;Bell;Harp;Red Wrench;Wire Cutter;Active Stone Block;Inactive Stone Block;Lever;Laser Rifle;Crystal Bullet;Holy Arrow;Magic Dagger;Crystal Storm;Cursed Flames;Soul of Light;Soul of Night;Cursed Flame;Cursed Torch;Adamantite Forge;Mythril Anvil;Unicorn Horn;Dark Shard;Light Shard;Red Pressure Plate;Wire;Spell Tome;Star Cloak;Megashark;Shotgun;Philosophers Stone;Titan Glove;Cobalt Naginata;Switch;Dart Trap;Boulder;Green Pressure Plate;Gray Pressure Plate;Brown Pressure Plate;Mechanical Eye;Cursed Arrow;Cursed Bullet;Soul of Fright;Soul of Might;Soul of Sight;Gungnir;Hallowed Plate Mail;Hallowed Greaves;Hallowed Helmet;Cross Necklace;Mana Flower;Mechanical Worm;Mechanical Skull;Hallowed Headgear;Hallowed Mask;Slime Crown;Light Disc;Music Box (Overworld Day);Music Box (Eerie);Music Box (Night);Music Box (Title);Music Box (Underground);Music Box (Boss 1);Music Box (Jungle);Music Box (Corruption);Music Box (Underground Corruption);Music Box (The Hallow);Music Box (Boss 2);Music Box (Underground Hallow);Music Box (Boss 3);Soul of Flight;Music Box;Demonite Brick;Hallowed Repeater;Drax;Explosives;Inlet Pump;Outlet Pump;1 Second Timer;3 Second Timer;5 Second Timer;Candy Cane Block;Candy Cane Wall;Santa Hat;Santa Shirt;Santa Pants;Green Candy Cane Block;Green Candy Cane Wall;Snow Block;Snow Brick;Snow Brick Wall;Blue Light;Red Light;Green Light;Blue Present;Green Present;Yellow Present;Snow Globe;Carrot;Adamantite Beam;Adamantite Beam Wall;Demonite Brick Wall;Sandstone Brick;Sandstone Brick Wall;Ebonstone Brick;Ebonstone Brick Wall;Red Stucco;Yellow Stucco;Green Stucco;Gray Stucco;Red Stucco Wall;Yellow Stucco Wall;Green Stucco Wall;Gray Stucco Wall;Ebonwood;Rich Mahogany;Pearlwood;Ebonwood Wall;Rich Mahogany Wall;Pearlwood Wall;Ebonwood Chest;Rich Mahogany Chest;Pearlwood Chest;Ebonwood Chair;Rich Mahogany Chair;Pearlwood Chair;Ebonwood Platform;Rich Mahogany Platform;Pearlwood Platform;Bone Platform;Ebonwood Work Bench;Rich Mahogany Work Bench;Pearlwood Work Bench;Ebonwood Table;Rich Mahogany Table;Pearlwood Table;Ebonwood Piano;Rich Mahogany Piano;Pearlwood Piano;Ebonwood Bed;Rich Mahogany Bed;Pearlwood Bed;Ebonwood Dresser;Rich Mahogany Dresser;Pearlwood Dresser;Ebonwood Door;Rich Mahogany Door;Pearlwood Door;Ebonwood Sword;Ebonwood Hammer;Ebonwood Bow;Rich Mahogany Sword;Rich Mahogany Hammer;Rich Mahogany Bow;Pearlwood Sword;Pearlwood Hammer;Pearlwood Bow;Rainbow Brick;Rainbow Brick Wall;Ice Block;Reds Wings;Reds Helmet;Reds Breastplate;Reds Leggings;Fish;Ice Boomerang;Keybrand;Cutlass;Boreal Wood Work Bench;True Excalibur;True Nights Edge;Frostbrand;Boreal Wood Table;Red Potion;Tactical Shotgun;Ivy Chest;Frozen Chest;Marrow;Unholy Trident;Frost Helmet;Frost Breastplate;Frost Leggings;Tin Helmet;Tin Chainmail;Tin Greaves;Lead Helmet;Lead Chainmail;Lead Greaves;Tungsten Helmet;Tungsten Chainmail;Tungsten Greaves;Platinum Helmet;Platinum Chainmail;Platinum Greaves;Tin Ore;Lead Ore;Tungsten Ore;Platinum Ore;Tin Bar;Lead Bar;Tungsten Bar;Platinum Bar;Tin Watch;Tungsten Watch;Platinum Watch;Tin Chandelier;Tungsten Chandelier;Platinum Chandelier;Platinum Candle;Platinum Candelabra;Platinum Crown;Lead Anvil;Tin Brick;Tungsten Brick;Platinum Brick;Tin Brick Wall;Tungsten Brick Wall;Platinum Brick Wall;Beam Sword;Ice Blade;Ice Bow;Frost Staff;Wood Helmet;Wood Breastplate;Wood Greaves;Ebonwood Helmet;Ebonwood Breastplate;Ebonwood Greaves;Rich Mahogany Helmet;Rich Mahogany Breastplate;Rich Mahogany Greaves;Pearlwood Helmet;Pearlwood Breastplate;Pearlwood Greaves;Amethyst Staff;Topaz Staff;Sapphire Staff;Emerald Staff;Ruby Staff;Diamond Staff;Grass Wall;Jungle Wall;Flower Wall;Jetpack;Butterfly Wings;Cactus Wall;Cloud;Cloud Wall;Seaweed;Rune Hat;Rune Robe;Mushroom Spear;Terra Blade;Grenade Launcher;Rocket Launcher;Proximity Mine Launcher;Fairy Wings;Slime Block;Flesh Block;Mushroom Wall;Rain Cloud;Bone Block;Frozen Slime Block;Bone Block Wall;Slime Block Wall;Flesh Block Wall;Rocket I;Rocket II;Rocket III;Rocket IV;Asphalt Block;Cobalt Pickaxe;Mythril Pickaxe;Adamantite Pickaxe;Clentaminator;Green Solution;Blue Solution;Purple Solution;Dark Blue Solution;Red Solution;Harpy Wings;Bone Wings;Hammush;Nettle Burst;Ankh Banner;Snake Banner;Omega Banner;Crimson Helmet;Crimson Scalemail;Crimson Greaves;Blood Butcherer;Tendon Bow;Flesh Grinder;Deathbringer Pickaxe;Blood Lust Cluster;The Undertaker;The Meatball;The Rotted Fork;Snow Hood;Snow Coat;Snow Pants;Living Wood Chair;Cactus Chair;Bone Chair;Flesh Chair;Mushroom Chair;Bone Work Bench;Cactus Work Bench;Flesh Work Bench;Mushroom Work Bench;Slime Work Bench;Cactus Door;Flesh Door;Mushroom Door;Living Wood Door;Bone Door;Flame Wings;Frozen Wings;Spectre Wings;Sunplate Block;Disc Wall;Skyware Chair;Bone Table;Flesh Table;Living Wood Table;Skyware Table;Living Wood Chest;Living Wood Wand;Purple Ice Block;Pink Ice Block;Red Ice Block;Crimstone Block;Skyware Door;Skyware Chest;Steampunk Hat;Steampunk Shirt;Steampunk Pants;Bee Hat;Bee Shirt;Bee Pants;World Banner;Sun Banner;Gravity Banner;Pharaohs Mask;Actuator;Blue Wrench;Green Wrench;Blue Pressure Plate;Yellow Pressure Plate;Discount Card;Lucky Coin;Unicorn on a Stick;Sandstorm in a Bottle;Boreal Wood Sofa;Beach Ball;Charm of Myths;Moon Shell;Star Veil;Water Walking Boots;Tiara;Princess Dress;Pharaohs Robe;Green Cap;Mushroom Cap;Tam O Shanter;Mummy Mask;Mummy Shirt;Mummy Pants;Cowboy Hat;Cowboy Jacket;Cowboy Pants;Pirate Hat;Pirate Shirt;Pirate Pants;Viking Helmet;Crimtane Ore;Cactus Sword;Cactus Pickaxe;Ice Brick;Ice Brick Wall;Adhesive Bandage;Armor Polish;Bezoar;Blindfold;Fast Clock;Megaphone;Nazar;Vitamins;Trifold Map;Cactus Helmet;Cactus Breastplate;Cactus Leggings;Power Glove;Lightning Boots;Sun Stone;Moon Stone;Armor Bracing;Medicated Bandage;The Plan;Countercurse Mantra;Coin Gun;Lava Charm;Obsidian Water Walking Boots;Lava Waders;Pure Water Fountain;Desert Water Fountain;Shadewood;Shadewood Door;Shadewood Platform;Shadewood Chest;Shadewood Chair;Shadewood Work Bench;Shadewood Table;Shadewood Dresser;Shadewood Piano;Shadewood Bed;Shadewood Sword;Shadewood Hammer;Shadewood Bow;Shadewood Helmet;Shadewood Breastplate;Shadewood Greaves;Shadewood Wall;Cannon;Cannonball;Flare Gun;Flare;Bone Wand;Leaf Wand;Flying Carpet;Avenger Emblem;Mechanical Glove;Land Mine;Paladins Shield;Web Slinger;Jungle Water Fountain;Icy Water Fountain;Corrupt Water Fountain;Crimson Water Fountain;Hallowed Water Fountain;Blood Water Fountain;Umbrella;Chlorophyte Ore;Steampunk Wings;Snowball;Ice Skates;Snowball Launcher;Web Covered Chest;Climbing Claws;Ancient Iron Helmet;Ancient Gold Helmet;Ancient Shadow Helmet;Ancient Shadow Scalemail;Ancient Shadow Greaves;Ancient Necro Helmet;Ancient Cobalt Helmet;Ancient Cobalt Breastplate;Ancient Cobalt Leggings;Black Belt;Boomstick;Rope;Campfire;Marshmallow;Marshmallow on a Stick;Cooked Marshmallow;Red Rocket;Green Rocket;Blue Rocket;Yellow Rocket;Ice Torch;Shoe Spikes;Tiger Climbing Gear;Tabi;Pink Snow Hood;Pink Snow Coat;Pink Snow Pants;Pink Thread;Mana Regeneration Band;Sandstorm in a Balloon;Master Ninja Gear;Rope Coil;Blowgun;Blizzard in a Bottle;Frostburn Arrow;Enchanted Sword;Pickaxe Axe;Cobalt Waraxe;Mythril Waraxe;Adamantite Waraxe;Eaters Bone;Blend-O-Matic;Meat Grinder;Extractinator;Solidifier;Amber;Confetti Gun;Chlorophyte Mask;Chlorophyte Helmet;Chlorophyte Headgear;Chlorophyte Plate Mail;Chlorophyte Greaves;Chlorophyte Bar;Red Dye;Orange Dye;Yellow Dye;Lime Dye;Green Dye;Teal Dye;Cyan Dye;Sky Blue Dye;Blue Dye;Purple Dye;Violet Dye;Pink Dye;Red and Black Dye;Orange and Black Dye;Yellow and Black Dye;Lime and Black Dye;Green and Black Dye;Teal and Black Dye;Cyan and Black Dye;Sky Blue and Black Dye;Blue and Black Dye;Purple and Black Dye;Violet and Black Dye;Pink and Black Dye;Flame Dye;Flame and Black Dye;Green Flame Dye;Green Flame and Black Dye;Blue Flame Dye;Blue Flame and Black Dye;Silver Dye;Bright Red Dye;Bright Orange Dye;Bright Yellow Dye;Bright Lime Dye;Bright Green Dye;Bright Teal Dye;Bright Cyan Dye;Bright Sky Blue Dye;Bright Blue Dye;Bright Purple Dye;Bright Violet Dye;Bright Pink Dye;Black Dye;Red and Silver Dye;Orange and Silver Dye;Yellow and Silver Dye;Lime and Silver Dye;Green and Silver Dye;Teal and Silver Dye;Cyan and Silver Dye;Sky Blue and Silver Dye;Blue and Silver Dye;Purple and Silver Dye;Violet and Silver Dye;Pink and Silver Dye;Intense Flame Dye;Intense Green Flame Dye;Intense Blue Flame Dye;Rainbow Dye;Intense Rainbow Dye;Yellow Gradient Dye;Cyan Gradient Dye;Violet Gradient Dye;Paintbrush;Paint Roller;Red Paint;Orange Paint;Yellow Paint;Lime Paint;Green Paint;Teal Paint;Cyan Paint;Sky Blue Paint;Blue Paint;Purple Paint;Violet Paint;Pink Paint;Deep Red Paint;Deep Orange Paint;Deep Yellow Paint;Deep Lime Paint;Deep Green Paint;Deep Teal Paint;Deep Cyan Paint;Deep Sky Blue Paint;Deep Blue Paint;Deep Purple Paint;Deep Violet Paint;Deep Pink Paint;Black Paint;White Paint;Gray Paint;Paint Scraper;Lihzahrd Brick;Lihzahrd Brick Wall;Slush Block;Palladium Ore;Orichalcum Ore;Titanium Ore;Teal Mushroom;Green Mushroom;Sky Blue Flower;Yellow Marigold;Blue Berries;Lime Kelp;Pink Prickly Pear;Orange Bloodroot;Red Husk;Cyan Husk;Violet Husk;Purple Mucus;Black Ink;Dye Vat;Bee Gun;Possessed Hatchet;Bee Keeper;Hive;Honey Block;Hive Wall;Crispy Honey Block;Honey Bucket;Hive Wand;Beenade;Gravity Globe;Honey Comb;Abeemination;Bottled Honey;Rain Hat;Rain Coat;Lihzahrd Door;Dungeon Door;Lead Door;Iron Door;Temple Key;Lihzahrd Chest;Lihzahrd Chair;Lihzahrd Table;Lihzahrd Work Bench;Super Dart Trap;Flame Trap;Spiky Ball Trap;Spear Trap;Wooden Spike;Lihzahrd Pressure Plate;Lihzahrd Statue;Lihzahrd Watcher Statue;Lihzahrd Guardian Statue;Wasp Gun;Piranha Gun;Pygmy Staff;Pygmy Necklace;Tiki Mask;Tiki Shirt;Tiki Pants;Leaf Wings;Blizzard in a Balloon;Bundle of Balloons;Bat Wings;Bone Sword;Hercules Beetle;Smoke Bomb;Bone Key;Nectar;Tiki Totem;Lizard Egg;Grave Marker;Cross Grave Marker;Headstone;Gravestone;Obelisk;Leaf Blower;Chlorophyte Bullet;Parrot Cracker;Strange Glowing Mushroom;Seedling;Wisp in a Bottle;Palladium Bar;Palladium Sword;Palladium Pike;Palladium Repeater;Palladium Pickaxe;Palladium Drill;Palladium Chainsaw;Orichalcum Bar;Orichalcum Sword;Orichalcum Halberd;Orichalcum Repeater;Orichalcum Pickaxe;Orichalcum Drill;Orichalcum Chainsaw;Titanium Bar;Titanium Sword;Titanium Trident;Titanium Repeater;Titanium Pickaxe;Titanium Drill;Titanium Chainsaw;Palladium Mask;Palladium Helmet;Palladium Headgear;Palladium Breastplate;Palladium Leggings;Orichalcum Mask;Orichalcum Helmet;Orichalcum Headgear;Orichalcum Breastplate;Orichalcum Leggings;Titanium Mask;Titanium Helmet;Titanium Headgear;Titanium Breastplate;Titanium Leggings;Orichalcum Anvil;Titanium Forge;Palladium Waraxe;Orichalcum Waraxe;Titanium Waraxe;Hallowed Bar;Chlorophyte Claymore;Chlorophyte Saber;Chlorophyte Partisan;Chlorophyte Shotbow;Chlorophyte Pickaxe;Chlorophyte Drill;Chlorophyte Chainsaw;Chlorophyte Greataxe;Chlorophyte Warhammer;Chlorophyte Arrow;Amethyst Hook;Topaz Hook;Sapphire Hook;Emerald Hook;Ruby Hook;Diamond Hook;Amber Mosquito;Umbrella Hat;Nimbus Rod;Orange Torch;Crimsand Block;Bee Cloak;Eye of the Golem;Honey Balloon;Blue Horseshoe Balloon;White Horseshoe Balloon;Yellow Horseshoe Balloon;Frozen Turtle Shell;Sniper Rifle;Venus Magnum;Crimson Rod;Crimtane Bar;Stynger;Flower Pow;Rainbow Gun;Stynger Bolt;Chlorophyte Jackhammer;Teleporter;Flower of Frost;Uzi;Magnet Sphere;Purple Stained Glass;Yellow Stained Glass;Blue Stained Glass;Green Stained Glass;Red Stained Glass;Multicolored Stained Glass;Skeletron Hand;Skull;Balla Hat;Gangsta Hat;Sailor Hat;Eye Patch;Sailor Shirt;Sailor Pants;Skeletron Mask;Amethyst Robe;Topaz Robe;Sapphire Robe;Emerald Robe;Ruby Robe;Diamond Robe;White Tuxedo Shirt;White Tuxedo Pants;Panic Necklace;Life Fruit;Lihzahrd Altar;Lihzahrd Power Cell;Picksaw;Heat Ray;Staff of Earth;Golem Fist;Water Chest;Binoculars;Rifle Scope;Destroyer Emblem;High Velocity Bullet;Jellyfish Necklace;Zombie Arm;The Axe;Ice Sickle;Clothier Voodoo Doll;Poison Staff;Slime Staff;Poison Dart;Eye Spring;Toy Sled;Book of Skulls;KO Cannon;Pirate Map;Turtle Helmet;Turtle Scale Mail;Turtle Leggings;Snowball Cannon;Bone Pickaxe;Magic Quiver;Magma Stone;Obsidian Rose;Bananarang;Chain Knife;Rod of Discord;Death Sickle;Turtle Shell;Tissue Sample;Vertebra;Bloody Spine;Ichor;Ichor Torch;Ichor Arrow;Ichor Bullet;Golden Shower;Bunny Cannon;Explosive Bunny;Vial of Venom;Flask of Venom;Venom Arrow;Venom Bullet;Fire Gauntlet;Cog;Confetti;Nanites;Explosive Powder;Gold Dust;Party Bullet;Nano Bullet;Exploding Bullet;Golden Bullet;Flask of Cursed Flames;Flask of Fire;Flask of Gold;Flask of Ichor;Flask of Nanites;Flask of Party;Flask of Poison;Eye of Cthulhu Trophy;Eater of Worlds Trophy;Brain of Cthulhu Trophy;Skeletron Trophy;Queen Bee Trophy;Wall of Flesh Trophy;Destroyer Trophy;Skeletron Prime Trophy;Retinazer Trophy;Spazmatism Trophy;Plantera Trophy;Golem Trophy;Blood Moon Rising;The Hanged Man;Glory of the Fire;Bone Warp;Wall Skeleton;Hanging Skeleton;Blue Slab Wall;Blue Tiled Wall;Pink Slab Wall;Pink Tiled Wall;Green Slab Wall;Green Tiled Wall;Blue Brick Platform;Pink Brick Platform;Green Brick Platform;Metal Shelf;Brass Shelf;Wood Shelf;Brass Lantern;Caged Lantern;Carriage Lantern;Alchemy Lantern;Diabolist Lamp;Oil Rag Sconce;Blue Dungeon Chair;Blue Dungeon Table;Blue Dungeon Work Bench;Green Dungeon Chair;Green Dungeon Table;Green Dungeon Work Bench;Pink Dungeon Chair;Pink Dungeon Table;Pink Dungeon Work Bench;Blue Dungeon Candle;Green Dungeon Candle;Pink Dungeon Candle;Blue Dungeon Vase;Green Dungeon Vase;Pink Dungeon Vase;Blue Dungeon Door;Green Dungeon Door;Pink Dungeon Door;Blue Dungeon Bookcase;Green Dungeon Bookcase;Pink Dungeon Bookcase;Catacomb;Dungeon Shelf;Skellington J Skellingsworth;The Cursed Man;The Eye Sees the End;Something Evil is Watching You;The Twins Have Awoken;The Screamer;Goblins Playing Poker;Dryadisque;Sunflowers;Terrarian Gothic;Beanie;Imbuing Station;Star in a Bottle;Empty Bullet;Impact;Powered by Birds;The Destroyer;The Persistency of Eyes;Unicorn Crossing the Hallows;Great Wave;Starry Night;Guide Picasso;The Guardians Gaze;Father of Someone;Nurse Lisa;Shadowbeam Staff;Inferno Fork;Spectre Staff;Wooden Fence;Lead Fence;Bubble Machine;Bubble Wand;Marching Bones Banner;Necromantic Sign;Rusted Company Standard;Ragged Brotherhood Sigil;Molten Legion Flag;Diabolic Sigil;Obsidian Platform;Obsidian Door;Obsidian Chair;Obsidian Table;Obsidian Work Bench;Obsidian Vase;Obsidian Bookcase;Hellbound Banner;Hell Hammer Banner;Helltower Banner;Lost Hopes of Man Banner;Obsidian Watcher Banner;Lava Erupts Banner;Blue Dungeon Bed;Green Dungeon Bed;Pink Dungeon Bed;Obsidian Bed;Waldo;Darkness;Dark Soul Reaper;Land;Trapped Ghost;Demons Eye;Finding Gold;First Encounter;Good Morning;Underground Reward;Through the Window;Place Above the Clouds;Do Not Step on the Grass;Cold Waters in the White Land;Lightless Chasms;The Land of Deceiving Looks;Daylight;Secret of the Sands;Deadland Comes Alive;Evil Presence;Sky Guardian;American Explosive;Discover;Hand Earth;Old Miner;Skelehead;Facing the Cerebral Mastermind;Lake of Fire;Trio Super Heroes;Spectre Hood;Spectre Robe;Spectre Pants;Spectre Pickaxe;Spectre Hamaxe;Ectoplasm;Gothic Chair;Gothic Table;Gothic Work Bench;Gothic Bookcase;Paladins Hammer;SWAT Helmet;Bee Wings;Giant Harpy Feather;Bone Feather;Fire Feather;Ice Feather;Broken Bat Wing;Tattered Bee Wing;Large Amethyst;Large Topaz;Large Sapphire;Large Emerald;Large Ruby;Large Diamond;Jungle Chest;Corruption Chest;Crimson Chest;Hallowed Chest;Ice Chest;Jungle Key;Corruption Key;Crimson Key;Hallowed Key;Frozen Key;Imp Face;Ominous Presence;Shining Moon;Living Gore;Flowing Magma;Spectre Paintbrush;Spectre Paint Roller;Spectre Paint Scraper;Shroomite Headgear;Shroomite Mask;Shroomite Helmet;Shroomite Breastplate;Shroomite Leggings;Autohammer;Shroomite Bar;S.D.M.G.;Cenxs Tiara;Cenxs Breastplate;Cenxs Leggings;Crownos Mask;Crownos Breastplate;Crownos Leggings;Wills Helmet;Wills Breastplate;Wills Leggings;Jims Helmet;Jims Breastplate;Jims Leggings;Aarons Helmet;Aarons Breastplate;Aarons Leggings;Vampire Knives;Broken Hero Sword;Scourge of the Corruptor;Staff of the Frost Hydra;The Creation of the Guide;The Merchant;Crowno Devours His Lunch;Rare Enchantment;Glorious Night;Sweetheart Necklace;Flurry Boots;D-Towns Helmet;D-Towns Breastplate;D-Towns Leggings;D-Towns Wings;Wills Wings;Crownos Wings;Cenxs Wings;Cenxs Dress;Cenxs Dress Pants;Palladium Column;Palladium Column Wall;Bubblegum Block;Bubblegum Block Wall;Titanstone Block;Titanstone Block Wall;Magic Cuffs;Music Box (Snow);Music Box (Space Night);Music Box (Crimson);Music Box (Boss 4);Music Box (Alt Overworld Day);Music Box (Rain);Music Box (Ice);Music Box (Desert);Music Box (Ocean Day);Music Box (Dungeon);Music Box (Plantera);Music Box (Boss 5);Music Box (Temple);Music Box (Eclipse);Music Box (Mushrooms);Butterfly Dust;Ankh Charm;Ankh Shield;Blue Flare;Angler Fish Banner;Angry Nimbus Banner;Anomura Fungus Banner;Antlion Banner;Arapaima Banner;Armored Skeleton Banner;Cave Bat Banner;Bird Banner;Black Recluse Banner;Blood Feeder Banner;Blood Jelly Banner;Blood Crawler Banner;Bone Serpent Banner;Bunny Banner;Chaos Elemental Banner;Mimic Banner;Clown Banner;Corrupt Bunny Banner;Corrupt Goldfish Banner;Crab Banner;Crimera Banner;Crimson Axe Banner;Cursed Hammer Banner;Demon Banner;Demon Eye Banner;Derpling Banner;Eater of Souls Banner;Enchanted Sword Banner;Frozen Zombie Banner;Face Monster Banner;Floaty Gross Banner;Flying Fish Banner;Flying Snake Banner;Frankenstein Banner;Fungi Bulb Banner;Fungo Fish Banner;Gastropod Banner;Goblin Thief Banner;Goblin Sorcerer Banner;Goblin Peon Banner;Goblin Scout Banner;Goblin Warrior Banner;Goldfish Banner;Harpy Banner;Hellbat Banner;Herpling Banner;Hornet Banner;Ice Elemental Banner;Icy Merman Banner;Fire Imp Banner;Blue Jellyfish Banner;Jungle Creeper Banner;Lihzahrd Banner;Man Eater Banner;Meteor Head Banner;Moth Banner;Mummy Banner;Mushi Ladybug Banner;Parrot Banner;Pigron Banner;Piranha Banner;Pirate Deckhand Banner;Pixie Banner;Raincoat Zombie Banner;Reaper Banner;Shark Banner;Skeleton Banner;Dark Caster Banner;Blue Slime Banner;Snow Flinx Banner;Wall Creeper Banner;Spore Zombie Banner;Swamp Thing Banner;Giant Tortoise Banner;Toxic Sludge Banner;Umbrella Slime Banner;Unicorn Banner;Vampire Banner;Vulture Banner;Nymph Banner;Werewolf Banner;Wolf Banner;World Feeder Banner;Worm Banner;Wraith Banner;Wyvern Banner;Zombie Banner;Glass Platform;Glass Chair;Golden Chair;Golden Toilet;Bar Stool;Honey Chair;Steampunk Chair;Glass Door;Golden Door;Honey Door;Steampunk Door;Glass Table;Banquet Table;Bar;Golden Table;Honey Table;Steampunk Table;Glass Bed;Golden Bed;Honey Bed;Steampunk Bed;Living Wood Wall;Fart in a Jar;Pumpkin;Pumpkin Wall;Hay;Hay Wall;Spooky Wood;Spooky Wood Wall;Pumpkin Helmet;Pumpkin Breastplate;Pumpkin Leggings;Candy Apple;Soul Cake;Nurse Hat;Nurse Shirt;Nurse Pants;Wizards Hat;Guy Fawkes Mask;Dye Trader Robe;Steampunk Goggles;Cyborg Helmet;Cyborg Shirt;Cyborg Pants;Creeper Mask;Creeper Shirt;Creeper Pants;Cat Mask;Cat Shirt;Cat Pants;Ghost Mask;Ghost Shirt;Pumpkin Mask;Pumpkin Shirt;Pumpkin Pants;Robot Mask;Robot Shirt;Robot Pants;Unicorn Mask;Unicorn Shirt;Unicorn Pants;Vampire Mask;Vampire Shirt;Vampire Pants;Witch Hat;Leprechaun Hat;Leprechaun Shirt;Leprechaun Pants;Pixie Shirt;Pixie Pants;Princess Hat;Princess Dress;Goodie Bag;Witch Dress;Witch Boots;Bride of Frankenstein Mask;Bride of Frankenstein Dress;Karate Tortoise Mask;Karate Tortoise Shirt;Karate Tortoise Pants;Candy Corn Rifle;Candy Corn;Jack O Lantern Launcher;Explosive Jack O Lantern;Sickle;Pumpkin Pie;Scarecrow Hat;Scarecrow Shirt;Scarecrow Pants;Cauldron;Pumpkin Chair;Pumpkin Door;Pumpkin Table;Pumpkin Work Bench;Pumpkin Platform;Tattered Fairy Wings;Spider Egg;Magical Pumpkin Seed;Bat Hook;Bat Scepter;Raven Staff;Jungle Key;Corruption Key;Crimson Key;Hallowed Key;Frozen Key;Hanging Jack O Lantern;Rotten Egg;Unlucky Yarn;Black Fairy Dust;Jackelier;Jack O Lantern;Spooky Chair;Spooky Door;Spooky Table;Spooky Work Bench;Spooky Wood Platform;Reaper Hood;Reaper Robe;Fox Mask;Fox Shirt;Fox Pants;Cat Ears;Bloody Machete;The Horsemans Blade;Bladed Glove;Pumpkin Seed;Spooky Hook;Spooky Wings;Spooky Twig;Spooky Helmet;Spooky Breastplate;Spooky Leggings;Stake Launcher;Stake;Cursed Sapling;Space Creature Mask;Space Creature Shirt;Space Creature Pants;Wolf Mask;Wolf Shirt;Wolf Pants;Pumpkin Moon Medallion;Necromantic Scroll;Jacking Skeletron;Bitter Harvest;Blood Moon Countess;Hallows Eve;Morbid Curiosity;Treasure Hunter Shirt;Treasure Hunter Pants;Dryad Coverings;Dryad Loincloth;Mourning Wood Trophy;Pumpking Trophy;Jack O Lantern Mask;Sniper Scope;Heart Lantern;Jellyfish Diving Gear;Arctic Diving Gear;Frostspark Boots;Fart in a Balloon;Papyrus Scarab;Celestial Stone;Hoverboard;Candy Cane;Sugar Plum;Present;Red Ryder;Festive Wings;Pine Tree Block;Christmas Tree;Star Topper 1;Star Topper 2;Star Topper 3;Bow Topper;White Garland;White and Red Garland;Red Garland;Red and Green Garland;Green Garland;Green and White Garland;Multicolored Bulb;Red Bulb;Yellow Bulb;Green Bulb;Red and Green Bulb;Yellow and Green Bulb;Red and Yellow Bulb;White Bulb;White and Red Bulb;White and Yellow Bulb;White and Green Bulb;Multicolored Lights;Red Lights;Green Lights;Blue Lights;Yellow Lights;Red and Yellow Lights;Red and Green Lights;Yellow and Green Lights;Blue and Green Lights;Red and Blue Lights;Blue and Yellow Lights;Giant Bow;Reindeer Antlers;Holly;Candy Cane Sword;Elf Melter;Christmas Pudding;Eggnog;Star Anise;Reindeer Bells;Candy Cane Hook;Christmas Hook;Candy Cane Pickaxe;Fruitcake Chakram;Sugar Cookie;Gingerbread Cookie;Hand Warmer;Coal;Toolbox;Pine Door;Pine Chair;Pine Table;Dog Whistle;Christmas Tree Sword;Chain Gun;Razorpine;Blizzard Staff;Mrs. Claus Hat;Mrs. Claus Shirt;Mrs. Claus Heels;Parka Hood;Parka Coat;Parka Pants;Snow Hat;Ugly Sweater;Tree Mask;Tree Shirt;Tree Trunks;Elf Hat;Elf Shirt;Elf Pants;Snowman Cannon;North Pole;Christmas Tree Wallpaper;Ornament Wallpaper;Candy Cane Wallpaper;Festive Wallpaper;Stars Wallpaper;Squiggles Wallpaper;Snowflake Wallpaper;Krampus Horn Wallpaper;Bluegreen Wallpaper;Grinch Finger Wallpaper;Naughty Present;Baby Grinchs Mischief Whistle;Ice Queen Trophy;Santa-NK1 Trophy;Everscream Trophy;Music Box (Pumpkin Moon);Music Box (Alt Underground);Music Box (Frost Moon);Brown Paint;Shadow Paint;Negative Paint;Team Dye;Amethyst Gemspark Block;Topaz Gemspark Block;Sapphire Gemspark Block;Emerald Gemspark Block;Ruby Gemspark Block;Diamond Gemspark Block;Amber Gemspark Block;Life Hair Dye;Mana Hair Dye;Depth Hair Dye;Money Hair Dye;Time Hair Dye;Team Hair Dye;Biome Hair Dye;Party Hair Dye;Rainbow Hair Dye;Speed Hair Dye;Angel Halo;Fez;Womannequin;Hair Dye Remover;Bug Net;Firefly;Firefly in a Bottle;Monarch Butterfly;Purple Emperor Butterfly;Red Admiral Butterfly;Ulysses Butterfly;Sulphur Butterfly;Tree Nymph Butterfly;Zebra Swallowtail Butterfly;Julia Butterfly;Worm;Mouse;Lightning Bug;Lightning Bug in a Bottle;Snail;Glowing Snail;Fancy Gray Wallpaper;Ice Floe Wallpaper;Music Wallpaper;Purple Rain Wallpaper;Rainbow Wallpaper;Sparkle Stone Wallpaper;Starlit Heaven Wallpaper;Bird;Blue Jay;Cardinal;Squirrel;Bunny;Cactus Bookcase;Ebonwood Bookcase;Flesh Bookcase;Honey Bookcase;Steampunk Bookcase;Glass Bookcase;Rich Mahogany Bookcase;Pearlwood Bookcase;Spooky Bookcase;Skyware Bookcase;Lihzahrd Bookcase;Frozen Bookcase;Cactus Lantern;Ebonwood Lantern;Flesh Lantern;Honey Lantern;Steampunk Lantern;Glass Lantern;Rich Mahogany Lantern;Pearlwood Lantern;Frozen Lantern;Lihzahrd Lantern;Skyware Lantern;Spooky Lantern;Frozen Door;Cactus Candle;Ebonwood Candle;Flesh Candle;Glass Candle;Frozen Candle;Rich Mahogany Candle;Pearlwood Candle;Lihzahrd Candle;Skyware Candle;Pumpkin Candle;Cactus Chandelier;Ebonwood Chandelier;Flesh Chandelier;Honey Chandelier;Frozen Chandelier;Rich Mahogany Chandelier;Pearlwood Chandelier;Lihzahrd Chandelier;Skyware Chandelier;Spooky Chandelier;Glass Chandelier;Cactus Bed;Flesh Bed;Frozen Bed;Lihzahrd Bed;Skyware Bed;Spooky Bed;Cactus Bathtub;Ebonwood Bathtub;Flesh Bathtub;Glass Bathtub;Frozen Bathtub;Rich Mahogany Bathtub;Pearlwood Bathtub;Lihzahrd Bathtub;Skyware Bathtub;Spooky Bathtub;Cactus Lamp;Ebonwood Lamp;Flesh Lamp;Glass Lamp;Frozen Lamp;Rich Mahogany Lamp;Pearlwood Lamp;Lihzahrd Lamp;Skyware Lamp;Spooky Lamp;Cactus Candelabra;Ebonwood Candelabra;Flesh Candelabra;Honey Candelabra;Steampunk Candelabra;Glass Candelabra;Rich Mahogany Candelabra;Pearlwood Candelabra;Frozen Candelabra;Lihzahrd Candelabra;Skyware Candelabra;Spooky Candelabra;Brain of Cthulhu Mask;Wall of Flesh Mask;Twin Mask;Skeletron Prime Mask;Queen Bee Mask;Plantera Mask;Golem Mask;Eater of Worlds Mask;Eye of Cthulhu Mask;Destroyer Mask;Blacksmith Rack;Carpentry Rack;Helmet Rack;Spear Rack;Sword Rack;Stone Slab;Sandstone Slab;Frog;Mallard Duck;Duck;Honey Bathtub;Steampunk Bathtub;Living Wood Bathtub;Shadewood Bathtub;Bone Bathtub;Honey Lamp;Steampunk Lamp;Living Wood Lamp;Shadewood Lamp;Golden Lamp;Bone Lamp;Living Wood Bookcase;Shadewood Bookcase;Golden Bookcase;Bone Bookcase;Living Wood Bed;Bone Bed;Living Wood Chandelier;Shadewood Chandelier;Golden Chandelier;Bone Chandelier;Living Wood Lantern;Shadewood Lantern;Golden Lantern;Bone Lantern;Living Wood Candelabra;Shadewood Candelabra;Golden Candelabra;Bone Candelabra;Living Wood Candle;Shadewood Candle;Golden Candle;Black Scorpion;Scorpion;Bubble Wallpaper;Copper Pipe Wallpaper;Ducky Wallpaper;Frost Core;Bunny Cage;Squirrel Cage;Mallard Duck Cage;Duck Cage;Bird Cage;Blue Jay Cage;Cardinal Cage;Waterfall Wall;Lavafall Wall;Crimson Seeds;Heavy Work Bench;Copper Plating;Snail Cage;Glowing Snail Cage;Shroomite Digging Claw;Ammo Box;Monarch Butterfly Jar;Purple Emperor Butterfly Jar;Red Admiral Butterfly Jar;Ulysses Butterfly Jar;Sulphur Butterfly Jar;Tree Nymph Butterfly Jar;Zebra Swallowtail Butterfly Jar;Julia Butterfly Jar;Scorpion Cage;Black Scorpion Cage;Venom Staff;Spectre Mask;Frog Cage;Mouse Cage;Bone Welder;Flesh Cloning Vat;Glass Kiln;Lihzahrd Furnace;Living Loom;Sky Mill;Ice Machine;Beetle Helmet;Beetle Scale Mail;Beetle Shell;Beetle Leggings;Steampunk Boiler;Honey Dispenser;Penguin;Penguin Cage;Worm Cage;Terrarium;Super Mana Potion;Ebonwood Fence;Rich Mahogany Fence;Pearlwood Fence;Shadewood Fence;Brick Layer;Extendo Grip;Paint Sprayer;Portable Cement Mixer;Beetle Husk;Celestial Magnet;Celestial Emblem;Celestial Cuffs;Peddlers Hat;Pulse Bow;Large Dynasty Lantern;Dynasty Lamp;Dynasty Lantern;Large Dynasty Candle;Dynasty Chair;Dynasty Work Bench;Dynasty Chest;Dynasty Bed;Dynasty Bathtub;Dynasty Bookcase;Dynasty Cup;Dynasty Bowl;Dynasty Candle;Dynasty Clock;Golden Clock;Glass Clock;Honey Clock;Steampunk Clock;Fancy Dishes;Glass Bowl;Wine Glass;Living Wood Piano;Flesh Piano;Frozen Piano;Frozen Table;Honey Chest;Steampunk Chest;Honey Work Bench;Frozen Work Bench;Steampunk Work Bench;Glass Piano;Honey Piano;Steampunk Piano;Honey Cup;Chalice;Dynasty Table;Dynasty Wood;Red Dynasty Shingles;Blue Dynasty Shingles;White Dynasty Wall;Blue Dynasty Wall;Dynasty Door;Sake;Pad Thai;Pho;Revolver;Gatligator;Arcane Rune Wall;Water Gun;Katana;Ultrabright Torch;Magic Hat;Diamond Ring;Gi;Kimono;Mystic Robe;Beetle Wings;Tiger Skin;Leopard Skin;Zebra Skin;Crimson Cloak;Mysterious Cape;Red Cape;Winter Cape;Frozen Chair;Wood Fishing Pole;Bass;Reinforced Fishing Pole;Fiberglass Fishing Pole;Fisher of Souls;Golden Fishing Rod;Mechanics Rod;Sitting Ducks Fishing Pole;Trout;Salmon;Atlantic Cod;Tuna;Red Snapper;Neon Tetra;Armored Cavefish;Damselfish;Crimson Tigerfish;Frost Minnow;Princess Fish;Golden Carp;Specular Fish;Prismite;Variegated Lardfish;Flarefin Koi;Double Cod;Honeyfin;Obsidifish;Shrimp;Chaos Fish;Ebonkoi;Hemopiranha;Rockfish;Stinkfish;Mining Potion;Heartreach Potion;Calming Potion;Builder Potion;Titan Potion;Flipper Potion;Summoning Potion;Dangersense Potion;Purple Clubberfish;Obsidian Swordfish;Swordfish;Iron Fence;Wooden Crate;Iron Crate;Golden Crate;Old Shoe;Seaweed;Tin Can;Minecart Track;Reaver Shark;Sawtooth Shark;Minecart;Ammo Reservation Potion;Lifeforce Potion;Endurance Potion;Rage Potion;Inferno Potion;Wrath Potion;Recall Potion;Teleportation Potion;Love Potion;Stink Potion;Fishing Potion;Sonar Potion;Crate Potion;Shiverthorn Seeds;Shiverthorn;Warmth Potion;Fish Hook;Bee Headgear;Bee Breastplate;Bee Greaves;Hornet Staff;Imp Staff;Queen Spider Staff;Angler Hat;Angler Vest;Angler Pants;Spider Mask;Spider Breastplate;Spider Greaves;High Test Fishing Line;Angler Earring;Tackle Box;Blue Dungeon Piano;Green Dungeon Piano;Pink Dungeon Piano;Golden Piano;Obsidian Piano;Bone Piano;Cactus Piano;Spooky Piano;Skyware Piano;Lihzahrd Piano;Blue Dungeon Dresser;Green Dungeon Dresser;Pink Dungeon Dresser;Golden Dresser;Obsidian Dresser;Bone Dresser;Cactus Dresser;Spooky Dresser;Skyware Dresser;Honey Dresser;Lihzahrd Dresser;Sofa;Ebonwood Sofa;Rich Mahogany Sofa;Pearlwood Sofa;Shadewood Sofa;Blue Dungeon Sofa;Green Dungeon Sofa;Pink Dungeon Sofa;Golden Sofa;Obsidian Sofa;Bone Sofa;Cactus Sofa;Spooky Sofa;Skyware Sofa;Honey Sofa;Steampunk Sofa;Mushroom Sofa;Glass Sofa;Pumpkin Sofa;Lihzahrd Sofa;Seashell Hairpin;Mermaid Adornment;Mermaid Tail;Zephyr Fish;Fleshcatcher;Hotline Fishing Hook;Frog Leg;Anchor;Cooked Fish;Cooked Shrimp;Sashimi;Fuzzy Carrot;Scaly Truffle;Slimy Saddle;Bee Wax;Copper Plating Wall;Stone Slab Wall;Sail;Coralstone Block;Blue Jellyfish;Green Jellyfish;Pink Jellyfish;Blue Jellyfish Jar;Green Jellyfish Jar;Pink Jellyfish Jar;Life Preserver;Ships Wheel;Compass Rose;Wall Anchor;Goldfish Trophy;Bunnyfish Trophy;Swordfish Trophy;Sharkteeth Trophy;Batfish;Bumblebee Tuna;Catfish;Cloudfish;Cursedfish;Dirtfish;Dynamite Fish;Eater of Plankton;Fallen Starfish;The Fish of Cthulhu;Fishotron;Harpyfish;Hungerfish;Ichorfish;Jewelfish;Mirage Fish;Mutant Flinxfin;Pengfish;Pixiefish;Spiderfish;Tundra Trout;Unicorn Fish;Guide Voodoo Fish;Wyverntail;Zombie Fish;Amanita Fungifin;Angelfish;Bloody Manowar;Bonefish;Bunnyfish;Capn Tunabeard;Clownfish;Demonic Hellfish;Derpfish;Fishron;Infected Scabbardfish;Mudfish;Slimefish;Tropical Barracuda;King Slime Trophy;Ship in a Bottle;Hardy Saddle;Pressure Plate Track;King Slime Mask;Fin Wings;Treasure Map;Seaweed Planter;Pillagin Me Pixels;Fish Costume Mask;Fish Costume Shirt;Fish Costume Finskirt;Ginger Beard;Honeyed Goggles;Boreal Wood;Palm Wood;Boreal Wood Wall;Palm Wood Wall;Boreal Wood Fence;Palm Wood Fence;Boreal Wood Helmet;Boreal Wood Breastplate;Boreal Wood Greaves;Palm Wood Helmet;Palm Wood Breastplate;Palm Wood Greaves;Palm Wood Bow;Palm Wood Hammer;Palm Wood Sword;Palm Wood Platform;Palm Wood Bathtub;Palm Wood Bed;Palm Wood Bench;Palm Wood Candelabra;Palm Wood Candle;Palm Wood Chair;Palm Wood Chandelier;Palm Wood Chest;Palm Wood Sofa;Palm Wood Door;Palm Wood Dresser;Palm Wood Lantern;Palm Wood Piano;Palm Wood Table;Palm Wood Lamp;Palm Wood Work Bench;Optic Staff;Palm Wood Bookcase;Mushroom Bathtub;Mushroom Bed;Mushroom Bench;Mushroom Bookcase;Mushroom Candelabra;Mushroom Candle;Mushroom Chandelier;Mushroom Chest;Mushroom Dresser;Mushroom Lantern;Mushroom Lamp;Mushroom Piano;Mushroom Platform;Mushroom Table;Spider Staff;Boreal Wood Bathtub;Boreal Wood Bed;Boreal Wood Bookcase;Boreal Wood Candelabra;Boreal Wood Candle;Boreal Wood Chair;Boreal Wood Chandelier;Boreal Wood Chest;Boreal Wood Clock;Boreal Wood Door;Boreal Wood Dresser;Boreal Wood Lamp;Boreal Wood Lantern;Boreal Wood Piano;Boreal Wood Platform;Slime Bathtub;Slime Bed;Slime Bookcase;Slime Candelabra;Slime Candle;Slime Chair;Slime Chandelier;Slime Chest;Slime Clock;Slime Door;Slime Dresser;Slime Lamp;Slime Lantern;Slime Piano;Slime Platform;Slime Sofa;Slime Table;Pirate Staff;Slime Hook;Sticky Grenade;Tartar Sauce;Duke Fishron Mask;Duke Fishron Trophy;Molotov Cocktail;Bone Clock;Cactus Clock;Ebonwood Clock;Frozen Clock;Lihzahrd Clock;Living Wood Clock;Rich Mahogany Clock;Flesh Clock;Mushroom Clock;Obsidian Clock;Palm Wood Clock;Pearlwood Clock;Pumpkin Clock;Shadewood Clock;Spooky Clock;Skyware Clock;Spider Fang;Falcon Blade;Fishron Wings;Slime Gun;Flairon;Green Dungeon Chest;Pink Dungeon Chest;Blue Dungeon Chest;Bone Chest;Cactus Chest;Flesh Chest;Obsidian Chest;Pumpkin Chest;Spooky Chest;Tempest Staff;Razorblade Typhoon;Bubble Gun;Tsunami;Seashell;Starfish;Steampunk Platform;Skyware Platform;Living Wood Platform;Honey Platform;Skyware Work Bench;Glass Work Bench;Living Wood Work Bench;Flesh Sofa;Frozen Sofa;Living Wood Sofa;Pumpkin Dresser;Steampunk Dresser;Glass Dresser;Flesh Dresser;Pumpkin Lantern;Obsidian Lantern;Pumpkin Lamp;Obsidian Lamp;Blue Dungeon Lamp;Green Dungeon Lamp;Pink Dungeon Lamp;Honey Candle;Steampunk Candle;Spooky Candle;Obsidian Candle;Blue Dungeon Chandelier;Green Dungeon Chandelier;Pink Dungeon Chandelier;Steampunk Chandelier;Pumpkin Chandelier;Obsidian Chandelier;Blue Dungeon Bathtub;Green Dungeon Bathtub;Pink Dungeon Bathtub;Pumpkin Bathtub;Obsidian Bathtub;Golden Bathtub;Blue Dungeon Candelabra;Green Dungeon Candelabra;Pink Dungeon Candelabra;Obsidian Candelabra;Pumpkin Candelabra;Pumpkin Bed;Pumpkin Bookcase;Pumpkin Piano;Shark Statue;Truffle Worm;Apprentice Bait;Journeyman Bait;Master Bait;Amber Gemspark Wall;Offline Amber Gemspark Wall;Amethyst Gemspark Wall;Offline Amethyst Gemspark Wall;Diamond Gemspark Wall;Offline Diamond Gemspark Wall;Emerald Gemspark Wall;Offline Emerald Gemspark Wall;Ruby Gemspark Wall;Offline Ruby Gemspark Wall;Sapphire Gemspark Wall;Offline Sapphire Gemspark Wall;Topaz Gemspark Wall;Offline Topaz Gemspark Wall;Tin Plating Wall;Tin Plating;Waterfall Block;Lavafall Block;Confetti Block;Confetti Wall;Midnight Confetti Block;Midnight Confetti Wall;Weapon Rack;Fireworks Box;Living Fire Block;0 Statue;1 Statue;2 Statue;3 Statue;4 Statue;5 Statue;6 Statue;7 Statue;8 Statue;9 Statue;A Statue;B Statue;C Statue;D Statue;E Statue;F Statue;G Statue;H Statue;I Statue;J Statue;K Statue;L Statue;M Statue;N Statue;O Statue;P Statue;Q Statue;R Statue;S Statue;T Statue;U Statue;V Statue;W Statue;X Statue;Y Statue;Z Statue;Firework Fountain;Booster Track;Grasshopper;Grasshopper Cage;Music Box (Underground Crimson);Cactus Table;Cactus Platform;Boreal Wood Sword;Boreal Wood Hammer;Boreal Wood Bow;Glass Chest;Xeno Staff;Meteor Staff;Living Cursed Fire Block;Living Demon Fire Block;Living Frost Fire Block;Living Ichor Block;Living Ultrabright Fire Block;Gender Change Potion;Vortex Helmet;Vortex Breastplate;Vortex Leggings;Nebula Helmet;Nebula Breastplate;Nebula Leggings;Solar Flare Helmet;Solar Flare Breastplate;Solar Flare Leggings;Solar Tablet Fragment;Solar Tablet;Drill Containment Unit;Cosmic Car Key;Mothron Wings;Brain Scrambler;;;Vortex Drill;;Vortex Pickaxe;;;Nebula Drill;;Nebula Pickaxe;;;Solar Flare Drill;;Solar Flare Pickaxe;Honeyfall Block;Honeyfall Wall;Chlorophyte Brick Wall;Crimtane Brick Wall;Shroomite Plating Wall;Chlorophyte Brick;Crimtane Brick;Shroomite Plating;Laser Machinegun;Electrosphere Launcher;Xenopopper;Laser Drill;Mechanical Ruler;Anti-Gravity Hook;Moon Mask;Sun Mask;Martian Costume Mask;Martian Costume Shirt;Martian Costume Pants;Martian Uniform Helmet;Martian Uniform Torso;Martian Uniform Pants;Martian Astro Clock;Martian Bathtub;Martian Bed;Martian Hover Chair;Martian Chandelier;Martian Chest;Martian Door;Martian Dresser;Martian Holobookcase;Martian Hover Candle;Martian Lamppost;Martian Lantern;Martian Piano;Martian Platform;Martian Sofa;Martian Table;Martian Table Lamp;Martian Work Bench;Wooden Sink;Ebonwood Sink;Rich Mahogany Sink;Pearlwood Sink;Bone Sink;Flesh Sink;Living Wood Sink;Skyware Sink;Shadewood Sink;Lihzahrd Sink;Blue Dungeon Sink;Green Dungeon Sink;Pink Dungeon Sink;Obsidian Sink;Metal Sink;Glass Sink;Golden Sink;Honey Sink;Steampunk Sink;Pumpkin Sink;Spooky Sink;Frozen Sink;Dynasty Sink;Palm Wood Sink;Mushroom Sink;Boreal Wood Sink;Slime Sink;Cactus Sink;Martian Sink;Solar Cultist Hood;Lunar Cultist Hood;Solar Cultist Robe;Lunar Cultist Robe;Martian Conduit Plating;Martian Conduit Wall;HiTek Sunglasses;Martian Hair Dye;Martian Dye;Castle Marsberg;Martia Lisa;The Truth Is Up There;Smoke Block;Living Flame Dye;Living Rainbow Dye;Shadow Dye;Negative Dye;Living Ocean Dye;Brown Dye;Brown and Black Dye;Bright Brown Dye;Brown and Silver Dye;Wisp Dye;Pixie Dye;Influx Waver;;Charged Blaster Cannon;Chlorophyte Dye;Unicorn Wisp Dye;Infernal Wisp Dye;Vicious Powder;Vicious Mushroom;The Bees Knees;Gold Bird;Gold Bunny;Gold Butterfly;Gold Frog;Gold Grasshopper;Gold Mouse;Gold Worm;Sticky Dynamite;Angry Trapper Banner;Armored Viking Banner;Black Slime Banner;Blue Armored Bones Banner;Blue Cultist Archer Banner;Lunatic Devotee Banner;Blue Cultist Fighter Banner;Bone Lee Banner;Clinger Banner;Cochineal Beetle Banner;Corrupt Penguin Banner;Corrupt Slime Banner;Corruptor Banner;Crimslime Banner;Cursed Skull Banner;Cyan Beetle Banner;Devourer Banner;Diabolist Banner;Doctor Bones Banner;Dungeon Slime Banner;Dungeon Spirit Banner;Elf Archer Banner;Elf Copter Banner;Eyezor Banner;Flocko Banner;Ghost Banner;Giant Bat Banner;Giant Cursed Skull Banner;Giant Flying Fox Banner;Gingerbread Man Banner;Goblin Archer Banner;Green Slime Banner;Headless Horseman Banner;Hell Armored Bones Banner;Hellhound Banner;Hoppin Jack Banner;Ice Bat Banner;Ice Golem Banner;Ice Slime Banner;Ichor Sticker Banner;Illuminant Bat Banner;Illuminant Slime Banner;Jungle Bat Banner;Jungle Slime Banner;Krampus Banner;Lac Beetle Banner;Lava Bat Banner;Lava Slime Banner;Martian Brainscrambler Banner;Martian Drone Banner;Martian Engineer Banner;Martian Gigazapper Banner;Martian Gray Grunt Banner;Martian Officer Banner;Martian Ray Gunner Banner;Martian Scutlix Gunner Banner;Martian Tesla Turret Banner;Mister Stabby Banner;Mother Slime Banner;Necromancer Banner;Nutcracker Banner;Paladin Banner;Penguin Banner;Pinky Banner;Poltergeist Banner;Possessed Armor Banner;Present Mimic Banner;Purple Slime Banner;Ragged Caster Banner;Rainbow Slime Banner;Raven Banner;Red Slime Banner;Rune Wizard Banner;Rusty Armored Bones Banner;Scarecrow Banner;Scutlix Banner;Skeleton Archer Banner;Skeleton Commando Banner;Skeleton Sniper Banner;Slimer Banner;Snatcher Banner;Snow Balla Banner;Snowman Gangsta Banner;Spiked Ice Slime Banner;Spiked Jungle Slime Banner;Splinterling Banner;Squid Banner;Tactical Skeleton Banner;The Groom Banner;Tim Banner;Undead Miner Banner;Undead Viking Banner;White Cultist Archer Banner;White Cultist Caster Banner;White Cultist Fighter Banner;Yellow Slime Banner;Yeti Banner;Zombie Elf Banner;Sparky;Vine Rope;Wormhole Potion;Summoner Emblem;Bewitching Table;Alchemy Table;Strange Brew;Spelunker Glowstick;Bone Arrow;Bone Torch;Vine Rope Coil;Life Drain;Dart Pistol;Dart Rifle;Crystal Dart;Cursed Dart;Ichor Dart;Chain Guillotines;Fetid Baghnakhs;Clinger Staff;Putrid Scent;Flesh Knuckles;Flower Boots;Seedler;Hellwing Bow;Tendon Hook;Thorn Hook;Illuminant Hook;Worm Hook;Skiphs Blood;Purple Ooze Dye;Reflective Silver Dye;Reflective Gold Dye;Blue Acid Dye;Daedalus Stormbow;Flying Knife;Bottomless Water Bucket;Super Absorbant Sponge;Gold Ring;Coin Ring;Greedy Ring;Fish Finder;Weather Radio;Hades Dye;Twilight Dye;Acid Dye;Glowing Mushroom Dye;Phase Dye;Magic Lantern;Music Box (Lunar Boss);Rainbow Torch;Cursed Campfire;Demon Campfire;Frozen Campfire;Ichor Campfire;Rainbow Campfire;Crystal Vile Shard;Shadowflame Bow;Shadowflame Hex Doll;Shadowflame Knife;Acorns;Cold Snap;Cursed Saint;Snowfellas;The Season;Bone Rattle;Architect Gizmo Pack;Crimson Heart;Meowmere;Enchanted Sundial;Star Wrath;Smooth Marble Block;Hellstone Brick Wall;Guide to Plant Fiber Cordage;Wand of Sparking;Gold Bird Cage;Gold Bunny Cage;Gold Butterfly Jar;Gold Frog Cage;Gold Grasshopper Cage;Gold Mouse Cage;Gold Worm Cage;Silk Rope;Web Rope;Silk Rope Coil;Web Rope Coil;Marble Block;Marble Wall;Smooth Marble Wall;Radar;Golden Lock Box;Granite Block;Smooth Granite Block;Granite Wall;Smooth Granite Wall;Royal Gel;Key of Night;Key of Light;Herb Bag;Javelin;Tally Counter;Sextant;Shield of Cthulhu;Butchers Chainsaw;Stopwatch;Meteorite Brick;Meteorite Brick Wall;Metal Detector;Endless Quiver;Endless Musket Pouch;Toxic Flask;Psycho Knife;Nail Gun;Nail;Night Vision Helmet;Celestial Shell;Pink Gel;Bouncy Glowstick;Pink Slime Block;Pink Torch;Bouncy Bomb;Bouncy Grenade;Peace Candle;Lifeform Analyzer;DPS Meter;Fishermans Pocket Guide;Goblin Tech;R.E.K. 3000;PDA;Cell Phone;Granite Chest;Meteorite Clock;Marble Clock;Granite Clock;Meteorite Door;Marble Door;Granite Door;Meteorite Dresser;Marble Dresser;Granite Dresser;Meteorite Lamp;Marble Lamp;Granite Lamp;Meteorite Lantern;Marble Lantern;Granite Lantern;Meteorite Piano;Marble Piano;Granite Piano;Meteorite Platform;Marble Platform;Granite Platform;Meteorite Sink;Marble Sink;Granite Sink;Meteorite Sofa;Marble Sofa;Granite Sofa;Meteorite Table;Marble Table;Granite Table;Meteorite Work Bench;Marble Work Bench;Granite Work Bench;Meteorite Bathtub;Marble Bathtub;Granite Bathtub;Meteorite Bed;Marble Bed;Granite Bed;Meteorite Bookcase;Marble Bookcase;Granite Bookcase;Meteorite Candelabra;Marble Candelabra;Granite Candelabra;Meteorite Candle;Marble Candle;Granite Candle;Meteorite Chair;Marble Chair;Granite Chair;Meteorite Chandelier;Marble Chandelier;Granite Chandelier;Meteorite Chest;Marble Chest;Magic Water Dropper;Golden Bug Net;Magic Lava Dropper;Magic Honey Dropper;Empty Dropper;Gladiator Helmet;Gladiator Breastplate;Gladiator Leggings;Reflective Dye;Enchanted Nightcrawler;Grubby;Sluggy;Buggy;Grub Soup;Bomb Fish;Frost Daggerfish;Sharpening Station;Ice Mirror;Sailfish Boots;Tsunami in a Bottle;Target Dummy;Corrupt Crate;Crimson Crate;Dungeon Crate;Sky Crate;Hallowed Crate;Jungle Crate;Crystal Serpent;Toxikarp;Bladetongue;Shark Tooth Necklace;Money Trough;Bubble;Daybloom Planter Box;Moonglow Planter Box;Deathweed Planter Box;Deathweed Planter Box;Blinkroot Planter Box;Waterleaf Planter Box;Shiverthorn Planter Box;Fireblossom Planter Box;Brain of Confusion;Worm Scarf;Balloon Pufferfish;Lazures Valkyrie Circlet;Lazures Valkyrie Cloak;Lazures Barrier Platform;Golden Cross Grave Marker;Golden Tombstone;Golden Grave Marker;Golden Gravestone;Golden Headstone;Crystal Block;Music Box (Martian Madness);Music Box (Pirate Invasion);Music Box (Hell);Crystal Block Wall;Trap Door;Tall Gate;Sharkron Balloon;Tax Collectors Hat;Tax Collectors Suit;Tax Collectors Pants;Bone Glove;Clothiers Jacket;Clothiers Pants;Dye Traders Turban;Deadly Sphere Staff;Green Horseshoe Balloon;Amber Horseshoe Balloon;Pink Horseshoe Balloon;Lava Lamp;Enchanted Nightcrawler Cage;Buggy Cage;Grubby Cage;Sluggy Cage;Slap Hand;Twilight Hair Dye;Blessed Apple;Spectre Bar;Code 1;Buccaneer Bandana;Buccaneer Tunic;Buccaneer Pantaloons;Obsidian Outlaw Hat;Obsidian Longcoat;Obsidian Pants;Medusa Head;Item Frame;Sandstone Block;Hardened Sand Block;Sandstone Wall;Hardened Ebonsand Block;Hardened Crimsand Block;Ebonsandstone Block;Crimsandstone Block;Wooden Yoyo;Malaise;Artery;Amazon;Cascade;Chik;Code 2;Rally;Yelets;Reds Throw;Valkyrie Yoyo;Amarok;Hel-Fire;Kraken;The Eye of Cthulhu;Red String;Orange String;Yellow String;Lime String;Green String;Teal String;Cyan String;Sky Blue String;Blue String;Purple String;Violet String;Pink String;Brown String;White String;Rainbow String;Black String;Black Counterweight;Blue Counterweight;Green Counterweight;Purple Counterweight;Red Counterweight;Yellow Counterweight;Format:C;Gradient;Valor;Treasure Bag (King Slime) (King Slime);Treasure Bag (Eye of Cthulhu) (Eye of Cthulhu);Treasure Bag (Eater of Worlds) (Eater of Worlds Head);Treasure Bag (Brain of Cthulhu) (Brain of Cthulhu);Treasure Bag (Queen Bee) (Queen Bee);Treasure Bag (Skeletron) (Skeletron Head);Treasure Bag (Wall of Flesh) (Wall of Flesh);Treasure Bag (The Destroyer) (The Destroyer Head);Treasure Bag (The Twins) (The Twins);Treasure Bag (Skeletron Prime) (Skeletron Prime);Treasure Bag (Plantera) (Plantera);Treasure Bag (Golem) (Golem);Treasure Bag (Duke Fishron) (Duke Fishron);Treasure Bag (Lunatic Cultist) (Lunatic Cultist);Treasure Bag (Moon Lord) (Moon Lord);Hive Pack;Yoyo Glove;Demon Heart;Spore Sac;Shiny Stone;Hardened Pearlsand Block;Pearlsandstone Block;Hardened Sand Wall;Hardened Ebonsand Wall;Hardened Crimsand Wall;Hardened Pearlsand Wall;Ebonsandstone Wall;Crimsandstone Wall;Pearlsandstone Wall;Desert Fossil;Desert Fossil Wall;Exotic Scimitar;Paintball Gun;Classy Cane;Stylish Scissors;Mechanical Cart;Mechanical Wheel Piece;Mechanical Wagon Piece;Mechanical Battery Piece;Lunatic Cultist Trophy;Martian Saucer Trophy;Flying Dutchman Trophy;Living Mahogany Wand;Rich Mahogany Leaf Wand;Fallen Tuxedo Shirt;Fallen Tuxedo Pants;Fireplace;Chimney;Yoyo Bag;Shrimpy Truffle;Arkhalis;Confetti Cannon;Music Box (The Towers);Music Box (Goblin Invasion);Lunatic Cultist Mask;Moon Lord Mask;Fossil Helmet;Fossil Plate;Fossil Greaves;Amber Staff;Bone Javelin;Bone Throwing Knife;Sturdy Fossil;Stardust Helmet;Stardust Plate;Stardust Leggings;Portal Gun;Strange Plant;Strange Plant;Strange Plant;Strange Plant;Terrarian;Goblin Summoner Banner;Salamander Banner;Giant Shelly Banner;Crawdad Banner;Fritz Banner;Creature From The Deep Banner;Dr. Man Fly Banner;Mothron Banner;Severed Hand Banner;The Possessed Banner;Butcher Banner;Psycho Banner;Deadly Sphere Banner;Nailhead Banner;Poisonous Spore Banner;Medusa Banner;Hoplite Banner;Granite Elemental Banner;Granite Golem Banner;Blood Zombie Banner;Drippler Banner;Tomb Crawler Banner;Dune Splicer Banner;Antlion Swarmer Banner;Antlion Charger Banner;Ghoul Banner;Lamia Banner;Desert Spirit Banner;Basilisk Banner;Sand Poacher Banner;Stargazer Banner;Milkyway Weaver Banner;Flow Invader Banner;Twinkle Popper Banner;Mini Star Cell Banner;Star Cell Banner;Corite Banner;Sroller Banner;Crawltipede Banner;Drakomire Rider Banner;Drakomire Banner;Selenian Banner;Predictor Banner;Brain Suckler Banner;Nebula Floater Banner;Evolution Beast Banner;Alien Larva Banner;Alien Queen Banner;Alien Hornet Banner;Vortexian Banner;Storm Diver Banner;Pirate Captain Banner;Pirate Deadeye Banner;Pirate Corsair Banner;Pirate Crossbower Banner;Martian Walker Banner;Red Devil Banner;Pink Jellyfish Banner;Green Jellyfish Banner;Dark Mummy Banner;Light Mummy Banner;Angry Bones Banner;Ice Tortoise Banner;Damage Booster;Life Booster;Mana Booster;Vortex Fragment;Nebula Fragment;Solar Fragment;Stardust Fragment;Luminite;Luminite Brick;Stardust Axe;Stardust Saw;Stardust Drill;Stardust Hammer;Stardust Pickaxe;Luminite Bar;Solar Wings;Vortex Booster;Nebula Mantle;Stardust Wings;Luminite Brick Wall;Solar Eruption;Stardust Cell Staff;Vortex Beater;Nebula Arcanum;Blood Water;Wedding Veil;Wedding Dress;Platinum Bow;Platinum Hammer;Platinum Axe;Platinum Shortsword;Platinum Broadsword;Platinum Pickaxe;Tungsten Bow;Tungsten Hammer;Tungsten Axe;Tungsten Shortsword;Tungsten Broadsword;Tungsten Pickaxe;Lead Bow;Lead Hammer;Lead Axe;Lead Shortsword;Lead Broadsword;Lead Pickaxe;Tin Bow;Tin Hammer;Tin Axe;Tin Shortsword;Tin Broadsword;Tin Pickaxe;Copper Bow;Copper Hammer;Copper Axe;Copper Shortsword;Copper Broadsword;Copper Pickaxe;Silver Bow;Silver Hammer;Silver Axe;Silver Shortsword;Silver Broadsword;Silver Pickaxe;Gold Bow;Gold Hammer;Gold Axe;Gold Shortsword;Gold Broadsword;Gold Pickaxe;Solar Flare Hamaxe;Vortex Hamaxe;Nebula Hamaxe;Stardust Hamaxe;Solar Dye;Nebula Dye;Vortex Dye;Stardust Dye;Void Dye;Stardust Dragon Staff;Bacon;Shifting Sands Dye;Mirage Dye;Shifting Pearlsands Dye;Vortex Monolith;Nebula Monolith;Stardust Monolith;Solar Monolith;Phantasm;Last Prism;Nebula Blaze;Daybreak;Super Healing Potion;Detonator;Celebration;Bouncy Dynamite;Happy Grenade;Ancient Manipulator;Flame and Silver Dye;Green Flame and Silver Dye;Blue Flame and Silver Dye;Reflective Copper Dye;Reflective Obsidian Dye;Reflective Metal Dye;Midnight Rainbow Dye;Black and White Dye;Bright Silver Dye;Silver and Black Dye;Red Acid Dye;Gel Dye;Pink Gel Dye;Red Squirrel;Gold Squirrel;Red Squirrel Cage;Gold Squirrel Cage;Luminite Bullet;Luminite Arrow;Lunar Portal Staff;Lunar Flare;Rainbow Crystal Staff;Lunar Hook;Solar Fragment Block;Vortex Fragment Block;Nebula Fragment Block;Stardust Fragment Block;Suspicious Looking Tentacle;Yoraiz0rs Uniform;Yoraiz0rs Skirt;Yoraiz0rs Spell;Yoraiz0rs Scowl;Jims Wings;Yoraiz0rs Recolored Goggles;Living Leaf Wall;Skiphs Mask;Skiphs Skin;Skiphs Bear Butt;Skiphs Paws;Lokis Helmet;Lokis Breastplate;Lokis Greaves;Lokis Wings;Sand Slime Banner;Sea Snail Banner;Moon Lord Trophy;Not a Kid, nor a Squid;Burning Hades Dye;Grim Dye;Lokis Dye;Shadowflame Hades Dye;Celestial Sigil;Logic Gate Lamp (Off);Logic Gate (AND);Logic Gate (OR);Logic Gate (NAND);Logic Gate (NOR);Logic Gate (XOR);Logic Gate (XNOR);Conveyor Belt (Clockwise);Conveyor Belt (Counter Clockwise);The Grand Design;Yellow Wrench;Logic Sensor (Day);Logic Sensor (Night);Logic Sensor (Player Above);Junction Box;Announcement Box;Logic Gate Lamp (On);Mechanical Lens;Actuation Rod;Red Team Block;Red Team Platform;Static Hook;Presserator;Multicolor Wrench;Pink Weighted Pressure Plate;Engineering Helmet;Companion Cube;Wire Bulb;Orange Weighted Pressure Plate;Purple Weighted Pressure Plate;Cyan Weighted Pressure Plate;Green Team Block;Blue Team Block;Yellow Team Block;Pink Team Block;White Team Block;Green Team Platform;Blue Team Platform;Yellow Team Platform;Pink Team Platform;White Team Platform;Large Amber;Ruby Gem Lock;Sapphire Gem Lock;Emerald Gem Lock;Topaz Gem Lock;Amethyst Gem Lock;Diamond Gem Lock;Amber Gem Lock;Squirrel Statue;Butterfly Statue;Worm Statue;Firefly Statue;Scorpion Statue;Snail Statue;Grasshopper Statue;Mouse Statue;Duck Statue;Penguin Statue;Frog Statue;Buggy Statue;Logic Gate Lamp (Faulty);Portal Gun Station;Trapped Chest;Trapped Gold Chest;Trapped Shadow Chest;Trapped Ebonwood Chest;Trapped Rich Mahogany Chest;Trapped Pearlwood Chest;Trapped Ivy Chest;Trapped Frozen Chest;Trapped Living Wood Chest;Trapped Skyware Chest;Trapped Shadewood Chest;Trapped Web Covered Chest;Trapped Lihzahrd Chest;Trapped Water Chest;Trapped Jungle Chest;Trapped Corruption Chest;Trapped Crimson Chest;Trapped Hallowed Chest;Trapped Ice Chest;Trapped Dynasty Chest;Trapped Honey Chest;Trapped Steampunk Chest;Trapped Palm Wood Chest;Trapped Mushroom Chest;Trapped Boreal Wood Chest;Trapped Slime Chest;Trapped Green Dungeon Chest;Trapped Pink Dungeon Chest;Trapped Blue Dungeon Chest;Trapped Bone Chest;Trapped Cactus Chest;Trapped Flesh Chest;Trapped Obsidian Chest;Trapped Pumpkin Chest;Trapped Spooky Chest;Trapped Glass Chest;Trapped Martian Chest;Trapped Meteorite Chest;Trapped Granite Chest;Trapped Marble Chest;ItemName.Fake_newchest1;ItemName.Fake_newchest2;Teal Pressure Pad;Wall Creeper Statue;Unicorn Statue;Drippler Statue;Wraith Statue;Bone Skeleton Statue;Undead Viking Statue;Medusa Statue;Harpy Statue;Pigron Statue;Hoplite Statue;Granite Golem Statue;Armed Zombie Statue;Blood Zombie Statue;Angler Tackle Bag;Geyser;Ultrabright Campfire;Bone Campfire;Pixel Box;Liquid Sensor (Water);Liquid Sensor (Lava);Liquid Sensor (Honey);Liquid Sensor (Any);Bundled Party Balloons;Balloon Animal;Party Hat;Silly Sunflower Petals;Silly Sunflower Tops;Silly Sunflower Bottoms;Silly Pink Balloon;Silly Purple Balloon;Silly Green Balloon;Blue Streamer;Green Streamer;Pink Streamer;Silly Balloon Machine;Silly Tied Balloon (Pink);Silly Tied Balloon (Purple);Silly Tied Balloon (Green);Pigronata;Party Center;Silly Tied Bundle of Balloons;Party Present;Slice of Cake;Cog Wall;Sandfall Wall;Snowfall Wall;Sandfall Block;Snowfall Block;Snow Cloud;Pedguins Hood;Pedguins Jacket;Pedguins Trousers;Silly Pink Balloon Wall;Silly Purple Balloon Wall;Silly Green Balloon Wall;0x33s Aviators;Blue Phasesaber;Red Phasesaber;Green Phasesaber;Purple Phasesaber;White Phasesaber;Yellow Phasesaber;Djinns Curse;Ancient Horn;Mandible Blade;Ancient Headdress;Ancient Garments;Ancient Slacks;Forbidden Mask;Forbidden Robes;Forbidden Treads;Spirit Flame;Sand Elemental Banner;Pocket Mirror;Magic Sand Dropper;Forbidden Fragment;Lamia Tail;Lamia Wraps;Lamia Mask;Sky Fracture;Onyx Blaster;Sand Shark Banner;Bone Biter Banner;Flesh Reaver Banner;Crystal Thresher Banner;Angry Tumbler Banner;Ancient Cloth;Desert Spirit Lamp;Music Box (Sandstorm);Apprentices Hat;Apprentices Robe;Apprentices Trousers;Squires Great Helm;Squires Plating;Squires Greaves;Huntresss Wig;Huntresss Jerkin;Huntresss Pants;Monks Bushy Brow Bald Cap;Monks Shirt;Monks Pants;Apprentices Scarf;Squires Shield;Huntresss Buckler;Monks Belt;Defenders Forge;War Table;War Table Banner;Eternia Crystal Stand;Defender Medal;Flameburst Rod;Flameburst Cane;Flameburst Staff;Ale Tosser;Etherian Mana;Brand of the Inferno;Ballista Rod;Ballista Cane;Ballista Staff;Flying Dragon;Eternia Crystal;Lightning Aura Rod;Lightning Aura Cane;Lightning Aura Staff;Explosive Trap Rod;Explosive Trap Cane;Explosive Trap Staff;Sleepy Octopod;Ghastly Glaive;Etherian Goblin Bomber Banner;Etherian Goblin Banner;Old Ones Skeleton Banner;Drakin Banner;Kobold Glider Banner;Kobold Banner;Wither Beast Banner;Etherian Wyvern Banner;Etherian Javelin Thrower Banner;Etherian Lightning Bug Banner;;;;;;Tome of Infinite Wisdom;ItemName.BoringBow;Phantom Phoenix;Gato Egg;Creeper Egg;Dragon Egg;Sky Dragons Fury;Aerial Bane;Treasure Bag (Betsy);;;Betsy Mask;Dark Mage Mask;Ogre Mask;Betsy Trophy;Dark Mage Trophy;Ogre Trophy;Music Box (Old Ones Army);Betsys Wrath;Valhalla Knights Helm;Valhalla Knights Breastplate;Valhalla Knights Greaves;Dark Artists Hat;Dark Artists Robes;Dark Artists Leggings;Red Riding Hood;Red Riding Dress;Red Riding Leggings;Shinobi Infiltrators Helmet;Shinobi Infiltrators Torso;Shinobi Infiltrators Pants;Betsys Wings;Crystal Chest;Golden Chest;Trapped Crystal Chest;Trapped Golden Chest;Crystal Door;Crystal Chair;Crystal Candle;Crystal Lantern;Crystal Lamp;Crystal Candelabra;Crystal Chandelier;Crystal Bathtub;Crystal Sink;Crystal Bed;Crystal Clock;Sunplate Clock;Blue Dungeon Clock;Green Dungeon Clock;Pink Dungeon Clock;Crystal Platform;Golden Platform;Dynasty Wood Platform;Lihzahrd Platform;Flesh Platform;Frozen Platform;Crystal Work Bench;Golden Work Bench;Crystal Dresser;Dynasty Dresser;Frozen Dresser;Living Wood Dresser;Crystal Piano;Dynasty Piano;Crystal Bookcase;Crystal Sofa;Dynasty Sofa;Crystal Table;Arkhalis Hood;Arkhalis Bodice;Arkhalis Tights;Arkhalis Lightwings;Leinfors Hair Protector;Leinfors Excessive Style;Leinfors Fancypants;Leinfors Prehensile Cloak;Leinfors Luxury Shampoo;Celebration Mk2;Spider Bathtub;Spider Bed;Spider Bookcase;Spider Dresser;Spider Candelabra;Spider Candle;Spider Chair;Spider Chandelier;Spider Chest;Spider Clock;Spider Door;Spider Lamp;Spider Lantern;Spider Piano;Spider Platform;Spider Sink;Spider Sofa;Spider Table;Spider Work Bench;Trapped Spider Chest;Iron Brick;Iron Brick Wall;Lead Brick;Lead Brick Wall;Lesion Block;Lesion Block Wall;Lesion Platform;Lesion Bathtub;Lesion Bed;Lesion Bookcase;Lesion Candelabra;Lesion Candle;Lesion Chair;Lesion Chandelier;Lesion Chest;Lesion Clock;Lesion Door;Lesion Dresser;Lesion Lamp;Lesion Lantern;Lesion Piano;Lesion Sink;Lesion Sofa;Lesion Table;Lesion Work Bench;Trapped Lesion Chest;Hat Rack;;Pearlwood Crate;Mythril Crate;Titanium Crate;Defiled Crate;Hematic Crate;Stockade Crate;Azure Crate;Divine Crate;Bramble Crate;Dead Mans Chest;Golf Ball;Amphibian Boots;Arcane Flower;Berserkers Glove;Fairy Boots;Frog Flipper;Frog Gear;Frog Webbing;Frozen Shield;Hero Shield;Magma Skull;Magnet Flower;Mana Cloak;Molten Quiver;Molten Skull Rose;Obsidian Skull Rose;Recon Scope;Stalkers Quiver;Stinger Necklace;Ultrabright Helmet;Apple;;Apple Pie;Banana Split;BBQ Ribs;Bunny Stew;Burger;Chicken Nugget;Chocolate Chip Cookie;Cream Soda;Escargot;Fried Egg;Fries;Golden Delight;Grapes;Grilled Squirrel;Hotdog;Ice Cream;Milkshake;Nachos;Pizza;Potato Chips;Roasted Bird;Roasted Duck;Sauteed Frog Legs;Seafood Dinner;Shrimp Po Boy;Spaghetti;Steak;Molten Charm;Golf Club (Iron);Golf Cup;Blue Flower Seeds;Magenta Flower Seeds;Pink Flower Seeds;Red Flower Seeds;Yellow Flower Seeds;Violet Flower Seeds;White Flower Seeds;Tall Grass Seeds;Lawn Mower;Crimstone Brick;Smooth Sandstone;Crimstone Brick Wall;Smooth Sandstone Wall;Blood Moon Monolith;Dunerider Boots;Ancient Chisel;Rain Song;;Fossil Pickaxe;Super Star Shooter;Storm Spear;Thunder Zapper;Drum Set;Picnic Table;Fancy Picnic Table;Desert Minecart;Minecarp;Pink Fairy;Green Fairy;Blue Fairy;Junonia Shell;Lightning Whelk Shell;Tulip Shell;Pin Wheel;Weather Vane;Void Vault;Music Box (Ocean Night);Music Box (Slime Rain);Music Box (Space Day);Music Box (Town Day);Music Box (Town Night);Music Box (Windy Day);White Pin Flag;Red Pin Flag;Green Pin Flag;Blue Pin Flag;Yellow Pin Flag;Purple Pin Flag;Golf Tee;Shell Pile;Anti-Portal Block;Golf Club (Putter);Golf Club (Wedge);Golf Club (Driver);Golf Whistle;Ebonwood Toilet;Rich Mahogany Toilet;Pearlwood Toilet;Living Wood Toilet;Cactus Toilet;Bone Toilet;Flesh Toilet;Mushroom Toilet;Skyware Toilet;Shadewood Toilet;Lihzahrd Toilet;Blue Dungeon Toilet;Green Dungeon Toilet;Pink Dungeon Toilet;Obsidian Toilet;Frozen Toilet;Glass Toilet;Honey Toilet;Steampunk Toilet;Pumpkin Toilet;Spooky Toilet;Dynasty Toilet;Palm Wood Toilet;Boreal Wood Toilet;Slime Toilet;Martian Toilet;Granite Toilet;Marble Toilet;Crystal Toilet;Spider Toilet;Lesion Toilet;Diamond Toilet;Maid Bonnet;Maid Dress;Maid Shoes;Void Bag;Pink Maid Bonnet;Pink Maid Dress;Pink Maid Shoes;Country Club Cap;Country Club Vest;Country Club Trousers;Country Club Visor;Spider Nest Block;Spider Nest Wall;Meteor Toilet;Decay Chamber;ManaCloakStar;Terragrim;Solar Bathtub;Solar Bed;Solar Bookcase;Solar Dresser;Solar Candelabra;Solar Candle;Solar Chair;Solar Chandelier;Solar Chest;Solar Clock;Solar Door;Solar Lamp;Solar Lantern;Solar Piano;Solar Platform;Solar Sink;Solar Sofa;Solar Table;Solar Work Bench;Trapped Solar Chest;Solar Toilet;Vortex Bathtub;Vortex Bed;Vortex Bookcase;Vortex Dresser;Vortex Candelabra;Vortex Candle;Vortex Chair;Vortex Chandelier;Vortex Chest;Vortex Clock;Vortex Door;Vortex Lamp;Vortex Lantern;Vortex Piano;Vortex Platform;Vortex Sink;Vortex Sofa;Vortex Table;Vortex Work Bench;Trapped Vortex Chest;Vortex Toilet;Nebula Bathtub;Nebula Bed;Nebula Bookcase;Nebula Dresser;Nebula Candelabra;Nebula Candle;Nebula Chair;Nebula Chandelier;Nebula Chest;Nebula Clock;Nebula Door;Nebula Lamp;Nebula Lantern;Nebula Piano;Nebula Platform;Nebula Sink;Nebula Sofa;Nebula Table;Nebula Work Bench;Trapped Nebula Chest;Nebula Toilet;Stardust Bathtub;Stardust Bed;Stardust Bookcase;Stardust Dresser;Stardust Candelabra;Stardust Candle;Stardust Chair;Stardust Chandelier;Stardust Chest;Stardust Clock;Stardust Door;Stardust Lamp;Stardust Lantern;Stardust Piano;Stardust Platform;Stardust Sink;Stardust Sofa;Stardust Table;Stardust Work Bench;Trapped Stardust Chest;Stardust Toilet;Solar Brick;Vortex Brick;Nebula Brick;Stardust Brick;Solar Brick Wall;Vortex Brick Wall;Nebula Brick Wall;Stardust Brick Wall;Music Box (Day Remix);Cracked Blue Brick;Cracked Green Brick;Cracked Pink Brick;Wild Flower Seeds;Black Golf Ball;Blue Golf Ball;Brown Golf Ball;Cyan Golf Ball;Green Golf Ball;Lime Golf Ball;Orange Golf Ball;Pink Golf Ball;Purple Golf Ball;Red Golf Ball;Sky Blue Golf Ball;Teal Golf Ball;Violet Golf Ball;Yellow Golf Ball;Amber Robe;Amber Hook;Orange Phaseblade;Orange Phasesaber;Orange Stained Glass;Orange Pressure Plate;Snake Charmers Flute;Magic Conch;Golf Cart Keys;Golf Chest;Trapped Golf Chest;Sandstone Chest;Trapped Sandstone Chest;Sanguine Staff;Blood Thorn;Bloody Tear;Drippler Crippler;Vampire Frog Staff;Gold Goldfish;Gold Fish Bowl;Bast Statue;Gold Starry Block;Blue Starry Block;Gold Starry Wall;Blue Starry Wall;Finch Staff;Apricot;Banana;Blackcurrant;Blood Orange;Cherry;Coconut;Dragon Fruit;Elderberry;Grapefruit;Lemon;Mango;Peach;Pineapple;Plum;Rambutan;Star Fruit;Sandstone Bathtub;Sandstone Bed;Sandstone Bookcase;Sandstone Dresser;Sandstone Candelabra;Sandstone Candle;Sandstone Chair;Sandstone Chandelier;Sandstone Clock;Sandstone Door;Sandstone Lamp;Sandstone Lantern;Sandstone Piano;Sandstone Platform;Sandstone Sink;Sandstone Sofa;Sandstone Table;Sandstone Work Bench;Sandstone Toilet;Haemorrhaxe;Void Monolith;Arrow Sign;Painted Arrow Sign;Master Gamers Jacket;Master Gamers Pants;Star Princess Crown;Star Princess Dress;Chum Caster;Plate;Black Dragonfly Jar;Blue Dragonfly Jar;Green Dragonfly Jar;Orange Dragonfly Jar;Red Dragonfly Jar;Yellow Dragonfly Jar;Gold Dragonfly Jar;Black Dragonfly;Blue Dragonfly;Green Dragonfly;Orange Dragonfly;Red Dragonfly;Yellow Dragonfly;Gold Dragonfly;Step Stool;Dragonfly Statue;Paper Airplane;White Paper Airplane;Can Of Worms;Encumbering Stone;Gray Zapinator;Orange Zapinator;Green Moss;Brown Moss;Red Moss;Blue Moss;Purple Moss;Lava Moss;Boulder Statue;Music Box (Journeys Beginning);Music Box (Storm);Music Box (Graveyard);Seagull;Seagull Statue;Ladybug;Gold Ladybug;Maggot;Maggot Cage;Celestial Wand;Eucalyptus Sap;Blue Kite;Blue and Yellow Kite;Red Kite;Red and Yellow Kite;Yellow Kite;Ivy;Pupfish;Grebe;Rat;Rat Cage;Krypton Moss;Xenon Moss;Wyvern Kite;Ladybug Cage;Blood Rain Bow;Advanced Combat Techniques;Desert Torch;Coral Torch;Corrupt Torch;Crimson Torch;Hallowed Torch;Jungle Torch;Argon Moss;Rolling Cactus;Thin Ice;Echo Block;Scarab Fish;Scorpio Fish;Owl;Owl Cage;Owl Statue;Pupfish Bowl;Gold Ladybug Cage;Geode;Flounder;Rock Lobster;Lobster Tail;Inner Tube;Frozen Crate;Boreal Crate;Oasis Crate;Mirage Crate;Spectre Goggles;Oyster;Shucked Oyster;White Pearl;Black Pearl;Pink Pearl;Stone Door;Stone Platform;Oasis Water Fountain;Water Strider;Gold Water Strider;Lawn Flamingo;Music Box (Underground Jungle);Grate;Scarab Bomb;Wrought Iron Fence;Shark Bait;Bee Minecart;Ladybug Minecart;Pigron Minecart;Sunflower Minecart;Potted Forest Cedar;Potted Jungle Cedar;Potted Hallow Cedar;Potted Forest Tree;Potted Jungle Tree;Potted Hallow Tree;Potted Forest Palm;Potted Jungle Palm;Potted Hallow Palm;Potted Forest Bamboo;Potted Jungle Bamboo;Potted Hallow Bamboo;Scarab Fishing Rod;Demonic Hellcart;Witchs Broom;Cluster Rocket I;Cluster Rocket II;Wet Rocket;Lava Rocket;Honey Rocket;Shroom Minecart;Amethyst Minecart;Topaz Minecart;Sapphire Minecart;Emerald Minecart;Ruby Minecart;Diamond Minecart;Mini Nuke I;Mini Nuke II;Dry Rocket;Sandcastle Bucket;Turtle Cage;Jungle Turtle Cage;Gladius;Turtle;Jungle Turtle;Turtle Statue;Amber Minecart;Beetle Minecart;Meowmere Minecart;Party Wagon;The Dutchman;Steampunk Minecart;Grebe Cage;Seagull Cage;Water Strider Cage;Gold Water Strider Cage;Lesser Luck Potion;Luck Potion;Greater Luck Potion;Seahorse;Seahorse Cage;Gold Seahorse;Gold Seahorse Cage;1/2 Second Timer;1/4 Second Timer;Ebonstone Wall;Mud Wall;Pearlstone Wall;Snow Wall;Amethyst Stone Wall;Topaz Stone Wall;Sapphire Stone Wall;Emerald Stone Wall;Ruby Stone Wall;Diamond Stone Wall;Green Mossy Wall;Brown Mossy Wall;Red Mossy Wall;Blue Mossy Wall;Purple Mossy Wall;Rocky Dirt Wall;Old Stone Wall;Spider Wall;Corrupt Grass Wall;Hallowed Grass Wall;Ice Wall;Obsidian Wall;Crimson Grass Wall;Crimstone Wall;Cave Dirt Wall;Rough Dirt Wall;Craggy Stone Wall;Corrupt Growth Wall;Corrupt Mass Wall;Corrupt Pustule Wall;Corrupt Tendril Wall;Crimson Crust Wall;Crimson Scab Wall;Crimson Teeth Wall;Crimson Blister Wall;Layered Dirt Wall;Crumbling Dirt Wall;Cracked Dirt Wall;Wavy Dirt Wall;Hallowed Prism Wall;Hallowed Cavern Wall;Hallowed Shard Wall;Hallowed Crystalline Wall;Lichen Stone Wall;Leafy Jungle Wall;Ivy Stone Wall;Jungle Vine Wall;Ember Wall;Cinder Wall;Magma Wall;Smouldering Stone Wall;Worn Stone Wall;Stalactite Stone Wall;Mottled Stone Wall;Fractured Stone Wall;The Bride Banner;Zombie Merman Banner;Wandering Eye Fish Banner;Blood Squid Banner;Blood Eel Banner;Hemogoblin Shark Banner;Large Bamboo;Large Bamboo Wall;Demon Horns;Bamboo Leaf;Slice of Hell Cake;Fog Machine;Plasma Lamp;Marble Column;Chef Hat;Chef Uniform;Chef Pants;Star Hairpin;Heart Hairpin;Bunny Ears;Devil Horns;Fedora;Fake Unicorn Horn;Bamboo;Bamboo Wall;Bamboo Bathtub;Bamboo Bed;Bamboo Bookcase;Bamboo Dresser;Bamboo Candelabra;Bamboo Candle;Bamboo Chair;Bamboo Chandelier;Bamboo Chest;Bamboo Clock;Bamboo Door;Bamboo Lamp;Bamboo Lantern;Bamboo Piano;Bamboo Platform;Bamboo Sink;Bamboo Sofa;Bamboo Table;Bamboo Work Bench;Trapped Bamboo Chest;Bamboo Toilet;Worn Golf Club (Iron);Worn Golf Club (Putter);Worn Golf Club (Wedge);Worn Golf Club (Driver);Fancy Golf Club (Iron);Fancy Golf Club (Putter);Fancy Golf Club (Wedge);Fancy Golf Club (Driver);Premium Golf Club (Iron);Premium Golf Club (Putter);Premium Golf Club (Wedge);Premium Golf Club (Driver);Bronze Golf Trophy;Silver Golf Trophy;Gold Golf Trophy;Dreadnautilus Banner;Birdie Rattle;Exotic Chew Toy;Bedazzled Nectar;Music Box (Jungle Night);Desert Tiger Staff;Chum Bucket;Garden Gnome;Bone Serpent Kite;World Feeder Kite;Bunny Kite;Pigron Kite;Apple Juice;Grape Juice;Lemonade;Frozen Banana Daiquiri;Peach Sangria;Piña Colada;Tropical Smoothie;Bloody Moscato;Smoothie of Darkness;Prismatic Punch;Fruit Juice;Fruit Salad;Andrew Sphinx;Watchful Antlion;Burning Spirit;Jaws of Death;The Sands of Slime;Snakes, I Hate Snakes;Life Above the Sand;Oasis;Prehistory Preserved;Ancient Tablet;Uluru;Visiting the Pyramids;Bandage Boy;Divine Eye;Amethyst Stone Block;Topaz Stone Block;Sapphire Stone Block;Emerald Stone Block;Ruby Stone Block;Diamond Stone Block;Amber Stone Block;Amber Stone Wall;Man Eater Kite;Blue Jellyfish Kite;Pink Jellyfish Kite;Shark Kite;Superhero Mask;Superhero Costume;Superhero Tights;Pink Fairy Jar;Green Fairy Jar;Blue Fairy Jar;The Rolling Greens;Study of a Ball at Rest;Fore!;The Duplicity of Reflections;Fogbound Dye;Bloodbath Dye;Pretty Pink Dress;Pretty Pink Stockings;Pretty Pink Ribbon;Bamboo Fence;Illuminant Coating;Sand Shark Kite;Corrupt Bunny Kite;Crimson Bunny Kite;Leather Whip;Drumstick;Goldfish Kite;Angry Trapper Kite;Koi Kite;Crawltipede Kite;Durendal;Morning Star;Dark Harvest;Spectrum Kite;Release Doves;Wandering Eye Kite;Unicorn Kite;Gravedigger Hat;Gravedigger Coat;Angry Dandelion Banner;Gnome Banner;Desert Campfire;Coral Campfire;Corrupt Campfire;Crimson Campfire;Hallowed Campfire;Jungle Campfire;Soul of Light in a Bottle;Soul of Night in a Bottle;Soul of Flight in a Bottle;Soul of Sight in a Bottle;Soul of Might in a Bottle;Soul of Fright in a Bottle;Mud Bud;Release Lantern;Quad-Barrel Shotgun;Funeral Hat;Funeral Coat;Funeral Pants;Tragic Umbrella;Victorian Goth Hat;Victorian Goth Dress;Tattered Wood Sign;Gravediggers Shovel;Desert Chest;Trapped Desert Chest;Desert Key;Stellar Tune;Mollusk Whistle;Boreal Beam;Rich Mahogany Beam;Granite Column;Sandstone Column;Mushroom Beam;;Nevermore;Reborn;Graveyard;Ghost Manifestation;Wicked Undead;Bloody Goblet;Still Life;Ghostar’s Infinity Eight;Terra Toilet;Ghostar’s Soul Jar;Ghostar’s Garb;Ghostar’s Tights;Ball O Fuse Wire;Full Moon Squeaky Toy;Ornate Shadow Key;Dr. Man Fly Mask;Dr. Man Flys Lab Coat;Butcher Mask;Butchers Bloodstained Apron;Butchers Bloodstained Pants;Football;Hunter Cloak;Coffin Minecart;Safemans Blanket Cape;Safemans Sunny Day;Safemans Sun Dress;Safemans Pink Leggings;FoodBarbarians Tattered Dragon Wings;FoodBarbarians Horned Helm;FoodBarbarians Wild Wolf Spaulders;FoodBarbarians Savage Greaves;Grox The Greats Wings;Grox The Greats Horned Cowl;Grox The Greats Chestplate;Grox The Greats Greaves;Blade Staff;Squirrel Hook;Sergeant United Shield;Rock Golem Head;Critter Shampoo;Digging Molecart;Shroomerang;Tree Globe;World Globe;Guide To Critter Companionship;Dog Ears;Dog Tail;Fox Ears;Fox Tail;Lizard Ears;Lizard Tail;Panda Ears;Bunny Tail;Fairy Glowstick;Lightning Carrot;Prismatic Dye;Mushroom Hat;Mushroom Vest;Mushroom Pants;Treasure Bag (Empress of Light);Empress of Light Trophy;Empress of Light Mask;Dusty Rawhide Saddle;Royal Gilded Saddle;Black Studded Saddle;Jousting Lance;Shadow Jousting Lance;Hallowed Jousting Lance;Pogo Stick;The Black Spot;Hexxed Branch;Toy Tank;Goat Skull;Dark Mages Tome;Royal Delight;Suspicious Grinning Eye;Writhing Remains;Brain in a Jar;Possessed Skull;Sparkling Honey;Deactivated Probe;Pair of Eyeballs;Robotic Skull;Plantera Seedling;Guardian Golem;Pork of the Sea;Tablet Fragment;Piece of Moon Squid;Jewel of Light;Pumpkin Scented Candle;Shrub Star;Frozen Crown;Cosmic Skateboard;Ogres Club;Betsys Egg;Combat Wrench;Demon Conch;Bottomless Lava Bucket;Lavaproof Bug Net;Flame Waker Boots;Empress Wings;Wet Bomb;Lava Bomb;Honey Bomb;Dry Bomb;Superheated Blood;Cat License;Dog License;Amethyst Squirrel;Topaz Squirrel;Sapphire Squirrel;Emerald Squirrel;Ruby Squirrel;Diamond Squirrel;Amber Squirrel;Amethyst Bunny;Topaz Bunny;Sapphire Bunny;Emerald Bunny;Ruby Bunny;Diamond Bunny;Amber Bunny;Hell Butterfly;Hell Butterfly Jar;Lavafly;Lavafly in a Bottle;Magma Snail;Magma Snail Cage;Topaz Gemcorn;Amethyst Gemcorn;Sapphire Gemcorn;Emerald Gemcorn;Ruby Gemcorn;Diamond Gemcorn;Amber Gemcorn;Hanging Pot;Hanging Daybloom;Hanging Moonglow;Hanging Waterleaf;Hanging Shiverthorn;Hanging Blinkroot;Hanging Corrupt Deathweed;Hanging Crimson Deathweed;Hanging Fireblossom;Hanging Brazier;Mini Volcano;Large Volcano;Potion of Return;Sakura Sapling;Lava Absorbant Sponge;Hallowed Hood;Hellfire Treads;Jungle Pylon;Forest Pylon;Obsidian Crate;Hellstone Crate;Obsidian Lock Box;Lava Serpent Bowl;Lavaproof Fishing Hook;Amethyst Bunny Cage;Topaz Bunny Cage;Sapphire Bunny Cage;Emerald Bunny Cage;Ruby Bunny Cage;Diamond Bunny Cage;Amber Bunny Cage;Amethyst Squirrel Cage;Topaz Squirrel Cage;Sapphire Squirrel Cage;Emerald Squirrel Cage;Ruby Squirrel Cage;Diamond Squirrel Cage;Amber Squirrel Cage;Ancient Hallowed Mask;Ancient Hallowed Helmet;Ancient Hallowed Headgear;Ancient Hallowed Hood;Ancient Hallowed Plate Mail;Ancient Hallowed Greaves;Potted Magma Palm;Potted Brimstone Bush;Potted Fire Brambles;Potted Lava Bulb;Potted Ember Tendrils;Yellow Willow Sapling;Dirt Bomb;Sticky Dirt Bomb;Bunny License;Cool Whip;Firecracker;Snapthorn;Kaleidoscope;Tungsten Bullet;Hallow Pylon;Cavern Pylon;Ocean Pylon;Desert Pylon;Snow Pylon;Mushroom Pylon;Cavern Water Fountain;Starlight;Eye of Cthulhu Relic;Eater of Worlds Relic;Brain of Cthulhu Relic;Skeletron Relic;Queen Bee Relic;King Slime Relic;Wall of Flesh Relic;Twins Relic;Destroyer Relic;Skeletron Prime Relic;Plantera Relic;Golem Relic;Duke Fishron Relic;Lunatic Cultist Relic;Moon Lord Relic;Martian Saucer Relic;Flying Dutchman Relic;Mourning Wood Relic;Pumpking Relic;Ice Queen Relic;Everscream Relic;Santa-NK1 Relic;Dark Mage Relic;Ogre Relic;Betsy Relic;Empress of Light Relic;Queen Slime Relic;Universal Pylon;Nightglow;Eventide;Celestial Starboard;Rabbit Perch;Zenith;Treasure Bag (Queen Slime);Queen Slime Trophy;Queen Slime Mask;Regal Delicacy;Prismatic Lacewing;Stone Accent Slab;Truffle Worm Cage;Prismatic Lacewing Jar;Rock Golem Banner;Blood Mummy Banner;Spore Skeleton Banner;Spore Bat Banner;Antlion Larva Banner;Vicious Bunny Banner;Vicious Goldfish Banner;Vicious Penguin Banner;Corrupt Mimic Banner;Crimson Mimic Banner;Hallowed Mimic Banner;Moss Hornet Banner;Wandering Eye Banner;Fledgling Wings;Music Box (Queen Slime);Hook of Dissonance;Gelatinous Pillion;Crystal Assassin Hood;Crystal Assassin Shirt;Crystal Assassin Pants;Music Box (Empress Of Light);Sparkle Slime Balloon;Volatile Gelatin;Gelatin Crystal;Soaring Insignia;Music Box (Duke Fishron);Music Box (Morning Rain);Music Box (Alt Title);Chippys Couch;Blue Graduation Cap;Maroon Graduation Cap;Black Graduation Cap;Blue Graduation Gown;Maroon Graduation Gown;Black Graduation Gown;Terraspark Boots;Moon Lord Legs;Ocean Crate;Seaside Crate;Badgers Hat;Terraprisma;Music Box (Underground Desert);Dead Mans Sweater;Teapot;Teacup;Treasure Magnet;Mace;Flaming Mace;;Otherworldly Music Box (Rain);Otherworldly Music Box (Overworld Day);Otherworldly Music Box (Night);Otherworldly Music Box (Underground);Otherworldly Music Box (Desert);Otherworldly Music Box (Ocean);Otherworldly Music Box (Mushrooms);Otherworldly Music Box (Dungeon);Otherworldly Music Box (Space);Otherworldly Music Box (Underworld);Otherworldly Music Box (Snow);Otherworldly Music Box (Corruption);Otherworldly Music Box (Underground Corruption);Otherworldly Music Box (Crimson);Otherworldly Music Box (Underground Crimson);Otherworldly Music Box (Ice);Otherworldly Music Box (Underground Hallow);Otherworldly Music Box (Eerie);Otherworldly Music Box (Boss 2);Otherworldly Music Box (Boss 1);Otherworldly Music Box (Invasion);Otherworldly Music Box (The Towers);Otherworldly Music Box (Lunar Boss);Otherworldly Music Box (Plantera);Otherworldly Music Box (Jungle);Otherworldly Music Box (Wall of Flesh);Otherworldly Music Box (Hallow);Carton of Milk;Coffee;Torch Gods Favor;Music Box (Journeys End);Plaguebringers Skull;Plaguebringers Cloak;Plaguebringers Treads;Wandering Jingasa;Wandering Yukata;Wandering Geta;Timeless Travelers Hood;Timeless Travelers Cloak;Timeless Travelers Footwear;Floret Protector Helmet;Floret Protector Shirt;Floret Protector Pants;Capricorn Helmet;Capricorn Chestplate;Capricorn Hooves;Capricorn Tail;Video Visage;Lazer Blazer;Pinstripe Pants;Lavaproof Tackle Bag;Resonance Scepter;Bee Hive;Antlion Eggs;Flinx Fur Coat;Flinx Staff;Flinx Fur;Royal Tiara;Royal Blouse;Royal Dress;Spinal Tap;Rainbow Cursor;Royal Scepter;Glass Slipper;Prince Uniform;Prince Pants;Prince Cape;Potted Crystal Fern;Potted Crystal Spiral;Potted Crystal Teardrop;Potted Crystal Tree;Princess 64;Painting of a Lass;Dark Side of the Hallow;Bernies Button;Glommers Flower;Deerclops Eyeball;Monster Meat;Monster Lasagna;Froggle Bunwich;Tentacle Spike;Lucy the Axe;Ham Bat;Bat Bat;Eye Bone;Garland;Bone Helm;Eyebrella;Gentlemans Vest;Gentlemans Trousers;Gentlemans Beard;Gentlemans Long Beard;Gentlemans Magnificent Beard;Magiluminescence;Deerclops Trophy;Deerclops Mask;Deerclops Relic;Treasure Bag (Deerclops);Music Box (Deerclops);Radio Thing;Abigails Flower;Firestarters Sweater;Firestarters Skirt;Pew-matic Horn;Weather Pain;Houndius Shootius;Deer Thing;The Gentleman Scientist;The Firestarter;The Bereaved;The Strongman;Fart Kart;Hand Of Creation;Neon Moss;Helium Moss;Flymeal;Liliths Necklace;Resplendent Dessert;Stinkbug;Stinkbug Cage;Terraformer;Venom Dart Trap;Vulkelf Ears;Stinkbug Blocker;Ghostly Stinkbug Blocker;Fishing Bobber;Glowing Fishing Bobber;Lava Moss Fishing Bobber;Krypton Moss Fishing Bobber;Xenon Moss Fishing Bobber;Argon Moss Fishing Bobber;Neon Moss Fishing Bobber;Helium Moss Fishing Bobber;Wand of Frosting;Reef Bathtub;Reef Bed;Reef Bookcase;Reef Dresser;Reef Candelabra;Reef Candle;Reef Chair;Reef Chandelier;Reef Chest;Reef Clock;Reef Door;Reef Lamp;Reef Lantern;Reef Piano;Reef Platform;Reef Sink;Reef Sofa;Reef Table;Reef Work Bench;Trapped Reef Chest;Reef Toilet;Balloon Bathtub;Balloon Bed;Balloon Bookcase;Balloon Dresser;Balloon Candelabra;Balloon Candle;Balloon Chair;Balloon Chandelier;Balloon Chest;Balloon Clock;Balloon Door;Balloon Lamp;Balloon Lantern;Balloon Piano;Balloon Platform;Balloon Sink;Balloon Sofa;Balloon Table;Balloon Work Bench;Trapped Balloon Chest;Balloon Toilet;Ash Wood Bathtub;Ash Wood Bed;Ash Wood Bookcase;Ash Wood Dresser;Ash Wood Candelabra;Ash Wood Candle;Ash Wood Chair;Ash Wood Chandelier;Ash Wood Chest;Ash Wood Clock;Ash Wood Door;Ash Wood Lamp;Ash Wood Lantern;Ash Wood Piano;Ash Wood Platform;Ash Wood Sink;Ash Wood Sofa;Ash Wood Table;Ash Wood Work Bench;Trapped Ash Wood Chest;Ash Wood Toilet;Biome Sight Potion;Scarlet Macaw;Scarlet Macaw Cage;Ash Grass Seeds;Ash Wood;Ash Wood Wall;Ash Wood Fence;Outcast;Fairy Guides;A Horrible Night for Alchemy;Morning Hunt;Suspiciously Sparkly;Requiem;Cat Sword;Kargohs Summon;High Pitch;A Machine for Terrarians;Terra Blade Chronicles;Benny Warhol;Lizard King;My Son;Duality;Parsec Pals;Remnants of Devotion;Not So Lost In Paradise;Ocular Resonance;Wings of Evil;Constellation;Eyezorhead;Dread of the Red Sea;Do Not Eat the Vile Mushroom!;Yuuma, The Blue Tiger;Moonman & Company;Sunshine of Israpony;Purity;Sufficiently Advanced;Strange Growth;Happy Little Tree;Strange Dead Fellows;Secrets;Thunderbolt;Crustography;The Werewolf;Blessing from the Heavens;Love is in the Trash Slot;Fangs;Hail to the King;See The World For What It Is;What Lurks Below;This Is Getting Out Of Hand;Buddies;Midnight Sun;Couch Gag;Silent Fish;The Duke;Royal Romance;Bioluminescence;Wildflowers;Viking Voyage;Bifrost;Heartlands;Forest Troll;Aurora Borealis;Lady Of The Lake;Joja Cola;Stardrop;Spicy Pepper;Pomegranate;Ash Wood Helmet;Ash Wood Breasplate;Ash Wood Greaves;Ash Wood Bow;Ash Wood Hammer;Ash Wood Sword;Moon Globe;Repaired Life Crystal;Repaired Mana Crystal;Terra Fart Kart;Minecart Upgrade Kit;Jims Cap;Echo Wall;Echo Platform;Mushroom Torch;Hive-Five;Axe of Regrowth;Chlorophyte Extractinator;Blue Chicken Egg;Trimarang;Mushroom Campfire;Blue Macaw;Blue Macaw Cage;Bottomless Honey Bucket;Honey Absorbant Sponge;Ultra Absorbant Sponge;Goblorc Ears;Reef Block;Reef Wall;r/Terraria;Guide to Environmental Preservation;Princess Style;Toucan;Yellow Cockatiel;Gray Cockatiel;Toucan Cage;Yellow Cockatiel Cage;Gray Cockatiel Cage;Macaw Statue;Toucan Statue;Cockatiel Statue;Decorative Healing Potion;Decorative Mana Potion;Shadow Candle;Guide to Peaceful Coexistence;Rubblemaker (Small);Closed Void Bag;Artisan Loaf;TNT Barrel;Chest Lock;Rubblemaker (Medium);Rubblemaker (Large);Bundle of Horseshoe Balloons;Spiffo Plush;Glow Tulip;Ocrams Razor;Rod of Harmony;Advanced Combat Techniques: Volume Two;Vital Crystal;Aegis Fruit;Arcane Crystal;Galaxy Pearl;Gummy Worm;Ambrosia;Peddlers Satchel;Echo Coating;Echo Chamber;Gas Trap;Aether Monolith;Shimmer Arrow;Aetherium Block;Faeling;Faeling in a Bottle;Shimmer Slime Banner;Aether Torch;Reflective Shades;Chromatic Cloak;Used Gas Trap;Aether Campfire;Shellphone (Home);Shellphone (Spawn);Shellphone (Ocean);Shellphone (Underworld);Music Box (Aether);Infested Spider Wall;Bottomless Shimmer Bucket;Cursed Blue Brick Wall;Cursed Blue Slab Wall;Cursed Blue Tiled Wall;Cursed Pink Brick Wall;Cursed Pink Slab Wall;Cursed Pink Tiled Wall;Cursed Green Brick Wall;Cursed Green Slab Wall;Cursed Green Tiled Wall;Treacherous Sandstone Wall;Treacherous Hardened Sand Wall;Forbidden Lihzahrd Brick Wall;Spelunker Flare;Cursed Flare;Rainbow Flare;Shimmer Flare;Enchanted Moondial;Waffles Iron;Bouncy Boulder;Life Crystal Boulder;Dizzys Rare Gecko Chester;Raynebros Hoodie;Raynebros Pants;Eye of the Sun;Cheesy Pizza Poster;Raynebros Hood;Uncumbering Stone;Yellow Solution;White Solution;Brown Solution;Poo;Poo Wall;Aetherium Wall;Aetherium Brick;Aetherium Brick Wall;The Dirtiest Block;Lunar Rust Brick;Dark Celestial Brick;Astra Brick;Cosmic Ember Brick;Cryocore Brick;Mercury Brick;Star Royale Brick;Heavenforge Brick;Lunar Rust Brick Wall;Dark Celestial Brick Wall;Astra Brick Wall;Cosmic Ember Brick Wall;Cryocore Brick Wall;Mercury Brick Wall;Star Royale Brick Wall;Heavenforge Brick Wall;Ancient Blue Brick;Ancient Blue Brick Wall;Ancient Green Brick;Ancient Green Brick Wall;Ancient Pink Brick;Ancient Pink Brick Wall;Ancient Gold Brick;Ancient Gold Brick Wall;Ancient Silver Brick;Ancient Silver Brick Wall;Ancient Copper Brick;Ancient Copper Brick Wall;Ancient Cobalt Brick;Ancient Cobalt Brick Wall;Ancient Mythril Brick;Ancient Mythril Brick Wall;Ancient Obsidian Brick;Ancient Obsidian Brick Wall;Ancient Hellstone Brick;Ancient Hellstone Brick Wall;Shellphone;Fertilizer;Lava Moss Brick;Argon Moss Brick;Krypton Moss Brick;Xenon Moss Brick;Neon Moss Brick;Helium Moss Brick;Lava Moss Brick Wall;Argon Moss Brick Wall;Krypton Moss Brick Wall;Xenon Moss Brick Wall;Neon Moss Brick Wall;Helium Moss Brick Wall;Kwad Racer Drone;FPV Goggles".split(";");
terra_data_TdItem.meta = "1;d1|d=5|t=20|k=2|tp=40|rg=1|z=2000;t|s=9999|rg=100;t|s=9999|rg=100;d1|d=12|t=20|k=5.5|rg=1|z=1800;c|s=9999|hl=15|t=17|rg=30|z=1250;d1|d=8|t=12|k=4|rg=1|z=1400;d1|d=7|t=30|k=5.5|th=40|rg=1|z=1600;t|s=9999|rg=100|1=Provides light|z=50;t|s=9999|rg=100;d1|d=5|t=27|k=4.5|tx=9|rg=1|z=1600;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=250;t|s=9999|rg=100|z=1500;t|s=9999|rg=100|z=750;a1|rg=1|1=Tells the time|z=1000;a1|rg=1|1=Tells the time|z=5000;a1|rg=1|1=Tells the time|z=10000;a1|rg=1|1=Displays depth|z=12500;t|s=9999|rg=25|z=6000;t|s=9999|rg=25|z=750;t|s=9999|rg=25|z=3000;t|s=9999|rg=25|z=1500;b|s=9999|rg=99|1=Both tasty and flammable|z=5;d1|d=7|t=20|k=5|rg=1|z=100;t|s=9999|rg=1|z=200;w|s=9999|rg=400;t|s=9999|rg=50|z=10;c|s=9999|hl=50|t=17|rg=30|z=300;c|s=9999|r=2|t=30|rg=10|1=Permanently increases maximum life by 20|z=75000;w|s=9999|rg=400;t|s=9999|rg=25|z=20;t|s=9999|rg=1|z=300;t|s=9999|rg=1|1=Used for smelting ore|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|1=Used to craft items from metal bars|z=5000;t|s=9999|rg=1|1=Used for basic crafting|z=150;41|D=1|rg=1|z=1000;|s=9999|rg=25|z=500;r1|d=4|t=30|rg=1|z=100;rb|s=9999|d=5|k=2|rg=99|z=5;rb|s=9999|d=7|k=2|rg=99|z=10;rc|s=9999|d=10|t=15|rg=99|z=15;c|s=9999|t=45|rg=3|1=Summons the Eye of Cthulhu;r1|d=14|t=25|k=1|rg=1|z=18000;d1|d=20|t=30|k=6|tx=15|rg=1|z=13500;d1|d=16|t=20|k=5|rg=1|z=13500;rb|s=9999|d=12|k=3|rg=99|z=40;t|s=9999|rg=1|z=500;a1|rg=1|1=Slowly regenerates life|z=50000;1|t=90|rg=1|1=Gaze in the mirror to return home|z=50000;rb|s=9999|d=10|k=4|rg=99|z=100;t|s=9999|rg=1|z=300;a1|rg=1|1=Allows the holder to double jump|z=50000;a1|rg=1|1=The wearer can run super fast|z=50000;d1|d=17|t=20|k=8|rg=1|z=50000;t|s=9999|rg=100|1=Pulsing with dark energy|z=5000;t|s=9999|rg=25|1=Pulsing with dark energy|z=15000;1;t|s=9999|rg=25|z=500;|s=9999|rg=25|z=50;t|s=9999|rg=100;t|s=9999|rg=25|z=20;t|s=9999|rg=5|z=5000;m1|d=10|t=28|k=1|m=10|rg=1|1=Summons a vile thorn|z=75000;d1|r=2|d=22|t=20|k=5|rg=1|1=Causes stars to rain from the sky|2=Forged with the fury of heaven|z=50000;c|s=9999|t=15|rg=99|1=Cleanses the evil|z=75;c|s=9999|t=15|rg=99|1=Spreads the Corruption|z=100;|s=9999|rg=25|1=Looks tasty!|z=10;|s=9999|rg=25|z=100;c|s=9999|t=45|rg=3|1=Summons the Eater of Worlds;rb|s=100|d=25|rg=100|z=5;rb|s=100|d=50|rg=100|z=500;rb|s=100|d=100|rg=100|z=50000;rb|s=9999|d=200|rg=100|z=5000000;b|s=9999|rg=50|1=Disappears after the sunrise|z=2500;61|D=1|rg=1|z=1000;61|D=2|rg=1|z=4000;61|D=3|rg=1|z=10000;61|D=4|rg=1|z=20000;51|D=2|rg=1|z=1250;51|D=3|rg=1|z=5000;51|D=4|rg=1|z=12500;51|D=5|rg=1|z=25000;1|t=20|k=7|rg=1|1=Get over here!|z=20000;t|s=9999|tr=3|rg=100|1=Can be climbed on|z=200;|s=9999|rg=25|z=500;t|s=9999|rg=1|1=Can be used to store your items|2=Stored items can only be accessed by you|z=10000;41|D=2|rg=1|1=Provides light when worn|z=40000;41|D=1|rg=1|z=750;41|D=2|rg=1|z=3000;41|D=3|rg=1|z=7500;41|D=4|rg=1|z=15000;w|s=9999|rg=400;t|s=9999|rg=200;r1|d=13|t=16|k=1|rg=1|z=50000;r1|c=7|d=31|t=32|k=5.25|rg=1|1=I have to be ready, said the minuteman|z=75000;rb|s=9999|d=7|k=2|rg=99|z=7;r1|r=2|d=6|t=8|rg=1|1=33% chance to not consume ammo|2=Half shark, half gun, completely awesome.|z=350000;r1|d=8|t=28|rg=1|z=1400;61|D=6|rg=1|1=5% increased critical strike chance|z=22500;51|D=7|rg=1|1=5% increased critical strike chance|z=30000;41|D=6|rg=1|1=5% increased critical strike chance|z=37500;d1|d=9|t=20|k=3|tp=65|rg=1|1=Able to mine Hellstone|z=18000;d1|d=24|t=45|k=6|th=55|rg=1|z=15000;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=12000;t|s=9999|rg=1|z=24000;c|s=9999|r=2|t=30|rg=10|1=Permanently increases maximum mana by 20|z=12500;c|s=9999|hm=50|t=17|rg=30|z=100;a1|rg=1|1=Increases maximum mana by 20|z=75000;m1|r=3|d=48|t=16|k=5.5|m=12|rg=1|1=Throws balls of fire|z=125000;m1|r=2|d=35|t=22|k=7.5|m=14|rg=1|1=Casts a controllable missile|z=87500;1|t=20|k=5|rg=1|1=Magically moves dirt|z=50000;1|t=20|rg=1|1=Creates a magical shadow orb|z=75000;t|s=9999|rg=100|z=1000;t|s=9999|rg=25|1=Warm to the touch|z=7000;|s=9999|rg=1|1=Sometimes dropped by Skeletons and Piranha|z=1000;d1|r=3|d=49|t=20|k=8|rg=1|z=100000;r1|r=3|d=31|t=22|k=2|rg=1|1=Lights wooden arrows ablaze|z=27000;d1|r=3|d=40|t=40|k=6.5|rg=1|1=Its made out of fire!|z=27000;d1|r=3|d=12|t=23|k=2|tp=100|rg=1|z=27000;41|D=5|rg=1|1=9% increased magic damage|z=45000;51|D=6|rg=1|1=9% increased magic damage|z=30000;61|D=5|rg=1|1=9% increased magic damage|z=30000;c|s=9999|hl=20|t=17|rg=30|z=20;m1|d=17|t=17|k=0.75|m=6|rg=1|z=20000;a1|r=3|rg=1|1=Allows flight|z=50000;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=1|z=150;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=1|1=Holding this may attract unwanted attention|z=500;t|s=9999|rg=25|1=It contains strange symbols|z=1500;t|s=9999|rg=50;41|r=2|D=6|rg=1|1=5% increased ranged damage|z=45000;51|r=2|D=7|rg=1|1=5% increased ranged damage|z=30000;61|r=2|D=6|rg=1|1=5% increased ranged damage|z=30000;rc|s=9999|d=20|t=12|k=2.3|rg=99|z=50;d1|r=2|d=24|t=18|k=3|rg=1|z=87500;a1|r=2|D=1|rg=1|1=Grants immunity to knockback|z=87500;m1|r=2|d=27|t=16|k=7|m=7|rg=1|1=Sprays out a shower of water|z=87500;a1|rg=1|1=Negates fall damage|2=Said to bring good fortune and keep evil spirits at bay|z=27000;a1|rg=1|1=Increases jump height|z=75000;r1|r=2|d=25|t=30|k=6|rg=1|z=27000;rc|s=9999|d=16|t=15|k=1|rg=99|z=80;d1|d=15|t=45|k=5.5|rg=1|z=75000;d1|r=2|d=27|t=45|k=6|rg=1|z=87500;r1|r=2|d=26|t=15|k=3|rg=1|z=87500;m1|r=2|d=19|t=17|k=5|m=10|rg=1|1=Casts a slow moving bolt of water|z=75000;c|s=9999|t=25|rg=99|1=A small explosion that will destroy most tiles|z=300;c|s=9999|t=40|rg=99|1=A large explosion that will destroy most tiles|z=2000;rc|s=9999|d=60|t=45|k=8|rg=99|1=A small explosion that will not destroy tiles|z=75;b|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=1;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|r=2|rg=100|z=1250;t|s=9999|r=2|rg=25|1=Hot to the touch|z=20000;t|s=9999|rg=100;t|s=9999|rg=15|z=5625;t|s=9999|rg=15|z=11250;t|s=9999|rg=15|z=7500;t|s=9999|rg=15|z=3750;t|s=9999|rg=15|z=1875;t|s=9999|rg=15|z=15000;t|s=9999|rg=100|z=50;1;1|r=3|t=20|k=7|rg=1|z=20000;d1|d=10|t=27|k=4|rg=1|1=Increases breath time and allows breathing in water|z=10000;a1|rg=1|1=Grants the ability to swim|z=10000;c|s=9999|hl=100|t=17|rg=30|z=1000;c|s=9999|hm=100|t=17|rg=30|z=250;d1|r=3|d=18|t=20|k=4.5|rg=1|1=Has a chance to poison enemies|z=27000;d1|r=3|d=25|t=15|k=8|rg=1|z=50000;t|s=9999|rg=100;a1|r=2|D=1|rg=1|1=Grants immunity to fire blocks|z=27000;t|s=9999|rg=25|z=150;t|s=9999|rg=25|z=150;d1|d=2|t=37|k=5.5|th=25|rg=1|z=50;r1|r=2|d=55|t=12|k=3|rg=1|1=Shoots fallen stars|z=500000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|d=20|t=30|k=7|tx=20|th=60|rg=1|z=15000;4|s=9999|D=1|rg=1|1=Can be used to scoop up a small amount of liquid;|s=9999|t=15|rg=1|1=Contains a small amount of water|2=Can be poured out;|s=9999|t=15|rg=1|1=Contains a small amount of lava|2=Can be poured out;av1|rg=1|1=Its pretty, oh so pretty|z=100;|s=9999|rg=25|z=200;|s=9999|rg=5|z=1000;a1|r=3|rg=1|1=12% increased melee speed|2=Enables auto swing for melee weapons|z=50000;a1|r=3|rg=1|1=10% increased movement speed|z=50000;dt1|r=3|d=7|k=3|rg=1|1=Creates grass on dirt|2=Increases alchemy plant collection when used to gather|z=25000;t|s=9999|rg=100;1|r=2|t=30|rg=1|1=May annoy others|z=100;a1|D=1|rg=1|z=10000;d1|r=3|d=20|t=27|k=7|tx=30|th=70|rg=1|z=27000;m1|r=3|d=32|t=30|k=6.5|m=21|rg=1|1=Summons a controllable ball of fire|z=125000;r1|r=3|d=33|t=17|k=2|rg=1|z=175000;d1|r=3|c=7|d=32|t=45|k=6.75|rg=1|z=125000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|1=Grows plants|z=100;a1|r=3|rg=1|1=6% reduced mana usage|z=27000;t|s=9999|rg=1|z=2000;|s=9999|rg=25|z=1000;c|s=9999|hl=90|t=17|rg=30|1=Reduced potion cooldown|z=1500;c|s=9999|hl=90|t=17|rg=30|1=Reduced potion cooldown|z=1500;41|r=3|D=5|rg=1|1=Increases maximum mana by 40|2=6% increased magic critical strike chance|z=45000;51|r=3|D=6|rg=1|1=Increases maximum mana by 20|2=6% increased magic damage|z=30000;61|r=3|D=6|rg=1|1=Increases maximum mana by 20|2=6% increased magic critical strike chance|z=30000;41|r=3|D=8|rg=1|1=7% increased melee critical strike chance|z=45000;51|r=3|D=9|rg=1|1=7% increased melee damage|z=30000;61|r=3|D=8|rg=1|1=7% increased melee speed|z=30000;rb|s=9999|d=8|k=1|rg=99|z=8;c|s=9999|t=25|rg=99|1=A small explosion that will destroy most tiles|2=Tossing may be difficult.|z=500;|s=9999|rg=1|z=5000;4v1|r=2|rg=1|1=Makes you look cool!|z=10000;41|r=2|D=4|rg=1|1=5% increased magic damage|z=10000;4v1|rg=1|z=10000;5v1|rg=1|z=5000;6v1|rg=1|z=5000;4v1|rg=1|z=10000;4v1|rg=1|z=20000;4v1|rg=1|z=10000;5v1|rg=1|z=250000;6v1|rg=1|z=250000;4v1|rg=1|z=10000;5v1|rg=1|z=5000;6v1|rg=1|z=5000;4vt|s=9999|rg=1|z=10000;4v1|rg=1|z=10000;5v1|rg=1|z=5000;6v1|rg=1|z=5000;|s=9999|rg=5|z=10000;|s=9999|rg=5|z=2000;41|D=2|rg=1|1=3% increased critical strike chance|z=10000;51|D=4|rg=1|1=3% increased critical strike chance|z=5000;61|D=3|rg=1|1=3% increased critical strike chance|z=5000;|s=9999|rg=5|z=50;4v1|rg=1|1=It smells funny...|z=1000;c|s=9999|t=15|rg=5|1=Its smiling, might be a good snack|z=3750;5v1|rg=1|z=2000;4v1|rg=1|z=10000;4v1|rg=1|z=10000;rb|s=9999|r=2|d=13|k=8|rg=99|z=100;r1|r=2|d=30|t=16|k=5|rg=1|1=This is a good idea!|z=10000;a|s=9999|rg=1|1=You are a terrible person.|z=1000;41|r=2|D=2|rg=1|1=Greatly extends underwater breathing|z=1000;v1|rg=1|z=10000;v1|rg=1|z=10000;v1|rg=1|z=10000;m1|r=3|d=35|t=20|k=5|m=14|rg=1|1=Casts a demon scythe|z=75000;d1|r=3|d=42|t=21|k=4.5|rg=1|z=200000;d1|r=3|d=34|t=22|k=5|rg=1|z=125000;t|s=9999|rg=25|z=1000;t|s=9999|rg=100|z=10;d1|d=14|t=31|k=6|rg=1|1=Increases mobility in water when held|2=Hold Up to descend slower|z=10000;rb|s=9999|d=9|k=3|rg=99|z=15;rc|s=9999|d=12|t=15|k=2|rg=99|z=50;d1|d=8|t=31|k=6.5|rg=1|z=1000;r1|d=9|t=25|k=3.5|rg=1|1=Allows the collection of seeds for ammo|z=10000;c|s=9999|t=15|rg=100|1=Works when wet|z=10;rb|s=9999|d=4|rg=99|1=For use with Blowpipe;d1|d=10|t=20|k=5|rg=1|z=10000;a1|rg=1|1=5% increased movement speed|z=25000;c|s=9999|t=15|rg=100|z=20;rc|s=9999|c=4|d=14|t=15|k=2.4|rg=99|z=60;c|s=9999|t=17|rg=20|1=Provides immunity to lava|z=1000;c|s=9999|t=17|rg=20|1=Provides life regeneration|z=1000;c|s=9999|t=17|rg=20|1=25% increased movement speed|z=1000;c|s=9999|t=17|rg=20|1=Breathe water instead of air|z=1000;c|s=9999|t=17|rg=20|1=Increase defense by 8|z=1000;c|s=9999|t=17|rg=20|1=Increased mana regeneration|z=1000;c|s=9999|t=17|rg=20|1=20% increased magic damage|z=1000;c|s=9999|t=17|rg=20|1=Slows falling speed|z=1000;c|s=9999|t=17|rg=20|1=Shows the location of treasure and ore|z=1000;c|s=9999|t=17|rg=20|1=Grants invisibility and lowers the spawn rate of enemies|z=1000;c|s=9999|t=17|rg=20|1=Emits an aura of light|z=1000;c|s=9999|t=17|rg=20|1=Increases night vision|z=1000;c|s=9999|t=17|rg=20|1=Increases enemy spawn rate|z=1000;c|s=9999|t=17|rg=20|1=Attackers also take damage|z=1000;c|s=9999|t=17|rg=20|1=Allows the ability to walk on water|z=1000;c|s=9999|t=17|rg=20|1=10% increased bow damage and 20% increased arrow speed|z=1000;c|s=9999|t=17|rg=20|1=Shows the location of enemies|z=1000;c|s=9999|t=17|rg=20|1=Allows the control of gravity|z=1000;t|s=9999|rg=1|z=5000;t|s=9999|rg=25|z=80;t|s=9999|rg=25|z=80;t|s=9999|rg=25|z=80;t|s=9999|rg=25|z=80;t|s=9999|rg=25|z=80;t|s=9999|rg=25|z=80;|s=9999|rg=25|z=100;|s=9999|rg=25|z=100;|s=9999|rg=25|z=100;|s=9999|rg=25|z=100;|s=9999|rg=25|z=100;|s=9999|rg=25|z=100;|s=9999|rg=25|z=200;|s=9999|rg=25|z=50;t|s=9999|rg=2;4v1|rg=1|z=20000;|s=9999|rg=5|z=50;|s=9999|rg=1|1=Banned in most places|z=200000;5v1|rg=1|z=200000;6v1|rg=1|z=200000;|s=9999|rg=3|1=Opens one locked Gold Chest or Lock Box;t|s=9999|rg=1|z=5000;1|rg=1|1=Opens all Shadow Chests and Obsidian Lock Boxes|z=87500;w|s=9999|rg=400;|s=9999|rg=25|z=100;t|s=9999|rg=1|1=Used for crafting cloth|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|1=Can be used to store your items|2=Stored items can only be accessed by you|z=200000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=70;t|s=9999|rg=1|z=20;t|s=9999|rg=1|1=Used for brewing ale|z=600;b|s=9999|rg=20|1=Minor improvements to melee stats & lowered defense|2=Down the hatch!|z=100;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=20;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Simple, yet refreshing.|z=10000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;c|s=9999|t=45|rg=3|1=Summons a Goblin Army;|s=9999|rg=25|z=30;t|s=9999|rg=1|1=Used for advanced wood crafting|z=300;t|s=9999|r=3|rg=100|z=3500;t|s=9999|r=3|rg=100|z=5500;t|s=9999|r=3|rg=100|z=7500;d1|r=4|d=26|t=27|k=7.5|th=80|rg=1|1=Strong enough to destroy Demon Altars|z=39000;d1|r=5|d=72|t=20|k=4.5|rg=1|z=230000;t|s=9999|r=3|rg=25|z=2000;b|s=9999|rg=100;41|r=4|D=3|rg=1|1=Increases maximum mana by 40|2=10% increased magic damage|3=9% increased magic critical strike chance|z=75000;41|r=4|D=14|rg=1|1=10% increased movement speed|2=15% increased melee damage|z=75000;41|r=4|D=5|rg=1|1=10% increased ranged damage|2=10% increased ranged critical strike chance|z=75000;51|r=4|D=10|rg=1|1=5% increased critical strike chance|z=60000;61|r=4|D=8|rg=1|1=10% increased movement speed and 3% increased damage|z=45000;41|r=4|D=3|rg=1|1=Increases maximum mana by 60|2=15% increased magic damage|z=112500;41|r=4|D=16|rg=1|1=8% increased melee critical strike chance|2=10% increased melee damage|z=112500;41|r=4|D=6|rg=1|1=12% increased ranged damage|2=7% increased ranged critical strike chance|z=112500;51|r=4|D=12|rg=1|1=7% increased damage|z=90000;61|r=4|D=9|rg=1|1=10% increased critical strike chance|z=67500;t|s=9999|r=3|rg=25|z=10500;t|s=9999|r=3|rg=25|z=22000;d1|r=4|d=23|t=15|k=2.75|tx=14|rg=1|z=54000;d1|r=4|d=29|t=15|k=3|tx=17|rg=1|z=81000;d1|r=4|d=10|t=15|k=0.5|tp=110|rg=1|1=Can mine Mythril and Orichalcum|z=54000;d1|r=4|d=15|t=15|k=0.5|tp=150|rg=1|1=Can mine Adamantite and Titanium|z=81000;d1|r=4|d=33|t=15|k=4.5|tx=20|rg=1|z=108000;d1|r=4|d=20|t=15|k=0.5|tp=180|rg=1|z=108000;d1|r=5|d=50|t=45|k=6|rg=1|1=Has a chance to confuse|2=Find your inner pieces|z=144000;d1|r=4|d=45|t=26|k=5|rg=1|z=67500;t|s=9999|r=3|rg=25|z=30000;w|s=9999|rg=400;a1|rg=1|1=Displays horizontal position|z=12500;a1|r=4|rg=1|1=Grants the ability to swim|2=Greatly extends underwater breathing|z=100000;a1|r=3|rg=1|1=Shows position|2=Tells the time|z=150000;a1|r=4|rg=1|1=Negates fall damage|2=Grants immunity to fire blocks|z=60000;a1|r=4|D=2|rg=1|1=Grants immunity to knockback|2=Grants immunity to fire blocks|z=100000;t|s=9999|rg=1|1=Allows the combining of some accessories|z=100000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height|z=150000;41|r=4|D=4|rg=1|1=Increases maximum mana by 80|2=12% increased magic damage and critical strike chance|z=150000;41|r=4|D=22|rg=1|1=7% increased melee critical strike chance|2=14% increased melee damage|z=150000;41|r=4|D=8|rg=1|1=14% increased ranged damage|2=10% increased ranged critical strike chance|z=150000;51|r=4|D=16|rg=1|1=8% increased damage|z=120000;61|r=4|D=12|rg=1|1=7% increased critical strike chance|2=5% increased movement speed|z=90000;a1|r=4|rg=1|1=Allows flight|2=The wearer can run super fast|z=100000;d1|r=4|d=49|t=25|k=6|rg=1|z=90000;a1|r=3|rg=1|1=Increases block placement range by 1|z=100000;b|s=9999|rg=100;t|s=9999|rg=100;51|D=1|rg=1|1=10% increased mining speed|z=5000;61|D=1|rg=1|1=10% increased mining speed|z=5000;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;c|s=9999|r=3|d=20|t=15|k=3|rg=99|1=Spreads the Hallow to some blocks|z=200;c|s=9999|r=3|d=20|t=15|k=3|rg=99|1=Spreads the Corruption to some blocks|z=100;t|s=9999|rg=200;1|r=5|t=20|rg=1|1=Summons a magical fairy|z=250000;d1|r=4|d=70|t=35|k=8|rg=1|1=Deals more damage to unhurt enemies|z=150000;t|s=9999|rg=100|z=200;t|s=9999|rg=100|z=200;t|s=9999|rg=100|z=200;t|s=9999|rg=100|z=200;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=200;t|s=9999|rg=100|z=300;r1|r=4|d=17|t=12|rg=1|1=Three round burst|2=Only the first shot consumes ammo|z=150000;r1|r=4|d=35|t=23|k=1.5|rg=1|z=60000;r1|r=4|d=39|t=20|k=2|rg=1|z=90000;1|r=4|t=20|k=7|rg=1|z=150000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;w|s=9999|rg=400;t|s=9999|rg=50;r1|r=4|d=42|t=18|k=2.5|rg=1|z=120000;d1|r=4|d=61|t=21|k=6|rg=1|z=138000;d1|r=4|d=40|t=19|k=5|rg=1|z=69000;d1|r=4|d=50|t=20|k=6|rg=1|z=103500;a1|r=4|rg=1|1=Turns the holder into a werewolf at night|z=150000;d1|d=12|t=20|k=0.5|rg=1|z=1000;t|s=9999|r=3|rg=1|z=100000;t|s=9999|rg=1|z=10000;a1|r=4|rg=1|1=15% increased magic damage|z=100000;a1|r=4|rg=1|1=15% increased melee damage|z=100000;a1|r=4|rg=1|1=15% increased ranged damage|z=100000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;m1|r=5|d=42|t=12|k=2|m=5|rg=1|z=200000;m1|r=5|d=50|t=25|k=6|m=21|rg=1|1=Casts a controllable rainbow|z=200000;m1|r=4|d=28|t=9|k=2|m=6|rg=1|1=Summons a block of ice|z=500000;a1|r=5|rg=1|1=Transforms the holder into merfolk when entering water|z=375000;t|s=9999|rg=1|1=Right Click to customize attire;c|s=9999|r=3|hl=150|t=17|rg=30|z=5000;c|s=9999|r=3|hm=200|t=17|rg=30|z=500;|s=9999|rg=25|z=500;t|s=9999|rg=25|z=8000;4v1|r=2|rg=1|z=20000;5v1|r=2|rg=1|z=10000;6v1|r=2|rg=1|z=10000;r1|r=5|d=35|t=30|k=0.3|rg=1|1=Uses gel for ammo|2=Ignores 15 points of enemy Defense|z=500000;1|r=3|t=12|rg=1|z=10000;1|r=3|t=12|rg=1|z=10000;1|t=15|tr=20|rg=1|1=Places red wire|z=20000;1|t=15|tr=20|rg=1|1=Removes wire|z=20000;t|s=9999|rg=100|z=1000;t|s=9999|rg=100|z=1000;t|s=9999|rg=5|z=3000;m1|r=4|d=29|t=12|k=2.5|m=8|rg=1|z=150000;rb|s=9999|r=3|d=9|k=1|rg=99|1=Creates crystal shards on impact|z=30;rb|s=9999|r=3|d=13|k=2|rg=99|1=Summons falling stars on impact|z=80;m1|r=4|d=35|t=8|k=3.75|m=6|rg=1|1=A magical returning dagger|z=250000;m1|r=4|d=32|t=7|k=5|m=5|rg=1|1=Summons rapid fire crystal shards|z=200000;m1|r=4|d=55|t=15|k=6.5|m=9|rg=1|1=Summons unholy fire balls|z=200000;|s=9999|r=3|rg=25|1=The essence of light creatures|z=1000;|s=9999|r=3|rg=25|1=The essence of dark creatures|z=1000;|s=9999|r=3|rg=25|1=Not even water can put the flame out|z=4000;t|s=9999|rg=100|1=Can be placed in water|z=150;t|s=9999|r=3|rg=1|1=Used to smelt adamantite and titanium ore|z=50000;t|s=9999|r=3|rg=1|1=Used to craft items from mythril, orichalcum, adamantite, and titanium bars|z=25000;|s=9999|rg=5|1=Sharp and magical!|z=15000;|s=9999|r=2|rg=1|1=Sometimes carried by creatures in dark deserts|z=4500;|s=9999|r=2|rg=1|1=Sometimes carried by creatures in light deserts|z=4500;t|s=9999|rg=5|1=Activates when stepped on|z=5000;|s=9999|rg=100|z=500;|s=9999|rg=1|1=Can be enchanted|z=50000;a1|r=4|rg=1|1=Causes stars to fall after taking damage|z=100000;r1|r=5|d=25|t=7|k=1|rg=1|1=50% chance to not consume ammo|2=Minisharks older brother|z=350000;r1|r=4|d=24|t=45|k=6.5|rg=1|1=Fires a spread of bullets|z=250000;a1|r=4|rg=1|1=Reduces the cooldown of healing potions by 25%|z=100000;a1|r=4|rg=1|1=Increases melee knockback|2=Increases the size of melee weapons|z=100000;d1|r=4|d=44|t=28|k=4|rg=1|z=45000;t|s=9999|rg=5|z=2000;t|s=9999|rg=5|z=10000;t|s=9999|rg=5;t|s=9999|rg=5|1=Activates when stepped on|z=5000;t|s=9999|rg=5|1=Activates when a player steps on it|z=5000;t|s=9999|rg=5|1=Activates when a player steps on it|z=5000;c|s=9999|r=3|t=45|rg=3|1=Summons The Twins;rb|s=9999|r=3|d=17|k=3|rg=99|z=40;rb|s=9999|r=3|d=12|k=4|rg=99|z=30;|s=9999|r=5|rg=25|1=The essence of pure terror|z=40000;|s=9999|r=5|rg=25|1=The essence of the destroyer|z=40000;|s=9999|r=5|rg=25|1=The essence of omniscient watchers|z=40000;d1|r=5|d=61|t=22|k=6.4|rg=1|z=230000;51|r=5|D=15|rg=1|1=7% increased critical strike chance|z=200000;61|r=5|D=11|rg=1|1=7% increased damage|2=8% increased movement speed|z=150000;41|r=5|D=9|rg=1|1=15% increased ranged damage|2=8% increased ranged critical strike chance|z=250000;a1|r=4|rg=1|1=Increases length of invincibility after taking damage|z=100000;a1|r=4|rg=1|1=8% reduced mana usage|2=Automatically use mana potions when needed|z=50000;c|s=9999|r=3|t=45|rg=3|1=Summons The Destroyer;c|s=9999|r=3|t=45|rg=3|1=Summons Skeletron Prime;41|r=5|D=5|rg=1|1=Increases maximum mana by 100|2=12% increased magic damage and critical strike chance|z=250000;41|r=5|D=24|rg=1|1=10% increased melee damage and critical strike chance|2=10% increased melee speed|z=250000;c|s=9999|t=45|rg=3|1=Summons King Slime;d1|r=5|d=60|t=14|k=8|rg=1|1=Greetings, programs!|z=1500000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;|s=9999|r=3|rg=25|1=The essence of powerful flying creatures|z=1000;a1|r=3|rg=1|1=Has a chance to record songs|z=100000;t|s=9999|rg=100;r1|r=4|d=50|t=17|k=2.5|rg=1|z=200000;d1|r=4|d=35|t=15|k=4.75|tp=200|tx=22|rg=1|1=Not to be confused with a picksaw|z=220000;t|s=9999|rg=5|1=Explodes when activated|z=5000;t|s=9999|rg=1|1=Sends water to outlet pumps;t|s=9999|rg=1|1=Receives water from inlet pumps;t|s=9999|rg=1|1=Activates every second|z=10000;t|s=9999|rg=1|1=Activates every 3 seconds|z=10000;t|s=9999|rg=1|1=Activates every 5 seconds|z=10000;t|s=9999|rg=100;w|s=9999|rg=400;4v1|rg=1|z=150000;5v1|rg=1|z=150000;6v1|rg=1|z=150000;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;1|1=Right Click to open;1|1=Right Click to open;1|1=Right Click to open;c|s=9999|r=2|t=45|rg=3|1=Summons the Frost Legion;1|r=3|t=20|rg=1|1=Summons a pet bunny;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;d1|d=11|t=19|k=6|rg=1|z=100;d1|d=7|t=30|k=5.5|th=40|rg=1|z=50;r1|d=8|t=28|rg=1|z=100;d1|d=8|t=19|k=6|rg=1|z=100;d1|d=4|t=33|k=5.5|th=35|rg=1|z=50;r1|d=6|t=29|rg=1|z=100;d1|d=30|t=15|k=7|rg=1|z=100;d1|d=10|t=29|k=5.5|th=55|rg=1|z=50;r1|d=12|t=20|rg=1|z=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;1|r=3|t=20|rg=1|1=Summons a baby penguin|z=100000;d1|c=2|d=21|t=20|k=8.5|rg=1|z=50000;d1|r=8|c=16|d=105|t=20|k=6.5|rg=1|1=Deals more damage to injured foes|z=200000;d1|r=4|d=53|t=16|k=4|rg=1|z=180000;t|s=9999|rg=1|z=150;d1|r=8|d=72|t=18|k=4.5|rg=1|z=500000;d1|r=8|d=70|t=32|k=4.75|rg=1|z=500000;d1|r=5|d=49|t=23|k=4.5|rg=1|1=Shoots an icy bolt|z=250000;t|s=9999|rg=1|z=300;c|s=9999|r=4|t=17|rg=3|1=Only for those who are worthy;r1|r=8|d=29|t=34|k=7|rg=1|z=400000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=5000;r1|r=5|c=5|d=53|t=19|k=4.7|rg=1|z=27000;m1|r=6|d=88|t=17|k=6.5|m=19|rg=1|1=Summons the Devils trident|z=500000;41|r=5|D=10|rg=1|1=16% increased melee and ranged damage|z=250000;51|r=5|D=20|rg=1|1=11% increased melee and ranged critical strike chance|z=200000;61|r=5|D=13|rg=1|1=8% increased movement speed|2=10% increased melee speed|z=150000;41|D=2|rg=1|z=1125;51|D=2|rg=1|z=1875;61|D=1|rg=1|z=1500;41|D=3|rg=1|z=4500;51|D=3|rg=1|z=7500;61|D=2|rg=1|z=6000;41|D=4|rg=1|z=11250;51|D=5|rg=1|z=18750;61|D=3|rg=1|z=15000;41|D=5|rg=1|z=22500;51|D=6|rg=1|z=37500;61|D=5|rg=1|z=30000;t|s=9999|rg=100|z=375;t|s=9999|rg=100|z=750;t|s=9999|rg=100|z=1125;t|s=9999|rg=100|z=2250;t|s=9999|rg=25|z=1125;t|s=9999|rg=25|z=2250;t|s=9999|rg=25|z=4500;t|s=9999|rg=25|z=9000;a1|rg=1|1=Tells the time|z=1500;a1|rg=1|1=Tells the time|z=7500;a1|rg=1|1=Tells the time|z=15000;t|s=9999|rg=1|z=4500;t|s=9999|rg=1|z=18000;t|s=9999|rg=1|z=36000;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;4v1|rg=1|z=15000;t|s=9999|rg=1|1=Used to craft items from metal bars|z=7500;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;d1|r=4|d=52|t=20|k=6.5|rg=1|1=Shoots a beam of light|z=150000;d1|c=2|d=17|t=20|k=4.75|rg=1|1=Shoots an icy bolt|z=20000;r1|r=5|d=39|t=14|k=4.5|rg=1|1=Shoots frost arrows|z=250000;m1|r=5|d=46|t=12|k=5|m=12|rg=1|1=Shoots a stream of frost|z=200000;41|D=1|rg=1;51|D=1|rg=1;61|rg=1;41|D=1|rg=1;51|D=2|rg=1;61|D=1|rg=1;41|D=1|rg=1;51|D=1|rg=1;61|D=1|rg=1;41|D=2|rg=1;51|D=3|rg=1;61|D=2|rg=1;m1|d=15|t=37|k=3.25|m=5|rg=1|z=2000;m1|d=16|t=36|k=3.5|m=5|rg=1|z=3000;m1|d=18|t=34|k=4|m=6|rg=1|z=10000;m1|d=19|t=32|k=4.25|m=6|rg=1|z=15000;m1|d=21|t=28|k=4.75|m=7|rg=1|z=20000;m1|r=2|d=23|t=26|k=5.5|m=8|rg=1|z=30000;w|s=9999|rg=400|z=10;w|s=9999|rg=400|z=10;w|s=9999|rg=400|z=10;a1|r=5|rg=1|1=Allows flight and slow fall|2=Hold Up to boost faster!|z=400000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;w|s=9999|rg=400;t|s=9999|rg=100|1=Prevents fall damage;w|s=9999|rg=400;1|r=3|t=20|rg=1|1=Summons a pet turtle|z=100000;4v1|r=5|rg=1|z=50000;5v1|r=5|rg=1|z=50000;d1|r=7|d=60|t=40|k=6.2|rg=1|z=700000;d1|r=8|d=85|t=18|k=6.5|rg=1|z=1000000;r1|r=8|d=60|t=20|k=4|rg=1|z=350000;r1|r=8|d=55|t=30|k=4|rg=1|1=Does extra damage on a direct hit|z=400000;r1|r=8|d=80|t=50|k=4|rg=1|1=Mines deal triple damage when armed|z=350000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100|1=Prevents fall damage;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;rb|s=9999|d=40|k=4|rg=99|1=Small blast radius. Will not destroy tiles|z=50;rb|s=9999|d=40|k=4|rg=99|1=Small blast radius. Will destroy tiles|z=250;rb|s=9999|d=65|k=6|rg=99|1=Large blast radius. Will not destroy tiles|z=100;rb|s=9999|r=2|d=65|k=6|rg=99|1=Large blast radius. Will destroy tiles|z=500;t|s=9999|rg=100|1=Increases running speed;d1|r=4|d=10|t=25|k=5|tp=110|rg=1|1=Can mine Mythril and Orichalcum|z=54000;d1|r=4|d=15|t=25|k=5|tp=150|rg=1|1=Can mine Adamantite and Titanium|z=81000;d1|r=4|d=20|t=25|k=5|tp=180|rg=1|z=108000;1|r=5|t=30|k=0.3|rg=1|1=Creates and destroys biomes when sprayed|2=Uses colored solution|z=2000000;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Purity|z=1500;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Hallow|z=1500;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Corruption|z=1500;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads Glowing Mushrooms|z=1500;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Crimson|z=1500;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;d1|r=7|d=26|t=27|k=7.5|th=85|rg=1|1=Strong enough to destroy Demon Altars|z=400000;m1|r=7|d=35|t=25|k=1|m=12|rg=1|1=Ignores 10 points of enemy Defense|z=200000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=5000;41|D=6|rg=1|1=3% increased damage|z=50000;51|D=7|rg=1|1=3% increased damage|z=40000;61|D=6|rg=1|1=3% increased damage|z=30000;d1|d=22|t=25|k=5|rg=1|z=13500;r1|d=19|t=30|k=1|rg=1|z=18000;d1|d=23|t=40|k=6|th=55|rg=1|z=15000;d1|d=12|t=22|k=3.5|tp=70|rg=1|1=Able to mine Hellstone|z=18000;d1|d=22|t=32|k=6|tx=15|rg=1|z=13500;r1|d=22|t=20|k=2|rg=1|z=75000;d1|d=17|t=45|k=5.5|rg=1|z=27000;d1|d=17|t=31|k=5|rg=1|z=75000;41|D=3|rg=1|z=50000;51|D=3|rg=1|z=40000;61|D=3|rg=1|z=30000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;a1|r=8|rg=1|1=Allows flight and slow fall|z=400000;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=5000;t1|rg=1|1=Places living wood|z=12500;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=5000;4v1|r=2|rg=1|z=15000;5v1|r=2|rg=1|z=15000;6v1|r=2|rg=1|z=15000;4v1|rg=1|z=25000;5v1|rg=1|z=25000;6v1|rg=1|z=25000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=5000;4v1|rg=1|z=20000;|s=9999|t=15|rg=50|1=Enables solid blocks to be toggled on and off|z=1000;1|t=15|tr=20|rg=1|1=Places blue wire|z=20000;1|t=15|tr=20|rg=1|1=Places green wire|z=20000;t|s=9999|rg=5|1=Activates when a player steps on it|z=5000;t|s=9999|rg=5|1=Activates when anything but a player steps on it|z=5000;a1|r=5|rg=1|1=Shops prices lowered by 20%|z=50000;a1|r=5|rg=1|1=Hitting enemies will sometimes drop extra coins|2=I found a coin! Its my lucky day!|z=50000;v1|r=2|rg=1|1=Having a wonderful time!|z=500;a1|r=2|rg=1|1=Allows the holder to do an improved double jump|z=50000;t|s=9999|rg=1|z=300;c1|t=20|rg=1|z=20;a1|r=6|rg=1|1=Provides life regeneration and reduces the cooldown of healing potions by 25%|z=200000;a1|r=6|rg=1|1=Turns the holder into a werewolf at night and a merfolk when entering water|z=400000;a1|r=6|rg=1|1=Causes stars to fall and increases length of invincibility after taking damage|z=100000;a1|r=4|rg=1|1=Provides the ability to walk on water & honey|z=200000;4v1|rg=1|z=250000;5v1|rg=1|z=100000;5v1|rg=1|z=20000;41|D=2|rg=1|z=25000;4v1|rg=1|z=20000;4v1|rg=1|z=25000;4v1|rg=1|z=20000;5v1|rg=1|z=20000;6v1|rg=1|z=20000;4v1|rg=1|z=50000;5v1|rg=1|z=50000;6v1|rg=1|z=50000;4v1|rg=1|z=50000;5v1|rg=1|z=50000;6v1|rg=1|z=50000;41|D=4|rg=1|z=25000;t|s=9999|rg=100|z=6500;d1|d=10|t=30|k=4.5|rg=1|z=1800;d1|d=4|t=25|k=2|tp=35|rg=1|z=2000;t|s=9999|rg=100;w|s=9999|rg=400;a1|r=4|rg=1|1=Immunity to Bleeding|z=100000;a1|r=4|rg=1|1=Immunity to Broken Armor|z=100000;a1|r=4|rg=1|1=Immunity to Poison|z=100000;a1|r=4|rg=1|1=Immunity to Darkness|z=100000;a1|r=4|rg=1|1=Immunity to Slow|z=100000;a1|r=4|rg=1|1=Immunity to Silence|z=100000;a1|r=2|rg=1|1=Immunity to Curse|z=100000;a1|r=4|rg=1|1=Immunity to Weakness|z=100000;a1|r=4|rg=1|1=Immunity to Confusion|z=100000;41|D=1|rg=1|z=200;51|D=1|rg=1|z=300;61|D=1|rg=1|z=250;a1|r=5|rg=1|1=Increases melee knockback|2=12% increased melee speed|3=Enables auto swing for melee weapons|4=Increases the size of melee weapons|z=200000;a1|r=5|rg=1|1=Allows flight, super fast running|2=8% increased movement speed|z=300000;a1|r=7|rg=1|1=If worn during the day, grants minor increase to damage, melee speed, critical strike chance,|2=life regeneration, defense, mining speed, and minion knockback|z=300000;a1|r=5|rg=1|1=If worn during the night, grants minor increase to damage, melee speed, critical strike chance,|2=life regeneration, defense, mining speed, and minion knockback|z=375000;a1|r=5|rg=1|1=Immunity to Weakness and Broken Armor|z=100000;a1|r=5|rg=1|1=Immunity to Poison and Bleeding|z=100000;a1|r=5|rg=1|1=Immunity to Slow and Confusion|z=100000;a1|r=5|rg=1|1=Immunity to Silence and Curse|z=100000;r1|r=6|t=8|k=2|rg=1|1=Uses coins for ammo|2=Higher valued coins do more damage|z=300000;a1|r=3|rg=1|1=Provides 7 seconds of immunity to lava|z=300000;a1|r=4|rg=1|1=Provides the ability to walk on water & honey|2=Grants immunity to fire blocks|z=300000;a1|r=7|rg=1|1=Provides the ability to walk on water, honey & lava|2=Grants immunity to fire blocks and 7 seconds of immunity to lava|3=Reduces damage from touching lava|z=500000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;t|s=9999|rg=100;t|s=9999|rg=1|z=200;t|s=9999|rg=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;d1|d=11|t=19|k=6|rg=1|z=100;d1|d=7|t=30|k=5.5|th=40|rg=1|z=50;r1|d=8|t=28|rg=1|z=100;41|D=1|rg=1;51|D=2|rg=1;61|D=1|rg=1;w|s=9999|rg=400;t|s=9999|r=3|rg=1|z=250000;c|s=9999|d=300|t=20|rg=25|1=For use with cannon|z=1500;1|d=2|t=18|rg=1|z=50000;rb|s=9999|d=1|k=1.5|rg=99|z=7;t1|rg=1|1=Places bone|z=25000;t1|rg=1|1=Places leaves|z=12500;a1|r=2|rg=1|1=Allows the owner to float for a few seconds|z=50000;a1|r=5|rg=1|1=12% increased damage|z=300000;a1|r=6|rg=1|1=Increases melee knockback|2=12% increased melee damage and speed|3=Enables auto swing for melee weapons|4=Increases the size of melee weapons|z=250000;t|s=9999|rg=5|1=Explodes when stepped on|z=50000;a1|r=8|D=6|rg=1|1=Absorbs 25% of damage done to players on your team when above 25% life|2=Grants immunity to knockback|z=300000;1|r=2|t=20|k=7|rg=1|z=20000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;d1|d=10|t=22|k=5|rg=1|1=You will fall slower while holding this|z=10000;t|s=9999|r=7|rg=100|1=Reacts to the light|z=7500;a1|r=8|rg=1|1=Allows flight and slow fall|z=3000000;rb|s=9999|d=8|k=5.75|rg=99;a1|rg=1|1=Provides extra mobility on ice|2=Ice will not break when you fall on it|z=50000;t|s=9999|r=2|rg=1|1=Rapidly launches snowballs|z=50000;t|s=9999|rg=1|z=500;a1|rg=1|1=Allows the ability to slide down walls|2=Improved ability if combined with Shoe Spikes|z=25000;41|D=2|rg=1|z=5000;41|D=4|rg=1|z=25000;41|D=6|rg=1|1=5% increased critical strike chance|z=37500;51|D=7|rg=1|1=5% increased critical strike chance|z=30000;61|D=6|rg=1|1=5% increased critical strike chance|z=22500;41|r=2|D=6|rg=1|1=5% increased ranged damage|z=45000;41|r=3|D=5|rg=1|1=Increases maximum mana by 40|2=6% increased magic critical strike chance|z=45000;51|r=3|D=6|rg=1|1=Increases maximum mana by 20|2=6% increased magic damage|z=30000;61|r=3|D=6|rg=1|1=Increases maximum mana by 20|2=6% increased magic critical strike chance|z=30000;a1|r=7|rg=1|1=Gives a chance to dodge attacks|z=150000;r1|r=2|d=14|t=40|k=5.75|rg=1|1=Fires a spread of bullets|z=100000;t|s=9999|tr=3|rg=100|1=Can be climbed on|z=10;t|s=9999|rg=1|1=Life regen is increased when near a campfire;c|s=9999|t=17|rg=5|1=Put it on a stick and roast over a campfire|2=Minor improvements to all stats|3=How many can you fit in your mouth?|z=100;1|rg=5|1=Roast it over a campfire!|z=200;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=How can I have some more of nothing?|z=200;t|s=9999|rg=5|z=1500;t|s=9999|rg=5|z=1500;t|s=9999|rg=5|z=1500;t|s=9999|rg=5|z=1500;t|s=9999|rg=100|z=60;a1|rg=1|1=Allows the ability to slide down walls|2=Improved ability if combined with Climbing Claws|z=50000;a1|r=2|rg=1|1=Allows the ability to climb walls|z=50000;a1|r=7|rg=1|1=Allows the ability to dash|2=Double tap a direction|z=150000;41|D=3|rg=1|z=50000;51|D=3|rg=1|z=40000;61|D=3|rg=1|z=30000;|s=9999|rg=5|z=10000;a1|rg=1|1=Increases maximum mana by 20|2=Increases mana regeneration rate|z=50000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height|z=150000;a1|r=8|rg=1|1=Allows the ability to climb walls and dash|2=Gives a chance to dodge attacks|z=500000;c|s=9999|t=20|rg=10|1=Throw to create a climbable line of rope|z=100;r1|r=3|d=27|t=35|k=4|rg=1|1=Allows the collection of seeds for ammo|z=50000;a1|rg=1|1=Allows the holder to double jump|z=50000;rb|s=9999|d=7|k=2.2|rg=99|z=15;d1|r=2|d=23|t=21|k=4.25|rg=1|1=Shoots an enchanted sword beam|z=150000;d1|r=4|d=35|t=25|k=4.75|tp=200|tx=22|rg=1|1=Not to be confused with a hamdrill|z=220000;d1|r=4|d=33|t=35|k=5|tx=14|rg=1|z=54000;d1|r=4|d=39|t=35|k=6|tx=17|rg=1|z=81000;d1|r=4|d=43|t=35|k=7|tx=20|rg=1|z=108000;1|r=3|t=20|rg=1|1=Summons a Baby Eater of Souls|z=375000;t|s=9999|rg=1|1=Used to craft objects|z=100000;t|s=9999|rg=1|1=Used to craft objects|z=100000;t|s=9999|rg=1|1=Placing silt/slush/fossil piles into the extractinator turns them into something more useful|z=100000;t|s=9999|rg=1|1=Used to craft objects|z=100000;t|s=9999|rg=15|z=15000;rc|s=9999|t=15|rg=5|1=Shoots confetti everywhere!|z=100;41|r=7|D=20|rg=1|1=16% increased melee damage|2=6% increased melee critical strike chance|z=300000;41|r=7|D=13|rg=1|1=16% increased ranged damage|2=20% chance to not consume ammo|z=300000;41|r=7|D=7|rg=1|1=Increases maximum mana by 80 and reduces mana usage by 17%|2=16% increased magic damage|z=300000;51|r=7|D=18|rg=1|1=5% increased damage|2=7% increased critical strike chance|z=240000;61|r=7|D=13|rg=1|1=8% increased critical strike chance|2=5% increased movement speed|z=180000;t|s=9999|r=7|rg=25|1=Reacts to the light|z=45000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;1|t=15|rg=1|1=Used with paint to color blocks|2=Can also apply coatings|z=10000;1|t=15|rg=1|1=Used with paint to color walls|2=Can also apply coatings|z=10000;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;|s=9999|rg=100|z=25;1|t=15|rg=1|1=Used to remove paint or coatings|2=Can sometimes collect moss|z=10000;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=200;t|s=9999|r=3|rg=100|z=4500;t|s=9999|r=3|rg=100|z=6500;t|s=9999|r=3|rg=100|z=8500;t|s=9999|rg=3|1=Used to make Teal Dye|z=10000;t|s=9999|rg=3|1=Used to make Green Dye|z=10000;t|s=9999|rg=3|1=Used to make Sky Blue Dye|z=10000;t|s=9999|rg=3|1=Used to make Yellow Dye|z=10000;t|s=9999|rg=3|1=Used to make Blue Dye|z=10000;t|s=9999|rg=3|1=Used to make Lime Dye|z=10000;|s=9999|rg=3|1=Used to make Pink Dye|z=10000;t|s=9999|rg=3|1=Used to make Orange Dye|z=10000;|s=9999|rg=3|1=Used to make Red Dye|z=10000;|s=9999|rg=3|1=Used to make Cyan Dye|z=10000;|s=9999|rg=3|1=Used to make Violet Dye|z=10000;|s=9999|rg=3|1=Used to make Purple Dye|z=10000;|s=9999|rg=3|1=Used to make Black Dye|z=10000;t|s=9999|rg=1|1=Used to Craft Dyes|z=50000;m1|r=2|d=9|t=12|k=0.25|m=5|rg=1|1=Shoots bees that will chase your enemy|z=100000;d1|r=7|d=80|t=14|k=5|rg=1|1=Chases after your enemy|z=350000;d1|r=3|d=30|t=20|k=5.3|rg=1|1=Summons killer bees after striking your foe|2=Small chance to cause confusion|z=100000;|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;|s=9999|t=15|rg=1|1=Contains a small amount of honey|2=Can be poured out;t1|rg=1|1=Places Hives|z=25000;rc|s=9999|d=12|t=15|k=1|rg=99|1=Explodes into a swarm of bees|z=200;a1|r=8|rg=1|1=Allows the holder to reverse gravity|2=Press Up to change gravity|z=2000000;a1|r=2|rg=1|1=Releases bees and douses the user in honey when damaged|z=100000;c|s=9999|t=45|rg=3|1=Summons the Queen Bee;c|s=9999|hl=80|t=17|rg=30|1=Improves natural healing for a short time|z=40;41|D=1|rg=1|z=1000;51|D=2|rg=1|z=1000;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;|s=9999|r=7|rg=1|1=Opens the jungle temple door;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|1=Used for basic crafting|z=150;t|s=9999|rg=5|z=10000;t|s=9999|rg=5|z=10000;t|s=9999|rg=5|z=10000;t|s=9999|rg=5|z=10000;t|s=9999|rg=100;t|s=9999|rg=5|1=Activates when a player steps on it|z=5000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;m1|r=8|d=31|t=18|k=0.25|m=10|rg=1|1=Ignores 10 points of enemy Defense|z=500000;r1|r=8|d=38|t=30|k=1|rg=1|1=Latches on to enemies for continuous damage|z=1000000;s1|r=7|d=40|t=28|k=3|m=10|rg=1|1=Summons a Pygmy to fight for you|z=350000;a1|r=7|rg=1|1=Increases your max number of minions by 1|z=200000;41|r=7|D=6|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 10%|3=Increases whip range by 10%|z=500000;51|r=7|D=17|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 10%|z=500000;61|r=7|D=12|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 10%|z=500000;a1|r=5|rg=1|1=Allows flight and slow fall|z=1500000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height|z=150000;a1|r=8|rg=1|1=Allows the holder to quadruple jump|2=Increases jump height|z=150000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;d1|r=3|d=19|t=22|k=5.5|rg=1|z=9000;a1|r=7|rg=1|1=Increases summon damage by 15%|2=Increases the knockback of your minions|z=400000;c|s=9999|t=15|rg=25|z=20;1|r=3|t=20|rg=1|1=Summons a Baby Skeletron Head|z=250000;1|r=3|t=20|rg=1|1=Summons a Baby Hornet|z=150000;1|r=3|t=20|rg=1|1=Summons a Tiki Spirit|z=2000000;1|r=3|t=20|rg=1|1=Summons a Pet Lizard|z=100000;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=2;m1|r=7|d=48|t=7|k=4|m=5|rg=1|1=Rapidly shoots razor sharp leaves|z=300000;rb|s=9999|r=7|d=9|k=4.5|rg=99|1=Chases after your enemy|z=50;1|r=3|t=20|rg=1|1=Summons a Pet Parrot|z=3750000;1|r=3|t=20|rg=1|1=Summons a Baby Truffle|z=450000;1|r=3|t=20|rg=1|1=Summons a Pet Sapling|z=100000;1|r=8|t=20|rg=1|1=Summons a Wisp to provide light|z=275000;t|s=9999|r=3|rg=25|z=13500;d1|r=4|d=49|t=22|k=5.5|rg=1|z=92000;d1|r=4|d=44|t=27|k=4.5|rg=1|z=60000;r1|r=4|d=37|t=22|k=1.75|rg=1|z=80000;d1|r=4|d=12|t=25|k=5|tp=130|rg=1|1=Can mine Mythril and Orichalcum|z=72000;d1|r=4|d=12|t=15|k=0.5|tp=130|rg=1|1=Can mine Mythril and Orichalcum|z=72000;d1|r=4|d=26|t=15|k=2.9|tx=15|rg=1|z=72000;t|s=9999|r=3|rg=25|z=26000;d1|r=4|d=59|t=22|k=6|rg=1|z=126500;d1|r=4|d=46|t=25|k=5.5|rg=1|z=82500;r1|r=4|d=40|t=19|k=2|rg=1|z=110000;d1|r=4|d=17|t=25|k=5|tp=165|rg=1|1=Can mine Adamantite and Titanium|z=99000;d1|r=4|d=17|t=15|k=0.5|tp=165|rg=1|1=Can mine Adamantite and Titanium|z=99000;d1|r=4|d=31|t=15|k=3.75|tx=18|rg=1|z=99000;t|s=9999|r=3|rg=25|z=34000;d1|r=4|d=61|t=20|k=6|rg=1|z=161000;d1|r=4|d=48|t=23|k=6.2|rg=1|z=105000;r1|r=4|d=43|t=17|k=2.5|rg=1|z=140000;d1|r=4|d=27|t=25|k=5|tp=190|rg=1|z=126000;d1|r=4|d=27|t=15|k=0.5|tp=190|rg=1|z=126000;d1|r=4|d=34|t=15|k=4.6|tx=21|rg=1|z=126000;41|r=4|D=14|rg=1|1=12% increased melee damage|2=12% increased melee speed|z=75000;41|r=4|D=5|rg=1|1=9% increased ranged damage|2=9% increased ranged critical strike chance|z=75000;41|r=4|D=3|rg=1|1=9% increased magic damage and critical strike chance|2=Increases maximum mana by 60|z=75000;51|r=4|D=10|rg=1|1=3% increased damage|2=2% increased critical strike chance|z=60000;61|r=4|D=8|rg=1|1=2% increased damage|2=1% increased critical strike chance|z=45000;41|r=4|D=19|rg=1|1=11% increased melee damage and melee speed|2=7% increased movement speed|z=112500;41|r=4|D=7|rg=1|1=15% increased ranged critical strike chance|2=8% increased movement speed|z=112500;41|r=4|D=4|rg=1|1=18% increased magic critical strike chance|2=Increases maximum mana by 80|z=112500;51|r=4|D=13|rg=1|1=6% increased critical strike chance|z=90000;61|r=4|D=10|rg=1|1=8% increased damage and 11% increased movement speed|z=67500;41|r=4|D=23|rg=1|1=9% increased melee damage and critical strike chance|2=9% increased melee speed|z=150000;41|r=4|D=8|rg=1|1=16% increased ranged damage|2=7% increased ranged critical strike chance|z=150000;41|r=4|D=4|rg=1|1=16% increased magic damage and 7% increased magic critical strike chance|2=Increases maximum mana by 100|z=150000;51|r=4|D=15|rg=1|1=4% increased damage|2=3% increased critical strike chance|z=120000;61|r=4|D=11|rg=1|1=3% increased damage and critical strike chance|2=6% increased movement speed|z=90000;t|s=9999|r=3|rg=1|1=Used to craft items from mythril, orichalcum, adamantite, and titanium bars|z=25000;t|s=9999|r=3|rg=1|1=Used to smelt adamantite and titanium ore|z=50000;d1|r=4|d=36|t=35|k=5.5|tx=15|rg=1|z=72000;d1|r=4|d=41|t=35|k=6.5|tx=18|rg=1|z=99000;d1|r=4|d=44|t=35|k=7.5|tx=21|rg=1|z=126000;t|s=9999|r=4|rg=25|z=20000;d1|r=7|d=95|t=26|k=6|rg=1|1=Shoots a powerful orb|z=276000;d1|r=7|d=57|t=16|k=4|rg=1|1=Shoots a spore cloud|z=276000;d1|r=7|d=49|t=23|k=6.2|rg=1|1=Shoots a spore cloud|z=180000;r1|r=7|d=34|t=19|k=2.75|rg=1|z=240000;d1|r=7|d=40|t=25|k=5|tp=200|tr=1|rg=1|z=216000;d1|r=7|d=35|t=15|k=1|tp=200|rg=1|z=216000;d1|r=7|d=50|t=15|k=4.6|tx=23|rg=1|z=216000;d1|r=7|d=70|t=30|k=7|tx=23|tr=1|rg=1|z=216000;d1|r=7|d=80|t=35|k=8|th=90|tr=1|rg=1|z=216000;rb|s=9999|r=7|d=16|k=3.5|rg=99|1=Bounces back after hitting a wall|z=100;1|t=20|k=7|rg=1|z=20000;1|t=20|k=7|rg=1|z=20000;1|t=20|k=7|rg=1|z=20000;1|t=20|k=7|rg=1|z=20000;1|t=20|k=7|rg=1|z=20000;1|t=20|k=7|rg=1|z=20000;1|r=3|t=20|rg=1|1=Summons a Baby Dinosaur|z=375000;4v1|rg=1;m1|r=6|d=30|t=22|m=30|rg=1|1=Summons a cloud to rain down on your foes|z=175000;t|s=9999|rg=100|z=60;b|s=9999|rg=100;a1|r=4|rg=1|1=Causes stars to fall, releases bees and douses the user in honey when damaged|z=150000;a1|r=7|rg=1|1=10% increased critical strike chance|z=250000;a1|r=2|rg=1|1=Increases jump height|2=Releases bees and douses the user in honey when damaged|z=100000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height and negates fall damage|z=150000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height and negates fall damage|z=150000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height and negates fall damage|z=150000;a1|r=5|rg=1|1=Puts a shell around the owner when below 50% life that reduces damage by 25%|z=225000;r1|r=8|c=25|d=185|t=36|k=8|rg=1|1=Shoots a powerful, high velocity bullet|2=Right Click to zoom out|z=400000;r1|r=7|d=50|t=9|k=5.5|rg=1|1=Shoots a powerful, high velocity bullet|z=250000;m1|d=12|t=24|m=30|rg=1|1=Summons a cloud to rain blood on your foes|z=75000;t|s=9999|rg=25|z=19500;r1|r=7|d=45|t=22|k=5|rg=1|1=Shoots an explosive bolt|2=Does extra damage on a direct hit|z=350000;d1|r=7|d=65|t=40|k=6.5|rg=1|1=Shoots razor sharp flower petals at nearby enemies|z=300000;m1|r=8|d=45|t=40|k=2.5|m=20|rg=1|1=Shoots a rainbow that does continuous damage|z=1000000;rb|s=9999|r=5|d=17|k=1|rg=99|1=Explodes into deadly shrapnel|z=75;d1|r=7|d=45|t=15|k=5.2|th=90|rg=1|z=216000;t|s=9999|rg=1|z=25000;m1|r=5|d=60|t=12|k=6.5|m=11|rg=1|1=Shoots a ball of frost|z=250000;r1|r=7|d=30|t=9|k=3.5|rg=1|1=Shoots a powerful, high velocity bullet|z=350000;m1|r=8|d=48|t=20|k=6|m=14|rg=1|z=500000;w|s=9999|rg=400|z=100;w|s=9999|rg=400|z=200;w|s=9999|rg=400|z=300;w|s=9999|rg=400|z=400;w|s=9999|rg=400|z=600;w|s=9999|rg=400|z=500;1|r=2|t=25|rg=1|z=45000;4v1|rg=1;4v1|rg=1|z=10000;4v1|rg=1|z=10000;4v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=37500;51|rg=1|1=Increases maximum mana by 20|2=Reduces mana usage by 5%|z=25000;51|D=1|rg=1|1=Increases maximum mana by 40|2=Reduces mana usage by 7%|z=50000;51|D=1|rg=1|1=Increases maximum mana by 40|2=Reduces mana usage by 9%|z=75000;51|D=2|rg=1|1=Increases maximum mana by 60|2=Reduces mana usage by 11%|z=100000;51|D=2|rg=1|1=Increases maximum mana by 60|2=Reduces mana usage by 13%|z=125000;51|r=2|D=3|rg=1|1=Increases maximum mana by 80|2=Reduces mana usage by 15%|z=150000;5v1|rg=1|z=250000;6v1|rg=1|z=250000;a1|rg=1|1=Increases movement speed after taking damage|z=75000;c|s=9999|r=7|t=30|rg=10|1=Permanently increases maximum life by 5|z=100000;t|s=9999|rg=1|z=300;c|s=9999|rg=3|1=Used at the Lihzahrd Altar|z=50000;d1|r=7|d=34|t=16|k=5.5|tp=210|tx=25|tr=1|rg=1|1=Capable of mining Lihzahrd Bricks|z=216000;m1|r=7|d=90|k=3|m=8|rg=1|1=Shoots a scorching ray of heat|2=Oolaa!!|z=350000;m1|r=7|c=20|d=125|t=24|k=7.5|m=18|rg=1|1=Summons a powerful boulder|z=350000;d1|r=7|d=90|t=24|k=12|rg=1|1=Punches with the force of a golem|z=350000;t|s=9999|rg=1|z=500;1|r=4|rg=1|1=Increases view range when held|z=150000;a1|r=4|rg=1|1=Increases view range for guns|2=Right Click to zoom out|z=150000;a1|r=7|rg=1|1=10% increased damage|2=8% increased critical strike chance|z=300000;rb|s=9999|r=3|d=11|k=4|rg=99|z=40;a1|r=2|rg=1|1=Generates a very subtle glow which becomes more vibrant underwater|z=50000;d1|d=15|t=22|k=5.5|rg=1|z=2000;d1|r=8|d=72|t=23|k=7.25|tx=35|th=100|tr=1|rg=1|z=500000;d1|r=5|d=50|t=25|k=5.5|rg=1|1=Shoots an icy sickle|z=250000;a1|rg=1|1=You are a terrible person|z=1000;m1|r=6|d=43|t=36|k=5.6|m=22|rg=1|1=Shoots a poison fang that pierces multiple enemies|z=200000;s1|r=4|d=8|t=28|k=2|m=10|rg=1|1=Summons a baby slime to fight for you|z=100000;rb|s=9999|r=2|d=10|k=2|rg=99|1=Inflicts poison on enemies;1|r=6|t=20|rg=1|1=Summons an eyeball spring|z=150000;1|r=6|t=20|rg=1|1=Summons a baby snowman|z=125000;m1|r=2|d=29|t=26|k=3.5|m=18|rg=1|1=Shoots a skull|z=75000;d1|r=4|d=40|t=28|k=6.5|rg=1|1=Shoots a boxing glove|z=175000;c|s=9999|t=45|rg=3|1=Summons a pirate invasion;41|r=8|D=21|rg=1|1=6% increased melee damage|2=Enemies are more likely to target you|z=300000;51|r=8|D=27|rg=1|1=8% increased melee damage and critical strike chance|2=Enemies are more likely to target you|z=240000;61|r=8|D=17|rg=1|1=4% increased melee critical strike chance|2=Enemies are more likely to target you|z=180000;r1|d=10|t=19|k=1|rg=1|z=100000;d1|d=8|t=19|k=3|tp=55|rg=1|z=15000;a1|r=4|rg=1|1=Increases arrow damage by 10% and greatly increases arrow speed|2=20% chance to not consume arrows|z=250000;a1|r=3|rg=1|1=Melee attacks inflict fire damage|z=100000;a1|r=3|rg=1|1=Reduces damage from touching lava|z=100000;d1|r=5|d=45|t=11|k=6.5|rg=1|z=750000;d1|d=12|t=20|k=3.5|rg=1|z=12500;1|r=7|t=20|rg=1|1=Teleports you to the position of the mouse|2=Causes the chaos state|z=500000;d1|r=6|d=57|t=25|k=5|rg=1|1=Shoots a deathly sickle|z=375000;|s=9999|r=7|rg=3|z=5000;|s=9999|rg=25|z=750;|s=9999|rg=25|z=12;c|s=9999|t=45|rg=3|1=Summons the Brain of Cthulhu;|s=9999|r=3|rg=25|1=The blood of gods|z=4500;t|s=9999|rg=100|1=Can be placed in water|z=160;rb|s=9999|r=3|d=16|k=3|rg=99|1=Decreases targets defense|z=40;rb|s=9999|r=3|d=13|k=4|rg=99|1=Decreases targets defense|z=30;m1|r=4|d=30|t=18|k=4|m=7|rg=1|1=Sprays a shower of ichor|2=Decreases targets defense|z=200000;t|s=9999|rg=1|z=500000;c|s=9999|d=350|t=20|rg=25|1=For use with bunny cannon|z=3500;|s=9999|rg=25|1=Extremely toxic|z=1500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks inflict Acid Venom on enemies|z=2500;rb|s=9999|r=3|d=19|k=4.2|rg=99|1=Inflicts target with Acid Venom|z=90;rb|s=9999|r=3|d=15|k=4.1|rg=99|1=Inflicts target with Acid Venom|z=40;a1|r=7|rg=1|1=Increases melee knockback and melee attacks inflict fire damage|2=12% increased melee damage and speed|3=Enables auto swing for melee weapons|4=Increases the size of melee weapons|z=300000;t|s=9999|rg=100|z=700;c|s=9999|t=20|rg=25|z=200;|s=9999|rg=25|z=1500;|s=9999|rg=25|z=1200;|s=9999|rg=25|z=1700;rb|s=9999|r=3|d=10|k=5|rg=99|1=Explodes into confetti on impact|z=10;rb|s=9999|r=3|d=15|k=3.6|rg=99|1=Causes confusion and bounces back after hitting a wall|z=40;rb|s=9999|r=3|d=10|k=6.6|rg=99|1=Explodes on impact|z=40;rb|s=9999|r=3|d=10|k=3.6|rg=99|1=Enemies killed will drop more money|z=40;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks inflict enemies with cursed flames|z=2500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks set enemies on fire|z=2500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks make enemies drop more gold|z=2500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks decrease enemies defense|z=2500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks confuse enemies|z=2500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks cause confetti to appear|z=1500;c|s=9999|r=4|t=17|rg=20|1=Melee and Whip attacks poison enemies|z=2500;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1;t|s=9999|rg=1;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1;t|s=9999|rg=25;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=R. Moosdijk|z=5000;t|s=9999|rg=1|1=R. Moosdijk|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;4v1|rg=1|z=10000;t|s=9999|r=2|rg=1|1=Used to craft weapon imbuement flasks|z=70000;t|s=9999|rg=1|1=Increases mana regeneration when placed nearby|z=2500;|s=9999|rg=100|1=Used to craft various types of ammo|z=5;t|s=9999|rg=1|1=K. Wright|z=5000;t|s=9999|rg=1|1=C. J. Ness|z=5000;t|s=9999|rg=1|1=R. Moosdijk|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=A. G. Kolf|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;m1|r=8|d=80|t=15|k=3.25|m=7|rg=1|1=Creates a shadow beam that bounces off walls|z=300000;m1|r=8|d=70|t=30|k=5|m=18|rg=1|1=Launches a ball of fire that explodes into a raging inferno|z=300000;m1|r=8|d=65|t=24|k=6|m=15|rg=1|1=Summons a lost soul to chase your foes|z=300000;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=1|1=Blows bubbles|z=40000;1|t=25|rg=1|1=Blows bubbles|z=50000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=A. G. Kolf|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=A. G. Kolf|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=C. Burczyk|z=5000;41|r=8|D=6|rg=1|z=375000;51|r=8|D=14|rg=1|1=7% increased magic damage and critical strike chance|z=300000;61|r=8|D=10|rg=1|1=8% increased magic damage|2=8% increased movement speed|z=225000;d1|r=8|d=32|t=24|k=5.25|tp=200|tr=3|rg=1|z=216000;d1|r=8|d=60|t=28|k=7|tx=30|th=90|tr=3|rg=1|z=216000;|s=9999|r=8|rg=25|z=25000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;d1|r=8|d=90|t=15|k=9|rg=1|1=A powerful returning hammer|z=500000;4v1|rg=1|z=50000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;|s=9999|r=5|rg=1|z=125000;|s=9999|r=5|rg=1|z=125000;|s=9999|r=5|rg=1|z=125000;|s=9999|r=5|rg=1|z=125000;|s=9999|r=5|rg=1|z=125000;|s=9999|r=5|rg=1|z=125000;1|rg=1|1=For Capture the Gem. It drops when you die;1|rg=1|1=For Capture the Gem. It drops when you die;1|rg=1|1=For Capture the Gem. It drops when you die;1|rg=1|1=For Capture the Gem. It drops when you die;1|rg=1|1=For Capture the Gem. It drops when you die;1|rg=1|1=For Capture the Gem. It drops when you die;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;|s=9999|r=8|rg=1|1=Unlocks a Jungle Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks a Corruption Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks a Crimson Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks a Hallowed Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks an Ice Chest in the dungeon;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=A. Craig|z=5000;t|s=9999|rg=1|1=A. Craig|z=5000;t|s=9999|rg=1|1=A. Craig|z=5000;t|s=9999|rg=1|1=A. Craig|z=5000;1|t=15|tr=3|rg=1|1=Used with paint to color blocks|2=Can also apply coatings|z=300000;1|t=15|tr=3|rg=1|1=Used with paint to color walls|2=Can also apply coatings|z=300000;1|t=15|tr=3|rg=1|1=Used to remove paint or coatings|2=Can sometimes collect moss|z=300000;41|r=8|D=11|rg=1|1=15% increased damage from bows|2=5% increased ranged critical strike chance|z=375000;41|r=8|D=11|rg=1|1=15% increased damage from guns|2=5% increased ranged critical strike chance|z=375000;41|r=8|D=11|rg=1|1=15% increased damage from specialist ranged weapons|2=These are launchers, dartguns, or anything else that doesnt shoot arrows/bullets|3=5% increased ranged critical strike chance|z=375000;51|r=8|D=24|rg=1|1=13% increased ranged damage & critical strike chance|2=20% chance to not consume ammo|z=300000;61|r=8|D=16|rg=1|1=7% increased ranged critical strike chance|2=12% increased movement speed|z=225000;t|s=9999|rg=1|1=Converts Chlorophyte Bars into Shroomite Bars|z=1000000;t|s=9999|r=7|rg=25|z=50000;r1|r=10|c=10|d=85|t=5|k=2.5|rg=1|1=66% chance to not consume ammo|2=It came from the edge of space|z=750000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;d1|r=8|d=29|t=16|k=2.75|rg=1|1=Rapidly throw life stealing daggers|z=1000000;|s=9999|r=8|rg=1|z=375000;d1|r=8|d=70|t=20|k=5|rg=1|1=A powerful javelin that unleashes tiny eaters|z=1000000;sS1|r=8|d=100|t=30|k=7.5|m=20|rg=1|1=Summons a sentry|2=Summons a powerful frost hydra to spit ice at your enemies|z=1000000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=W. Garner|z=5000;t|s=9999|rg=1|1=D. Phelps|z=5000;t|s=9999|rg=1|1=M. J. Duncan|z=5000;a1|r=3|rg=1|1=Releases bees, douses the user in honey and increases movement speed when damaged|z=100000;a1|rg=1|1=The wearer can run super fast|z=50000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;a1|r=2|rg=1|1=Increases maximum mana by 20|2=Restores mana when damaged|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;|s=9999|r=5|rg=1|z=125000;a1|r=6|rg=1|1=Grants immunity to most debuffs|z=150000;a1|r=7|D=4|rg=1|1=Grants immunity to knockback and fire blocks|2=Grants immunity to most debuffs|z=250000;rb|s=9999|d=1|k=1.5|rg=99|z=7;t|s=9999|rg=1|1=Nearby players get a bonus against: Angler Fish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Angry Nimbus|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Anomura Fungus|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Antlion|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Arapaima|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Armored Skeleton|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Cave Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Bird|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Black Recluse|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Feeder|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Jelly|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Crawler|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Bone Serpent|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Bunny|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Chaos Elemental|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mimic|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Clown|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corrupt Bunny|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corrupt Goldfish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crab|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crimera|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crimson Axe|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Cursed Hammer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Demon|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Demon Eye|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Derpling|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Eater of Souls|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Enchanted Sword|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Frozen Zombie|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Face Monster|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Floaty Gross|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Flying Fish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Flying Snake|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Frankenstein|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Fungi Bulb|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Fungo Fish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Gastropod|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Thief|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Sorcerer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Peon|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Scout|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Warrior|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goldfish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Harpy|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hellbat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Herpling|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hornet|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ice Elemental|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Icy Merman|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Fire Imp|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blue Jellyfish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Jungle Creeper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Lihzahrd|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Man Eater|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Meteor Head|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Moth|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mummy|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mushi Ladybug|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Parrot|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pigron|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Piranha|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pirate Deckhand|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pixie|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Raincoat Zombie|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Reaper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Shark|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Skeleton|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dark Caster|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blue Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Snow Flinx|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Wall Creeper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Spore Zombie|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Swamp Thing|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Giant Tortoise|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Toxic Sludge|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Umbrella Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Unicorn|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Vampire|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Vulture|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Nymph|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Werewolf|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Wolf|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: World Feeder|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Giant Worm|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Wraith|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Wyvern|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Zombie|z=1000;t|s=9999|rg=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;w|s=9999|rg=400;a1|r=2|rg=1|1=Allows the holder to double jump|z=50000;t|s=9999|rg=100|z=125;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;41|D=2|rg=1;51|D=3|rg=1;61|D=2|rg=1;1;1;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;4v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;4v1|rg=1|1=To me it look like a leprechaun to me|z=30000;5v1|rg=1|1=I just wanna know where the gold at!|z=30000;6v1|rg=1|1=I want the gold. I want the gold. I want the gold. Gimme the gold!|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;|s=9999|r=3|rg=10|1=Right Click to open|z=50000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;r1|r=8|c=6|d=44|t=9|k=2|rg=1|1=33% chance to not consume ammo|z=500000;rb|s=9999|d=9|k=1.5|rg=99|z=5;r1|r=8|c=6|d=65|t=25|k=5|rg=1|z=500000;rb|s=9999|d=60|k=3|rg=99|z=15;d1|d=9|t=24|k=2.25|rg=1|1=Allows the collection of hay from grass|z=6000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Stuff it all up in one bite!|z=1000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;t|s=9999|rg=1|z=15000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=200;a1|r=7|rg=1|1=Allows flight and slow fall|z=400000;1|r=3|t=20|rg=1|1=Summons a pet spider|z=100000;1|r=3|t=20|rg=1|1=Summons a pet squashling|z=100000;1|r=3|t=20|k=7|rg=1|z=75000;m1|r=8|d=45|t=12|k=3|m=6|rg=1|1=Summons bats to attack your enemies|z=500000;s1|r=8|d=55|t=28|k=3|m=10|rg=1|1=Summons a raven to fight for you|z=500000;|s=9999|r=8|rg=1|1=Unlocks a Jungle Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks a Corruption Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks a Crimson Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks a Hallowed Chest in the dungeon;|s=9999|r=8|rg=1|1=Unlocks an Ice Chest in the dungeon;t|s=9999|rg=1;rc|s=9999|d=13|t=19|k=6.5|rg=99|1=Best used for pranking townsfolk;1|r=3|t=20|rg=1|1=Summons a black kitty|z=100000;|s=9999|r=5|rg=1|z=125000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=200;4v1|rg=1|z=30000;5v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;d1|r=2|d=20|t=15|k=5|rg=1|z=50000;d1|r=8|d=150|t=26|k=7.5|rg=1|1=Summons Pumpkin heads to attack your enemies|z=500000;d1|r=2|d=14|t=8|k=4|rg=1|z=50000;t|s=9999|rg=25|z=250;1|r=7|t=20|k=7|rg=1|z=200000;a1|r=7|rg=1|1=Allows flight and slow fall|z=400000;|s=9999|r=5|rg=1|z=125000;41|r=8|D=9|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 11%|z=50000;51|r=8|D=11|rg=1|1=Increases your max number of minions by 2|2=Increases summon damage by 11%|z=50000;61|r=8|D=10|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 11%|3=20% increased movement speed|z=50000;r1|r=8|c=10|d=75|t=12|k=6.5|rg=1|z=500000;rb|s=9999|d=25|k=4.5|rg=99|z=15;1|r=3|t=20|rg=1|1=Summons a cursed sapling to follow you|z=100000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;c|s=9999|r=8|t=45|rg=3|1=Summons the Pumpkin Moon;a1|r=8|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 10%|z=200000;t|s=9999|rg=1|1=V. Costa Moura|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;4v1|r=3|rg=1|z=250000;a1|r=7|rg=1|1=Increases view range for guns (Right Click to zoom out)|2=10% increased ranged damage and critical strike chance|z=300000;t|s=9999|r=2|rg=1|1=Increases life regeneration when placed nearby|z=75000;a1|r=5|rg=1|1=Grants the ability to swim and greatly extends underwater breathing|2=Generates a very subtle glow which becomes more vibrant underwater|z=150000;a1|r=6|rg=1|1=Grants the ability to swim and greatly extends underwater breathing|2=Provides extra mobility on ice|3=Generates a very subtle glow which becomes more vibrant underwater|z=250000;a1|r=7|rg=1|1=Allows flight, super fast running, and extra mobility on ice|2=8% increased movement speed|z=350000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height|z=150000;a1|r=8|rg=1|1=Increases your max number of minions by 1|2=Increases your summon damage by 15% and the knockback of your minions|z=250000;a1|r=7|rg=1|1=Minor increase to damage, melee speed, critical strike chance,|2=life regeneration, defense, mining speed, and minion knockback|z=400000;a1|r=5|rg=1|1=Allows flight and slow fall|2=Press Down to toggle hover|3=Press Up to deactivate hover|z=400000;1;1;t|s=9999|rg=10|1=Right Click to open;r1|d=20|t=38|k=3.75|rg=1|1=Dont shoot your eye out!|z=100000;a1|r=5|rg=1|1=Allows flight and slow fall|z=400000;t|s=9999|rg=100;t|s=9999|rg=1|z=2500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;c|s=9999|t=15|rg=1|1=Placeable on a christmas tree|z=500;4v1|rg=1|z=10000;4v1|rg=1|z=10000;t|s=9999|rg=1|z=5000;d1|d=19|t=27|k=5.3|rg=1|z=13500;r1|r=8|d=53|t=30|k=0.425|rg=1|1=Uses gel for ammo|2=Ignores 15 points of enemy Defense|z=500000;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=A cozy treat by the fireplace.|z=1000;c|s=9999|hl=80|t=17|rg=30|z=40;rc|s=9999|d=14|t=15|rg=99|z=25;1|r=8|t=20|rg=1|1=Summons a rideable reindeer|z=250000;1|r=7|t=20|k=7|rg=1|z=100000;1|r=7|t=20|k=7|rg=1|z=200000;d1|d=7|t=20|k=2.5|tp=55|rg=1|1=Can mine Meteorite|z=10000;d1|d=19|t=15|k=8|rg=1|z=50000;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=Youll bounce off the walls!|z=2500;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=Not the gumdrop buttons!|z=2500;a1|r=2|rg=1|1=Provides immunity to chill and freezing effects|z=50000;1|rg=1|1=Youve been naughty this year;a1|r=2|rg=1|1=Increases block placement & tool range by 1|z=50000;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;1|r=3|t=20|rg=1|1=Summons a Puppy;d1|r=8|d=86|t=23|k=7|rg=1|1=Shoots Christmas ornaments|z=500000;r1|r=8|d=31|t=4|k=1.75|rg=1|1=50% chance to not consume ammo|z=450000;m1|r=8|d=48|t=8|k=3.25|m=5|rg=1|1=Shoots razor sharp pine needles|z=450000;m1|r=8|d=58|k=4.5|m=9|rg=1|1=Showers an area with icicles|z=450000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;r1|r=8|d=67|t=15|k=4|rg=1|1=Launches homing missiles|z=450000;d1|r=7|d=73|t=30|k=6.7|rg=1|1=Shoots an icy spear that rains snowflakes|z=450000;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;c|s=9999|r=8|t=45|rg=3|1=Summons the Frost Moon;1|r=3|t=20|rg=1|1=Summons a Baby Grinch|z=100000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;|s=9999|rg=100|z=25;|s=9999|rg=100|z=50;|s=9999|rg=100|z=75;|s=9999|rg=3|z=10000;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;c|s=9999|r=2|t=17|rg=1|z=50000;c|s=9999|r=2|t=17|rg=1|z=50000;c|s=9999|r=2|t=17|rg=1|z=50000;c|s=9999|r=2|t=17|rg=1|z=100000;c|s=9999|r=2|t=17|rg=1|z=50000;c|s=9999|r=2|t=17|rg=1|z=50000;c|s=9999|r=2|t=17|rg=1|z=50000;c|s=9999|r=2|t=17|rg=1|z=75000;c|s=9999|r=2|t=17|rg=1|z=150000;c|s=9999|r=2|t=17|rg=1|z=50000;av1|r=5|rg=1|z=400000;4v1|rg=1|1=Fezzes are cool|z=35000;t|s=9999|rg=1|1=Right Click to customize attire;c|s=9999|r=2|t=17|rg=1|z=20000;1|t=25|rg=1|1=Used to catch critters|z=2500;c|s=9999|t=15|rg=5|z=1500;t|s=9999|rg=1;c|s=9999|t=15|rg=5|z=2500;c|s=9999|r=2|t=15|rg=5|z=37500;c|s=9999|r=2|t=15|rg=5|z=20000;c|s=9999|t=15|rg=5|z=10000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|r=3|t=15|rg=5|z=50000;c|s=9999|t=15|rg=5|z=7500;c|s=9999|t=15|rg=5|z=15000;c|s=9999|t=15|rg=5|z=2500;c|s=9999|t=15|rg=5|z=5000;c|s=9999|r=2|t=15|rg=5|z=2500;t|s=9999|rg=1;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=25000;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;c|s=9999|t=15|rg=5|z=2500;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=2500;c|s=9999|t=15|rg=5|z=2500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=100;t|s=9999|rg=100;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=3750;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;c|s=9999|t=15|rg=5|z=7500;c|s=9999|t=15|rg=5|z=7500;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;w|s=9999|rg=400|z=75;|s=9999|r=5|rg=3|z=50000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=25|z=500;t|s=9999|rg=1|1=Used for advanced crafting|z=500;t|s=9999|rg=100;t|s=9999|rg=1;t|s=9999|rg=1;d1|r=8|d=45|t=12|k=6|tp=200|tx=25|rg=1|z=200000;t|s=9999|r=6|rg=1|1=Reduces ammo usage by 20%|z=100000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;m1|r=7|d=44|t=30|k=7|m=25|rg=1|1=Shoots a venom fang that pierces multiple enemies|z=350000;41|r=8|D=18|rg=1|1=Increases maximum mana by 60 and reduces mana usage by 13%|2=10% increased magic damage and critical strike chance|z=375000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;41|r=8|D=23|rg=1|1=6% increased melee damage|2=Enemies are more likely to target you|z=300000;51|r=8|D=20|rg=1|1=8% increased melee damage and critical strike chance|2=6% increased movement and melee speed|z=240000;51|r=8|D=32|rg=1|1=5% increased melee damage and critical strike chance|2=Enemies are more likely to target you|z=240000;61|r=8|D=18|rg=1|1=6% increased movement and melee speed|2=Enemies are more likely to target you|z=180000;t|s=9999|rg=1|1=Used for special crafting|z=100000;t|s=9999|rg=1|1=Used for special crafting|z=100000;c|s=9999|t=15|rg=5|z=6250;t|s=9999|rg=1;t|s=9999|rg=1;|s=9999|rg=1;c|s=9999|r=4|hm=300|t=17|rg=30|z=1500;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;a1|r=3|rg=1|1=Increases tile placement speed|z=100000;a1|r=3|rg=1|1=Increases block placement & tool range by 3|z=100000;a1|r=3|rg=1|1=Automatically paints or coats placed objects|z=100000;a1|r=3|rg=1|1=Increases wall placement speed|z=100000;|s=9999|r=8|rg=25|z=25000;a1|r=4|rg=1|1=Increases pickup range for mana stars|z=150000;a1|r=5|rg=1|1=Increases pickup range for mana stars|2=15% increased magic damage|z=160000;a1|r=5|rg=1|1=Increases pickup range for mana stars|2=Restores mana when damaged|3=Increases maximum mana by 20|z=160000;4v1|rg=1|z=12500;r1|r=8|c=7|d=80|t=20|k=3|rg=1|1=Shoots a charged arrow|z=450000;t|s=9999|rg=1|z=160;t|s=9999|rg=1|z=120;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=120;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=320;t|s=9999|rg=1|z=600;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=20;t|s=9999|rg=1|z=20;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=20;t|s=9999|rg=1|z=20;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=20;t|s=9999|rg=1|z=5000;t|s=9999|rg=1|z=300;t|s=9999|rg=100|z=50;t|s=9999|rg=100|z=50;t|s=9999|rg=100|z=50;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=1|z=200;c|s=9999|t=17|rg=20|1=Minor improvements to melee stats & lowered defense|2=Drink too much of this, and you become karate master.|z=500;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Spicy level 5!|z=5500;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Pho sho...|z=7500;r1|r=2|c=5|d=20|t=22|k=4|rg=1|z=100000;r1|r=4|d=21|t=7|k=1.5|rg=1|1=50% chance to not consume ammo|2=Highly inaccurate|z=350000;w|s=9999|rg=400|z=250;1|t=20|rg=1|1=Squirts a harmless stream of water|z=15000;d1|c=15|d=18|t=20|k=3.5|rg=1|z=100000;t|s=9999|rg=100|z=300;41|r=2|D=2|rg=1|1=6% increased magic damage and critical strike chance|z=30000;av1|r=8|rg=1|z=2000000;51|D=4|rg=1|1=5% increased damage and critical strike chance|2=10% increased melee and movement speed|z=20000;5v1|rg=1|z=10000;51|D=2|rg=1|1=6% increased magic damage and critical strike chance|2=Reduces mana usage by 10%|z=35000;a1|r=7|rg=1|1=Allows flight and slow fall|z=400000;t|s=9999|rg=1|z=10000;t|s=9999|rg=1|z=10000;t|s=9999|rg=1|z=10000;av1|r=5|rg=1|z=50000;av1|r=5|rg=1|z=50000;av1|r=5|rg=1|z=50000;av1|r=5|rg=1|z=50000;t|s=9999|rg=1|z=150;1|t=8|tf=5|rg=1|z=300;|s=9999|rg=3|z=2500;1|t=8|tf=15|rg=1|z=12000;1|r=2|t=8|tf=30|rg=1|z=50000;1|t=8|tf=20|rg=1|z=120000;1|r=3|t=8|tf=50|rg=1|z=1000000;1|r=2|t=8|tf=35|rg=1|z=200000;1|r=2|t=8|tf=40|rg=1|z=350000;|s=9999|rg=3|z=2500;|s=9999|rg=3|z=3750;|s=9999|rg=3|z=3750;|s=9999|rg=3|z=3750;|s=9999|rg=3|z=3750;|s=9999|rg=3|1=Its colorful scales could sell well.|z=7500;|s=9999|rg=3|z=7500;|s=9999|rg=3|z=15000;|s=9999|rg=3|z=3750;|s=9999|rg=3|z=7500;|s=9999|r=2|rg=3|z=12500;|s=9999|r=4|rg=3|1=Quite shiny. This will probably sell well.|z=500000;|s=9999|rg=3|z=3750;|s=9999|r=3|rg=3|z=50000;|s=9999|rg=3|z=7500;|s=9999|r=2|rg=3|z=25000;|s=9999|rg=3|z=7500;c|s=9999|hl=120|t=17|rg=30|z=7500;|s=9999|r=2|rg=3|z=7500;|s=9999|rg=3|z=7500;|s=9999|r=4|rg=3|z=150000;|s=9999|rg=3|z=7500;|s=9999|rg=3|z=7500;d1|r=3|d=24|t=24|k=6|th=70|rg=1|z=75000;|s=9999|rg=3|z=12500;c|s=9999|t=17|rg=20|1=Increases mining speed by 25%|z=1000;c|s=9999|t=17|rg=20|1=Increases pickup range for life hearts|z=1000;c|s=9999|t=17|rg=20|1=Decreases enemy spawn rate|z=1000;c|s=9999|t=17|rg=20|1=Increases placement speed and range|z=1000;c|s=9999|t=17|rg=20|1=Increases knockback|z=1000;c|s=9999|t=17|rg=20|1=Lets you move swiftly in liquids|z=1000;c|s=9999|t=17|rg=20|1=Increases your max number of minions by 1|z=1000;c|s=9999|t=17|rg=20|1=Allows you to see nearby danger sources|z=1000;d1|d=35|t=35|k=8|rg=1|z=50000;d1|r=7|c=20|d=70|t=20|k=6.5|rg=1|z=50000;d1|r=2|d=19|t=20|k=4.25|rg=1|z=25000;w|s=9999|rg=400;t|s=9999|rg=10|1=Right Click to open|z=5000;t|s=9999|r=2|rg=10|1=Right Click to open|z=25000;t|s=9999|r=3|rg=10|1=Right Click to open|z=100000;c|s=9999|t=15|rg=1;c|s=9999|t=15|rg=1;c|s=9999|t=15|rg=1;t|s=9999|tr=5|rg=100|1=Hammer end piece to change bumper style|2=Hammer intersections to change direction;d1|r=3|d=16|t=22|k=3|tp=59|rg=1|z=75000;d1|r=3|d=13|t=15|k=2.25|tx=14|rg=1|z=75000;1|rg=1|1=Lets ride the rails|z=1000;c|s=9999|t=17|rg=20|1=20% chance to not consume ammo|z=1000;c|s=9999|t=17|rg=20|1=Increases max life by 20%|z=1000;c|s=9999|t=17|rg=20|1=Reduces damage taken by 10%|z=1000;c|s=9999|t=17|rg=20|1=Increases critical chance by 10%|z=1000;c|s=9999|t=17|rg=20|1=Ignites nearby enemies|z=1000;c|s=9999|t=17|rg=20|1=Increases damage by 10%|z=1000;c|s=9999|t=30|rg=20|1=Teleports you home|z=1000;c|s=9999|t=17|rg=20|1=Teleports you to a random location|z=1000;c|s=9999|t=15|rg=20|1=Throw this to make someone fall in love|z=200;c|s=9999|t=15|rg=20|1=Throw this to make someone smell terrible|z=200;c|s=9999|t=17|rg=20|1=Increases fishing power by 15|z=1000;c|s=9999|t=17|rg=20|1=Detects hooked fish|z=1000;c|s=9999|t=17|rg=20|1=Increases chance to get a crate|z=1000;t|s=9999|rg=25|z=80;|s=9999|rg=25|z=100;c|s=9999|t=17|rg=20|1=Reduces damage from cold sources|z=1000;1|r=3|t=20|rg=1|z=20000;41|r=3|D=4|rg=1|1=Increases summon damage by 4%|2=Increases your max number of minions by 1|z=45000;51|r=3|D=5|rg=1|1=Increases summon damage by 4%|2=Increases your max number of minions by 1|z=30000;61|r=3|D=4|rg=1|1=Increases summon damage by 5%|z=30000;s1|r=3|d=12|t=22|k=2|m=10|rg=1|1=Summons a hornet to fight for you|z=10000;s1|r=3|d=17|t=36|k=2|m=10|rg=1|1=Summons an imp to fight for you|z=10000;sS1|r=4|d=26|t=30|k=7.5|m=10|rg=1|1=Summons a sentry|2=Summons a spider queen to spit eggs at your enemies|z=250000;41|D=1|rg=1|1=Increases fishing power by 5|z=50000;51|D=2|rg=1|1=Increases fishing power by 5|z=50000;61|D=1|rg=1|1=Increases fishing power by 5|z=50000;41|r=4|D=5|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 5%|z=37500;51|r=4|D=8|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 5%|z=37500;61|r=4|D=7|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 6%|z=37500;a1|rg=1|1=Fishing line will never break|z=50000;a1|rg=1|1=Increases fishing power by 10|z=50000;a1|rg=1|1=Decreases chance of bait consumption|z=50000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;4v1|rg=1|z=50000;5v1|rg=1|z=50000;6v1|rg=1|z=50000;1|r=3|t=20|rg=1|1=Summons a pet Zephyr Fish|z=150000;1|t=8|tf=22|rg=1|z=156000;1|r=3|t=8|tf=45|rg=1|1=Allows fishing in lava|z=500000;a1|rg=1|1=Increases jump speed and allows auto-jump|2=Increases fall resistance|z=50000;d1|r=3|d=70|t=20|k=8|rg=1|z=50000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Wheres the chips!?|z=2500;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Barbecue it, boil it, broil it, bake it...|z=7500;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Its raw! Its exotic!|z=2500;1|r=8|t=20|rg=1|1=Summons a rideable Bunny mount|z=250000;1|r=8|t=20|rg=1|1=Summons a rideable Pigron mount|z=250000;1|r=8|t=20|rg=1|1=Summons a rideable Slime mount|z=250000;|s=9999|rg=25|z=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400|z=50;t|s=9999|rg=100|z=50;c|s=9999|t=15|rg=3|z=175000;c|s=9999|t=15|rg=3|z=175000;c|s=9999|t=15|rg=3|z=175000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;t|s=9999|rg=1|z=25000;1|rg=2|1=Caught in Underground & Caverns;1|rg=2|1=Caught in Honey;1|rg=2|1=Caught in Jungle Surface;1|rg=2|1=Caught in Sky Lakes;1|rg=2|1=Caught in Corruption;1|rg=2|1=Caught in Surface & Underground;1|rg=2|1=Caught in Surface;1|rg=2|1=Caught in Corruption;1|rg=2|1=Caught in Sky Lakes;1|rg=2|1=Caught in Sky Lakes & Surface;1|rg=2|1=Caught in Caverns;1|rg=2|1=Caught in Sky Lakes & Surface;1|rg=2|1=Caught in Caverns;1|rg=2|1=Caught in Crimson;1|rg=2|1=Caught in Underground & Caverns;1|rg=2|1=Caught in Underground Hallow;1|rg=2|1=Caught in Underground Tundra;1|rg=2|1=Caught in Surface Tundra;1|rg=2|1=Caught in Surface Hallow;1|rg=2|1=Caught in Underground & Caverns;1|rg=2|1=Caught in Surface Tundra;1|rg=2|1=Caught in Hallow;1|rg=2|1=Caught in Caverns;1|rg=2|1=Caught in Sky Lakes;1|rg=2|1=Caught in Surface;1|rg=2|1=Caught in Glowing Mushroom Fields;1|rg=2|1=Caught in Sky Lakes;1|rg=2|1=Caught in Crimson;1|rg=2|1=Caught in Underground & Caverns;1|rg=2|1=Caught in Surface;1|rg=2|1=Caught in Ocean;1|rg=2|1=Caught in Ocean;1|rg=2|1=Caught in Caverns;1|rg=2|1=Caught in Jungle Surface;1|rg=2|1=Caught in Underground Tundra;1|rg=2|1=Caught in Corruption;1|rg=2|1=Caught in Jungle;1|rg=2|1=Caught in Surface Forest;1|rg=2|1=Caught in Jungle Surface;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=150000;1|r=8|t=20|rg=1|1=Summons a rideable Turtle mount|z=250000;t|s=9999|tr=2|rg=5|1=Not for use on slopes|z=5000;4v1|rg=1|z=37500;a1|r=4|rg=1|1=Allows flight and slow fall|z=400000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|1=J. Hayes|z=25000;4v1|rg=1|z=50000;5v1|rg=1|z=50000;6v1|rg=1|z=50000;av1|r=5|rg=1|z=50000;1|r=8|t=20|rg=1|1=Summons a rideable Bee mount|z=250000;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;41|D=1|rg=1;51|D=1|rg=1;61|D=1|rg=1;41|D=1|rg=1;51|D=1|rg=1;61|D=1|rg=1;r1|d=6|t=29|rg=1|z=100;d1|d=4|t=33|k=5.5|th=35|rg=1|z=50;d1|d=8|t=19|k=6|rg=1|z=100;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;s1|r=5|d=21|t=36|k=2|m=10|rg=1|1=Summons twins to fight for you|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;s1|r=4|d=26|t=36|k=3|m=10|rg=1|1=Summons spiders to fight for you|z=50000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;s1|r=5|d=40|t=36|k=6|m=10|rg=1|1=Summons pirates to fight for you|z=50000;1|r=3|t=20|rg=1|z=20000;rc|s=9999|d=60|t=45|k=8|rg=99|1=A small explosion that will not destroy tiles|2=Tossing may be difficult.|z=75;1|r=3|t=20|rg=1|1=Summons a mini minotaur|z=100000;4v1|rg=1|z=37500;t|s=9999|rg=1|z=50000;rc|s=9999|d=23|t=40|k=7|rg=99|1=A small explosion that puts enemies on fire|2=Lights nearby area on fire for a while|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;|s=9999|r=4|rg=25|z=2500;d1|r=4|d=25|t=20|k=6|rg=1|z=10000;a1|r=8|rg=1|1=Allows flight and slow fall|2=Allows quick travel in water|z=400000;1|t=12|rg=1|1=Squirts a harmless stream of slime|z=15000;d1|r=8|d=66|t=20|k=4.5|rg=1|1=Spews homing bubbles|z=250000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;s1|r=8|d=50|t=36|k=2|m=10|rg=1|1=Summons sharknados to fight for you|z=250000;m1|r=8|d=85|t=40|k=5|m=20|rg=1|1=Casts fast moving razorwheels|z=250000;m1|r=8|d=70|t=9|k=3|m=5|rg=1|1=Rapidly shoots forceful bubbles|z=250000;r1|r=8|d=53|t=24|k=2|rg=1|1=Shoots 5 arrows at a time|z=250000;t|s=9999|rg=5|z=2500;t|s=9999|rg=5|z=5000;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|rg=5|z=500;c|s=9999|r=2|rg=5|z=1500;c|s=9999|r=3|rg=5|z=5000;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=1|1=Right Click to place item on weapon rack|z=250;t|s=9999|rg=1|z=50000;t|s=9999|rg=100;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=30000;t|s=9999|tr=2|rg=5|1=Hammer to change direction|z=5000;c|s=9999|t=15|rg=5|z=1250;t|s=9999|rg=1;at1|r=4|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=200;d1|d=8|t=20|k=6|rg=1|z=100;d1|d=4|t=33|k=5.5|th=35|rg=1|z=50;r1|d=6|t=29|rg=1|z=100;t|s=9999|rg=1|z=500;s1|r=8|d=36|t=36|k=2|m=10|rg=1|1=Summons a UFO to fight for you|z=500000;m1|r=5|d=50|k=4.5|m=9|rg=1|1=Showers meteors|z=100000;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;c|s=9999|t=17|rg=20|z=1000;41|r=10|D=14|rg=1|1=16% increased ranged damage|2=7% increased ranged critical strike chance|z=350000;51|r=10|D=28|rg=1|1=12% increased ranged damage and critical strike chance|2=25% chance not to consume ammo|z=700000;61|r=10|D=20|rg=1|1=8% increased ranged damage and critical strike chance|2=10% increased movement speed|z=525000;41|r=10|D=14|rg=1|1=Increases maximum mana by 60 and reduces mana usage by 15% |2=7% increased magic damage and critical strike chance|z=350000;51|r=10|D=18|rg=1|1=9% increased magic damage and critical strike chance|z=700000;61|r=10|D=14|rg=1|1=10% increased magic damage|2=10% increased movement speed|z=525000;41|r=10|D=24|rg=1|1=26% increased melee critical strike chance|2=Grants minor life regeneration|3=Enemies are more likely to target you|z=350000;51|r=10|D=34|rg=1|1=29% increased melee damage|2=Grants minor life regeneration|3=Enemies are more likely to target you|z=700000;61|r=10|D=20|rg=1|1=15% increased movement and melee speed|2=Grants minor life regeneration|3=Enemies are more likely to target you|z=525000;|s=9999|r=8|rg=10;c|s=9999|r=8|t=45|rg=3|1=Summons the Eclipse;1|r=8|t=20|rg=1|1=Summons a rideable Drill mount|2=Left Click to mine blocks, Right Click to mine walls|z=250000;1|r=8|t=20|rg=1|1=Summons a rideable UFO mount|z=250000;a1|r=8|rg=1|1=Allows flight and slow fall|z=625000;1|r=8|t=20|rg=1|1=Summons a rideable Scutlix mount|z=250000;d1|r=10|d=100|t=25|k=6|tx=27|tr=8|z=300000;d1|r=10|d=80|t=25|k=4|tx=27|tr=7|z=300000;d1|r=10|d=50|t=15|k=0.5|tp=225|tr=2|rg=1|z=350000;d1|r=10|d=110|t=30|k=7|th=100|tr=8|z=400000;d1|r=10|d=80|t=12|k=5.5|tp=225|tr=4|rg=1|z=350000;d1|r=10|d=100|t=25|k=6|tx=27|tr=8|z=300000;d1|r=10|d=80|t=25|k=4|tx=27|tr=7|z=300000;d1|r=10|d=50|t=15|k=0.5|tp=225|tr=2|rg=1|z=350000;d1|r=10|d=110|t=30|k=7|th=100|tr=8|z=400000;d1|r=10|d=80|t=12|k=5.5|tp=225|tr=4|rg=1|z=350000;d1|r=10|d=100|t=25|k=6|tx=27|tr=8|z=300000;d1|r=10|d=80|t=25|k=4|tx=27|tr=7|z=300000;d1|r=10|d=50|t=15|k=0.5|tp=225|tr=2|rg=1|z=350000;d1|r=10|d=110|t=30|k=7|th=100|tr=8|z=400000;d1|r=10|d=80|t=12|k=5.5|tp=225|tr=4|rg=1|z=350000;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;m1|r=8|d=60|t=20|k=2|m=6|rg=1|z=500000;r1|r=8|d=40|t=12|k=2|rg=1|z=500000;r1|r=8|d=45|t=21|k=3|rg=1|z=500000;d1|r=8|d=35|t=25|k=4.75|tp=230|tr=11|rg=1|z=500000;a1|rg=1|1=Creates measurement lines on screen for block placement|z=10000;1|r=7|t=20|k=7|rg=1|z=125000;4v1|rg=1;4v1|rg=1;4v1|rg=1|z=50000;5v1|rg=1|z=50000;6v1|rg=1|z=50000;4v1|rg=1|z=50000;5v1|rg=1|z=50000;6v1|rg=1|z=50000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;4v1|rg=1|z=100000;4v1|rg=1|z=100000;5v1|rg=1|z=100000;5v1|rg=1|z=100000;t|s=9999|rg=100;w|s=9999|rg=400;4v1|r=3|rg=1|z=50000;c|s=9999|r=3|t=17|rg=1|z=300000;|s=9999|r=3|rg=3|z=75000;t|s=9999|rg=1|1=J. Hayes|z=20000;t|s=9999|rg=1|1=J. Hayes|z=20000;t|s=9999|rg=1|1=J. Hayes|z=20000;t|s=9999|rg=100|z=100;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;|s=9999|r=3|rg=3|z=75000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;d1|r=8|d=100|t=20|k=4.5|rg=1|z=500000;1;m1|r=8|d=100|t=20|k=2|m=14|rg=1|z=500000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;c|s=9999|t=15|rg=99|1=Spreads the Crimson|z=100;|s=9999|rg=25|z=50;r1|r=3|d=23|t=23|k=3|rg=1|1=Wooden arrows turn into a column of bees|z=100000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|t=40|rg=99|1=A large explosion that will destroy most tiles|2=Tossing may be difficult.|z=2000;t|s=9999|rg=1|1=Nearby players get a bonus against: Angry Trapper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Armored Viking|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Black Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blue Armored Bones|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Cultist Archer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Lunatic Devotee|z=1000;t|s=9999|1=Nearby players get a bonus against: NPCName.None|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Bone Lee|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Clinger|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Cochineal Beetle|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corrupt Penguin|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corrupt Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corruptor|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crimslime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Cursed Skull|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Cyan Beetle|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Devourer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Diabolist|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Doctor Bones|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dungeon Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dungeon Spirit|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Elf Archer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Elf Copter|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Eyezor|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Flocko|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ghost|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Giant Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Giant Cursed Skull|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Giant Flying Fox|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Gingerbread Man|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Archer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Green Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Headless Horseman|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hell Armored Bones|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hellhound|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hoppin Jack|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ice Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ice Golem|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ice Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ichor Sticker|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Illuminant Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Illuminant Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Jungle Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Jungle Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Krampus|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Lac Beetle|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Lava Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Lava Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Brain Scrambler|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Martian Drone|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Martian Engineer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Gigazapper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Gray Grunt|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Martian Officer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ray Gunner|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Scutlix Gunner|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Tesla Turret|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mister Stabby|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mother Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Necromancer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Nutcracker|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Paladin|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Penguin|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pinky|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Poltergeist|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Possessed Armor|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Present Mimic|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Purple Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ragged Caster|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Rainbow Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Raven|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Red Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Rune Wizard|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Rusty Armored Bones|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Scarecrow|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Scutlix|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Skeleton Archer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Skeleton Commando|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Skeleton Sniper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Slimer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Snatcher|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Snow Balla|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Snowman Gangsta|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Spiked Ice Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Spiked Jungle Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Splinterling|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Squid|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Tactical Skeleton|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: The Groom|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Tim|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Undead Miner|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Undead Viking|z=1000;t|s=9999|1=Nearby players get a bonus against: Cultist Archer|z=1000;t|s=9999|1=Nearby players get a bonus against: NPCName.None|z=1000;t|s=9999|1=Nearby players get a bonus against: NPCName.None|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Yellow Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Yeti|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Zombie Elf|z=1000;t|s=9999|rg=1|1=V. Costa Moura|2=In loving memory|z=5000;t|s=9999|tr=3|rg=100|1=Can be climbed on;c|s=9999|rg=20|1=Teleports you to a party member|2=Click their head on the fullscreen map|z=1000;a1|r=4|rg=1|1=15% increased summon damage|z=100000;t|s=9999|rg=1|1=Right Click to have more minions|z=100000;t|s=9999|rg=1|1=33% chance to not consume potion crafting ingredients|z=100000;c|s=9999|hl=70|t=17|rg=30|1=Side Effects May Include:|2=-Unpredictable Healing|3=-Inconsistent Potion Sickness|4=-Brief Periods of Inexplicable Invulnerability|5=It looks and smells terrible|z=500;c|s=9999|t=15|rg=100|1=Exposes nearby treasure|z=150;rb|s=9999|d=8|k=2.5|rg=99|z=15;t|s=9999|rg=100|1=Emits a deathly glow|z=100;c|s=9999|t=20|rg=10|1=Throw to create a climbable line of vine rope;m1|r=5|d=35|t=12|k=2.5|m=10|rg=1|1=Drains life from enemies|z=400000;r1|r=5|d=28|t=22|k=3.5|rg=1|z=400000;r1|r=5|d=52|t=38|k=5.5|rg=1|z=400000;rb|s=9999|r=3|d=14|k=3.5|rg=99|1=Bounces between enemies|z=30;rb|s=9999|r=3|d=9|k=2.2|rg=99|1=Drops cursed flames on the ground|z=30;rb|s=9999|r=3|d=10|k=2.5|rg=99|1=Bursts into multiple darts|z=30;d1|r=5|d=59|t=14|k=3.25|rg=1|z=400000;d1|r=5|d=60|t=8|k=6|rg=1|z=400000;m1|r=5|d=43|t=24|k=8|m=40|rg=1|1=Summons a wall of cursed flames|z=400000;a1|r=6|rg=1|1=Enemies are less likely to target you|2=5% increased damage and critical strike chance|z=400000;a1|r=5|D=8|rg=1|1=Enemies are more likely to target you|z=400000;a1|r=7|rg=1|1=Flowers grow on the grass you walk on|z=300000;d1|r=5|d=50|t=23|k=6|rg=1|z=500000;r1|r=3|d=22|t=13|k=5.5|rg=1|1=Wooden arrows turn into flaming bats|z=125000;1|r=6|t=20|rg=1|z=300000;1|r=6|t=20|rg=1|z=300000;1|r=6|t=20|rg=1|z=300000;1|r=6|t=20|rg=1|z=300000;|s=9999|r=9|rg=3|1=Great for impersonating devs!|z=150000;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;r1|r=6|d=38|t=19|k=2.25|rg=1|1=Shoots arrows from the sky|z=400000;d1|r=6|d=40|t=15|k=4.5|rg=1|1=Throws a controllable flying knife|z=400000;1|r=7|t=12|tr=2|rg=1|1=Contains an endless amount of water|2=Can be poured out|z=500000;1|r=7|t=12|tr=2|rg=1|1=Capable of soaking up an endless amount of water|z=500000;a1|r=5|rg=1|1=Increases coin pickup range|z=50000;a1|r=5|rg=1|1=Increases coin pickup range|2=Hitting enemies will sometimes drop extra coins|z=100000;a1|r=6|rg=1|1=Increases coin pickup range and shops prices lowered by 20%|2=Hitting enemies will sometimes drop extra coins|z=150000;a1|r=3|rg=1|1=Displays weather, moon phase, and fishing information|z=150000;a1|rg=1|1=Displays the weather|z=50000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;|s=9999|r=3|rg=3|z=75000;1|r=3|t=20|rg=1|1=Summons a magic lantern that exposes nearby treasure|z=100000;at1|r=4|rg=1|z=100000;t|s=9999|rg=100|z=250;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;m1|r=5|d=25|t=33|k=3|m=13|rg=1|1=Summons a massive crystal spike|2=Ignores 10 points of enemy Defense|z=400000;r1|r=5|c=3|d=47|t=20|k=4.5|rg=1|1=Shoots Shadowflame Arrows|z=100000;m1|r=5|c=3|d=32|t=21|k=3.75|m=6|rg=1|1=Summons Shadowflame tentacles to strike your foes|z=100000;d1|r=5|c=3|d=38|t=12|k=5.75|rg=1|1=Inflicts Shadowflame on hit|z=100000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;t|s=9999|rg=1|1=J. Hayes|z=5000;1|r=3|t=20|rg=1|1=Summons a Baby Face Monster|z=375000;a1|r=5|rg=1|1=Increases block & wall placement speed|2=Increases block placement & tool range by 3|3=Automatically paints or coats placed objects|z=200000;1|t=20|rg=1|1=Summons a heart to provide light|z=75000;d1|r=10|d=200|t=14|k=6.5|rg=1|z=1000000;t|s=9999|r=7|rg=1|1=Allows time to fast forward to dawn one day per week|z=150000;d1|r=10|d=170|t=16|k=6.5|rg=1|1=Causes stars to rain from the sky|z=1000000;t|s=9999|rg=100;w|s=9999|rg=400;a1|rg=1|1=Allows the collection of Vine Rope from vines|z=25000;m1|c=10|d=14|t=26|m=2|rg=1|1=Shoots a small spark|z=10000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|tr=3|rg=100|1=Can be climbed on|z=10;t|s=9999|tr=3|rg=100|1=Can be climbed on|z=10;c|s=9999|t=20|rg=10|1=Throw to create a climbable line of silk rope|z=100;c|s=9999|t=20|rg=10|1=Throw to create a climbable line of web rope|z=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;a1|rg=1|1=Detects enemies around you|z=25000;|s=9999|r=2|rg=5|1=Right Click to open|2=Requires a Golden Key|z=20000;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;a1|r=2|rg=1|1=Slimes become friendly|z=100000;|s=9999|rg=1|1=Charged with the essence of many souls;|s=9999|rg=1|1=Charged with the essence of many souls;|s=9999|rg=2|1=Right Click to open|z=5000;rc|s=9999|d=17|t=24|k=4.75|rg=99|z=25;a1|rg=1|1=Displays how many monsters have been killed|z=50000;a1|rg=1|1=Displays the phase of the moon|z=50000;da1|d=30|D=2|k=9|rg=1|1=Allows the player to dash into the enemy|2=Double tap a direction|z=100000;d1|r=8|d=120|t=15|k=8|tx=30|rg=1|1=Sparks emit from struck enemies|z=500000;a1|rg=1|1=Displays how fast the player is moving|z=50000;t|s=9999|rg=100;w|s=9999|rg=400;a1|rg=1|1=Displays the most valuable ore around you|z=50000;rb1|r=2|d=5|k=2|rg=1|z=50000;rb1|r=2|d=7|k=2|rg=1|z=50000;m1|r=8|d=52|t=45|k=4|m=30|rg=1|z=500000;d1|r=8|d=85|t=8|k=3.5|rg=1|1=Allows you to go into stealth mode|z=500000;r1|r=8|d=85|t=15|rg=1|z=500000;rb|s=9999|r=8|d=30|k=3|rg=99|z=100;41|r=2|D=4|rg=1|1=Improves vision|z=50000;a1|r=8|rg=1|1=Turns the holder into a werewolf at night and a merfolk when entering water|2=Minor increase to damage, melee speed, critical strike chance,|3=life regeneration, defense, mining speed, and minion knockback|z=700000;|s=9999|rg=5|1=Bouncy and sweet!|z=15;c|s=9999|t=15|rg=100|1=Works when wet|z=10;t|s=9999|rg=100|1=Very bouncy;t|s=9999|rg=100|z=80;c|s=9999|t=25|rg=99|1=A small explosion that will destroy most tiles|2=Very bouncy|z=400;rc|s=9999|d=65|t=40|k=8|rg=99|1=A small explosion that will not destroy tiles|2=Very bouncy|z=100;t|s=9999|rg=1|1=Makes surrounding creatures less hostile|z=500;a1|rg=1|1=Displays the name of rare creatures around you|z=50000;a1|rg=1|1=Displays your damage per second|z=50000;a1|rg=1|1=Displays fishing information|z=50000;a1|r=3|rg=1|1=Displays movement speed, damage per second, and valuable ore|z=150000;a1|r=3|rg=1|1=Displays number of monsters, kill count, and rare creatures|z=150000;a1|r=5|rg=1|1=Displays everything|z=250000;1|r=7|t=90|rg=1|1=Displays everything|2=Allows you to return home at will|z=400000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=200;1|r=4|t=18|rg=1|1=Used to catch critters|2=Can catch lava critters too!|z=250000;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=200;|s=9999|rg=1|z=100;41|D=5|rg=1|z=17500;51|D=6|rg=1|z=14000;61|D=5|rg=1|z=10500;|s=9999|r=2|rg=3|z=37500;c|s=9999|r=2|t=15|rg=5|z=10000;c|s=9999|t=15|rg=5|z=1250;c|s=9999|t=15|rg=5|z=2500;c|s=9999|r=2|t=15|rg=5|z=5000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Grubs up!|z=10000;c|s=9999|t=25|rg=99|1=A small explosion that will destroy most tiles|z=1000;rc|s=9999|d=17|t=13|k=3.5|rg=99|z=80;t|s=9999|rg=1|1=Increases armor penetration for melee weapons|z=100000;1|t=90|rg=1|1=Gaze in the mirror to return home|z=50000;a1|rg=1|1=The wearer can run super fast|z=50000;a1|rg=1|1=Allows the holder to double jump|z=50000;t|s=9999|rg=1|z=500;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;m1|r=5|d=40|t=29|k=4.4|m=9|rg=1|1=Shoots an explosive crystal charge|z=200000;r1|r=5|d=43|k=3|rg=1|1=Spits toxic bubbles|z=200000;d1|r=5|d=55|t=28|k=5.75|rg=1|1=Spits an Ichor stream on contact|z=200000;a1|rg=1|1=Increases armor penetration by 5|z=50000;1|r=3|t=28|rg=1|1=Summons a flying piggy bank to store your items|z=100000;t|s=9999|rg=100|z=200;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;t|s=9999|rg=25|z=100;a1|rg=1|1=Has a chance to create illusions and dodge an attack|2=Temporarily increase critical chance after dodge|3=May confuse nearby enemies after being struck|z=100000;a1|rg=1|1=Reduces damage taken by 17%|z=100000;a1|rg=1|1=Increases jump height|z=125000;4v1|r=9|rg=1|1=Great for impersonating devs!|2=Become the wind, ride the lightning.|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=Bejeweled and elegant for soaring through the thundering skies|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=The Valkyrie Satellite Barrier Platform is totally safe. Most of the time.|z=400000;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=2;t|s=9999|rg=100;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;w|s=9999|rg=400;t|s=9999|rg=1;t|s=9999|rg=1;a1|rg=1|1=Increases jump height|2=Allows the holder to double jump|z=150000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;a1|r=2|rg=1|1=Shoots crossbones at enemies while you are attacking|z=100000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;4v1|rg=1|z=30000;s1|r=8|d=40|t=36|k=2|m=10|rg=1|1=Summons a deadly sphere to fight for you|z=500000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height and negates fall damage|z=150000;a1|r=4|rg=1|1=Releases bees and douses the user in honey when damaged|2=Increases jump height and negates fall damage|z=150000;a1|r=4|rg=1|1=Allows the holder to double jump|2=Increases jump height and negates fall damage|z=150000;t|s=9999|rg=1|z=20000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;d1|r=4|c=15|d=55|t=20|k=20|rg=1|z=250000;c|s=9999|r=3|t=17|rg=1|z=300000;1|r=8|t=20|rg=1|1=Summons a rideable unicorn mount|z=250000;t|s=9999|r=7|rg=25|z=50000;d1|r=2|d=21|t=25|k=3.25|rg=1|z=50000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;41|D=4|rg=1|1=Increases summon damage by 8%|z=4500;51|D=6|rg=1|1=Increases your max number of minions by 1|z=4500;61|D=5|rg=1|1=Increases summon damage by 8%|z=4500;m1|r=4|d=40|t=20|k=2|m=15|rg=1|z=200000;t|s=9999|rg=1|1=Right Click to place item on item frame;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;d1|d=9|t=25|k=2.5|rg=1|z=500;d1|d=16|t=25|k=4.5|rg=1|z=50000;d1|d=17|t=25|k=4|rg=1|z=50000;d1|r=3|d=18|t=25|k=3.75|rg=1|z=65000;d1|r=3|d=27|t=25|k=4.3|rg=1|z=90000;d1|r=4|d=39|t=25|k=3.3|rg=1|z=200000;d1|r=5|d=54|t=25|k=3.8|rg=1|z=250000;d1|d=14|t=25|k=3.5|rg=1|z=25000;d1|r=7|d=60|t=25|k=3.1|rg=1|z=250000;d1|r=9|d=70|t=25|k=4.5|rg=1|1=Great for impersonating devs!|z=200000;d1|r=9|d=70|t=25|k=4.5|rg=1|1=Great for impersonating devs!|z=200000;d1|r=4|d=43|t=25|k=2.8|rg=1|z=200000;d1|r=4|d=41|t=25|k=4.5|rg=1|z=200000;d1|r=8|c=10|d=95|t=25|k=4.3|rg=1|z=550000;d1|r=8|d=115|t=25|k=3.5|rg=1|z=625000;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|rg=1|1=Increases yoyo range|z=1500;a1|r=2|rg=1|1=Throws a counterweight after hitting an enemy with a yoyo|z=50000;a1|r=2|rg=1|1=Throws a counterweight after hitting an enemy with a yoyo|z=50000;a1|r=2|rg=1|1=Throws a counterweight after hitting an enemy with a yoyo|z=50000;a1|r=2|rg=1|1=Throws a counterweight after hitting an enemy with a yoyo|z=50000;a1|r=2|rg=1|1=Throws a counterweight after hitting an enemy with a yoyo|z=50000;a1|r=2|rg=1|1=Throws a counterweight after hitting an enemy with a yoyo|z=50000;d1|r=3|d=39|t=25|k=3.25|rg=1|z=200000;d1|r=3|d=49|t=25|k=3.8|rg=1|z=200000;d1|r=3|d=28|t=25|k=3.85|rg=1|z=87500;c|s=9999|rg=3|1=Right Click to open;c|s=9999|rg=3|1=Right Click to open;c|s=9999|r=2|rg=3|1=Right Click to open;c|s=9999|r=2|rg=3|1=Right Click to open;c|s=9999|r=3|rg=3|1=Right Click to open;c|s=9999|r=3|rg=3|1=Right Click to open;c|s=9999|r=4|rg=3|1=Right Click to open;c|s=9999|r=5|rg=3|1=Right Click to open;c|s=9999|r=5|rg=3|1=Right Click to open;c|s=9999|r=5|rg=3|1=Right Click to open;c|s=9999|r=6|rg=3|1=Right Click to open;c|s=9999|r=7|rg=3|1=Right Click to open;c|s=9999|r=7|rg=3|1=Right Click to open;c|s=9999|r=8|1=Right Click to open;c|s=9999|r=8|rg=3|1=Right Click to open;a1|r=3|rg=1|1=Increases the strength of friendly bees|z=100000;a1|r=4|rg=1|1=Allows the use of two yoyos at once|z=500000;c|s=9999|r=4|t=30|rg=1|1=Permanently increases the number of accessory slots|z=100000;a1|r=8|rg=1|1=Summons spores over time that will damage enemies|z=200000;a1|r=8|rg=1|1=Greatly increases life regen when not moving|z=250000;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=200;w|s=9999|rg=400;d1|r=2|d=20|t=18|k=4.25|rg=1|z=25000;r1|r=2|c=7|d=12|t=24|k=1.25|rg=1|z=25000;d1|r=2|d=16|t=15|k=3.5|rg=1|z=25000;d1|r=2|d=14|t=12|k=5|rg=1|z=25000;1|r=6|rg=1|z=50000;|s=9999|r=5|rg=1|z=25000;|s=9999|r=5|rg=1|z=25000;|s=9999|r=5|rg=1|z=25000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t1|rg=1|1=Places living rich mahogany|z=12500;t1|rg=1|1=Places rich mahogany leaves|z=12500;5v1|rg=1|z=250000;6v1|rg=1|z=250000;t|s=9999|rg=1;t|s=9999|rg=1;a1|r=4|rg=1|1=Gives the user master yoyo skills|z=500000;1|r=8|t=20|rg=1|1=Attracts a legendary creature which flourishes in water & combat|z=250000;d1|r=9|d=25|t=25|k=4|rg=1|1=I didnt get this off of a Schmoo|z=250000;t|s=9999|r=3|rg=1|z=250000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;4v1|rg=1|z=37500;4v1|rg=1|z=37500;41|D=4|rg=1|1=4% increased ranged critical strike chance|z=15000;51|D=5|rg=1|1=5% increased ranged damage|z=25000;61|D=4|rg=1|1=4% increased ranged critical strike chance|z=20000;m1|d=21|t=28|k=4.75|m=7|rg=1|z=20000;rc|s=9999|d=20|t=25|k=5|rg=99|z=50;rc|s=9999|d=14|t=14|k=1.5|rg=99|z=50;t|s=9999|rg=100;41|r=10|D=10|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 22%|3=Increases your max number of sentries by 1|z=350000;51|r=10|D=16|rg=1|1=Increases your max number of minions by 2|2=Increases summon damage by 22%|3=Increases whip range by 15%|z=700000;61|r=10|D=12|rg=1|1=Increases your max number of minions by 2|2=Increases summon damage by 22%|3=Increases whip range by 15%|z=525000;1|r=8|t=20|k=2|rg=1|1=Creates a pair of portals that can be traveled through.|2=Use Left Click & Right Click to place portals.|3=Increases momentum and falling speed.|4=Speedy thing goes in, speedy thing comes out.|z=500000;t|s=9999|rg=3|1=Can be traded for rare dyes|z=10000;t|s=9999|rg=3|1=Can be traded for rare dyes|z=10000;t|s=9999|rg=3|1=Can be traded for rare dyes|z=10000;t|s=9999|rg=3|1=Can be traded for rare dyes|z=10000;d1|r=10|c=10|d=190|t=25|k=6.5|rg=1|z=500000;t|s=9999|rg=1|1=Nearby players get a bonus against: Goblin Summoner|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Salamander|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Giant Shelly|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crawdad|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Fritz|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Creature from the Deep|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dr. Man Fly|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mothron|z=1000;t|s=9999|1=Nearby players get a bonus against: NPCName.None|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: The Possessed|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Butcher|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Psycho|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Deadly Sphere|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Nailhead|z=1000;t|s=9999|1=Nearby players get a bonus against: NPCName.None|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Medusa|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hoplite|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Granite Elemental|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Granite Golem|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Zombie|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Drippler|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Tomb Crawler|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dune Splicer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Antlion Swarmer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Antlion Charger|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ghoul|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Lamia|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Desert Spirit|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Basilisk|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Sand Poacher|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Stargazer|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Milkyway Weaver|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Flow Invader|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Twinkle Popper|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Mini Star Cell|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Star Cell|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corite|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Sroller|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crawltipede|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Drakomire Rider|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Drakomire|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Selenian|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Predictor|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Brain Suckler|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Nebula Floater|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Evolution Beast|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Alien Larva|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Alien Queen|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Alien Hornet|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Vortexian|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Storm Diver|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pirate Captain|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pirate Deadeye|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pirate Corsair|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pirate Crossbower|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Martian Walker|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Red Devil|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Pink Jellyfish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Green Jellyfish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dark Mummy|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Light Mummy|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Angry Bones|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Ice Tortoise|z=1000;1;1;1;|s=9999|r=9|rg=25|1=Swirling energies emanate from this fragment|z=10000;|s=9999|r=9|rg=25|1=The power of a galaxy resides within this fragment|z=10000;|s=9999|r=9|rg=25|1=The fury of the universe lies within this fragment|z=10000;|s=9999|r=9|rg=25|1=Entrancing particles revolve around this fragment|z=10000;t|s=9999|r=10|rg=100|1=A pebble of the heavens|z=15000;t|s=9999|r=9|rg=100;d1|r=10|d=100|t=25|k=6|tx=27|tr=4|z=300000;d1|r=10|d=80|t=15|k=4|tx=27|tr=3|z=300000;d1|r=10|d=50|t=15|k=0.5|tp=225|tr=2|rg=1|z=350000;d1|r=10|d=110|t=30|k=7|th=100|tr=4|z=400000;d1|r=10|d=80|t=12|k=5.5|tp=225|tr=4|rg=1|z=350000;t|s=9999|r=10|rg=25|1=It vibrates with luminous celestial energy|z=60000;a1|r=10|rg=1|1=Allows flight and slow fall|z=400000;a1|r=10|rg=1|1=Allows flight and slow fall|2=Press Down to toggle hover|3=Press Up to deactivate hover|z=400000;a1|r=10|rg=1|1=Allows flight and slow fall|2=Press Down to toggle hover|3=Press Up to deactivate hover|z=400000;a1|r=10|rg=1|1=Allows flight and slow fall|z=400000;w|s=9999|r=9|rg=400;d1|r=10|d=105|t=20|k=2|rg=1|1=Strike with the fury of the sun|z=500000;s1|r=10|d=60|t=36|k=2|m=10|rg=1|1=Summons a stardust cell to fight for you|2=Cultivate the most beautiful cellular infection|z=500000;r1|r=10|d=50|t=20|k=2|rg=1|1=66% chance to not consume ammo|2=The catastrophic mixture of pew pew and boom boom.|z=500000;m1|r=10|d=70|t=30|k=5|m=30|rg=1|1=Conjure masses of astral energy to chase down your foes|z=500000;c|s=9999|r=3|d=20|t=15|k=3|rg=99|1=Spreads the Crimson to some blocks|z=100;4v1|rg=1|1=Wuv... twue wuv...|z=5000;5v1|rg=1|1=Mawwiage...|z=5000;r1|d=13|t=25|rg=1|z=10500;d1|d=10|t=27|k=5.5|th=59|rg=1|z=12000;d1|d=8|t=25|k=4.5|tx=12|rg=1|z=12000;d1|d=13|k=5|rg=1|z=10500;d1|d=16|t=17|k=6.5|rg=1|z=13500;d1|d=7|t=19|k=2|tp=59|rg=1|1=Can mine Meteorite|z=15000;r1|d=10|t=26|rg=1|z=5250;d1|d=9|t=28|k=5.5|th=50|rg=1|z=6000;d1|d=7|t=26|k=4.5|tx=11|rg=1|z=6000;d1|d=10|t=11|k=4|rg=1|z=5250;d1|d=14|t=19|k=6|rg=1|z=6750;d1|d=6|t=21|k=2|tp=50|rg=1|1=Can mine Meteorite|z=7500;r1|d=9|t=27|rg=1|z=2100;d1|d=8|t=29|k=5.5|th=43|rg=1|z=2400;d1|d=6|t=28|k=4.5|tx=10|rg=1|z=2400;d1|d=9|t=12|k=4|rg=1|z=2100;d1|d=13|t=20|k=5.5|rg=1|z=2700;d1|d=6|t=19|k=2|tp=43|rg=1|z=3000;r1|d=7|t=28|rg=1|z=525;d1|d=6|t=31|k=5.5|th=38|rg=1|z=600;d1|d=4|t=28|k=4.5|tx=8|rg=1|z=600;d1|d=7|t=12|k=4|rg=1|z=525;d1|d=10|t=20|k=5.5|rg=1|z=675;d1|d=5|t=21|k=2|tp=35|rg=1|z=750;r1|d=6|t=29|rg=1|z=350;d1|d=4|t=33|k=5.5|th=35|rg=1|z=400;d1|d=3|t=30|k=4.5|tx=7|rg=1|z=400;d1|d=5|t=13|k=4|rg=1|z=350;d1|d=9|t=21|k=5.5|rg=1|z=450;d1|d=4|t=23|k=2|tp=35|rg=1|z=500;r1|d=9|t=27|rg=1|z=3500;d1|d=9|t=29|k=5.5|th=45|rg=1|z=4000;d1|d=6|t=26|k=4.5|tx=10|rg=1|z=4000;d1|d=9|t=12|k=4|rg=1|z=3500;d1|d=14|t=20|k=6|rg=1|z=4500;d1|d=6|t=19|k=2|tp=45|rg=1|z=5000;r1|d=11|t=26|rg=1|z=7000;d1|d=9|t=28|k=5.5|th=55|rg=1|z=8000;d1|d=7|t=26|k=4.5|tx=11|rg=1|z=8000;d1|d=12|t=11|k=5|rg=1|z=7000;d1|d=15|t=18|k=6.5|rg=1|z=9000;d1|d=6|t=20|k=2|tp=55|rg=1|1=Can mine Meteorite|z=10000;d1|r=10|d=60|t=28|k=7|tx=30|th=100|tr=4|rg=1|z=250000;d1|r=10|d=60|t=28|k=7|tx=30|th=100|tr=4|rg=1|z=250000;d1|r=10|d=60|t=28|k=7|tx=30|th=100|tr=4|rg=1|z=250000;d1|r=10|d=60|t=28|k=7|tx=30|th=100|tr=4|rg=1|z=250000;|s=9999|r=4|rg=3|z=125000;|s=9999|r=4|rg=3|z=125000;|s=9999|r=4|rg=3|z=125000;|s=9999|r=4|rg=3|z=125000;|s=9999|r=4|rg=3|z=125000;s1|r=10|d=40|t=36|k=2|m=10|rg=1|1=Summons a stardust dragon to fight for you|2=Who needs a horde of minions when you have a giant dragon?|z=500000;c|s=9999|r=4|t=17|rg=5|1=Major improvements to all stats|2=Bacon? Bacon.|z=50000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=2|rg=3|z=37500;|s=9999|r=3|rg=3|z=75000;avt|s=9999|r=9|rg=1|1=Wield a small amount of power from the Vortex Tower|z=1000000;avt|s=9999|r=9|rg=1|1=Wield a small amount of power from the Nebula Tower|z=1000000;avt|s=9999|r=9|rg=1|1=Wield a small amount of power from the Stardust Tower|z=1000000;avt|s=9999|r=9|rg=1|1=Wield a small amount of power from the Solar Tower|z=1000000;r1|r=10|d=50|t=12|k=2|rg=1|1=66% chance to not consume ammo|z=500000;m1|r=10|d=100|k=0.25|m=12|rg=1|1=Fire a lifeform disintegration rainbow|z=500000;m1|r=10|d=130|t=12|k=3|m=12|rg=1|1=From Orions belt to the palm of your hand|z=500000;d1|r=10|d=150|t=16|k=5|rg=1|1=Rend your foes asunder with a spear of light!|z=500000;c|s=9999|r=7|hl=200|t=17|rg=30|z=15000;t|s=9999|rg=1|1=Guts... and Gory!|z=10000;r1|r=8|d=25|t=30|k=4|rg=1|z=800000;c|s=9999|t=40|rg=99|1=A large explosion that will destroy most tiles|2=This will prove to be a terrible idea|z=2000;rc|s=9999|r=2|d=30|t=20|k=6|rg=99|1=A small explosion that will not destroy tiles|z=250;t|s=9999|r=10|rg=1|1=Used to craft items from Lunar Fragments and Luminite|z=250000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;|s=9999|r=2|rg=3|z=37500;|s=9999|r=3|rg=3|z=75000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|rg=3|z=10000;|s=9999|r=2|rg=3|z=10000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;c|s=9999|t=15|rg=5|z=2500;c|s=9999|r=3|t=15|rg=3|z=500000;t|s=9999|rg=1;t|s=9999|r=3|rg=1|z=500000;rb|s=9999|r=9|d=20|k=3|rg=99|1=Line em up and knock em down...|z=10;rb|s=9999|r=9|d=15|k=3.5|rg=99|1=Shooting them down at the speed of sound!|z=10;sS1|r=10|d=100|t=30|k=7.5|m=10|rg=1|1=Summons a sentry|2=Summons a lunar portal to shoot lasers at your enemies|z=500000;m1|r=10|d=100|k=4.5|m=9|rg=1|1=Rains down lunar flares|z=500000;sS1|r=10|d=130|t=30|k=7.5|m=10|rg=1|1=Summons a sentry|2=Summons a radiant crystal that banishes your enemies|3=The colors, Duke, the colors!|z=500000;1|r=10|t=20|rg=1|1=You want the moon? Just grapple it and pull it down!|z=500000;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;1|r=10|t=20|rg=1|1=Calls upon a suspicious looking eye to provide light|2=I know what youre thinking....|z=500000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=Whatever this accessory does to you is not a bug!|z=400000;av1|r=9|rg=1|1=Great for impersonating devs!|2=If you see this you should probably run away...|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;w|s=9999|rg=400;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|2=Disorder came from order, fear came from courage, weakness came from strength|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=Know thy self, know thy enemy. A thousand battles, a thousand victories…|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|2=Wheels of justice grind slow but grind fine.|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=Let your plans be dark and impenetrable as night, and when you move, fall like a thunderbolt.|z=400000;t|s=9999|rg=1|1=Nearby players get a bonus against: Sand Slime|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Sea Snail|z=1000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|1=V. Costa Moura|z=30000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=9|rg=3|1=Great for impersonating devs!|z=150000;|s=9999|r=3|rg=3|z=75000;c|s=9999|r=10|t=45|rg=3|1=Summons the Impending Doom;t|s=9999|rg=5|1=Place this on logic gates to add checks|z=1000;t|s=9999|rg=5|1=Activates when all lamps are on, deactivates otherwise|z=20000;t|s=9999|rg=5|1=Judges logic gate lamps above it|2=Activates when any lamp is on, deactivates otherwise|z=20000;t|s=9999|rg=5|1=Activates when not all lamps are on, deactivates otherwise|z=20000;t|s=9999|rg=5|1=Judges logic gate lamps above it|2=Activates when no lamp is on, deactivates otherwise|z=20000;t|s=9999|rg=5|1=Judges logic gate lamps above it|2=Activates when only one lamp is on, deactivates otherwise|z=20000;t|s=9999|rg=5|1=Judges logic gate lamps above it|2=Activates when the total on lamps is not one, deactivates otherwise|3=Also often called NXOR|z=20000;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;1|r=2|rg=1|1=Allows ultimate control over wires!|2=Right Click while holding to edit wire settings|z=200000;1|t=15|tr=20|rg=1|1=Places yellow wire|z=20000;t|s=9999|rg=5|1=Activates once day starts;t|s=9999|rg=5|1=Activates once night starts;t|s=9999|rg=5|1=Activates whenever players are over it, deactivates otherwise;t|s=9999|rg=25|1=Separates wire paths|2=Its also hammerable!|z=200;t|s=9999|rg=1;t|s=9999|rg=5|1=Place this on logic gates to add checks|z=1000;a1|r=3|rg=1|1=Grants improved wire vision|z=10000;1|t=15|tr=20|rg=1|1=Activates Actuators|z=20000;t|s=9999|rg=100|z=100;t|s=9999|rg=200|z=100;1|r=10|t=20|rg=1|z=500000;a1|r=3|rg=1|1=Automatically places actuators on placed objects|z=100000;1|t=15|tr=20|rg=1|1=Right Click while holding to edit wire settings|z=120000;t|s=9999|rg=5|1=Activates when a player steps on or off it;4v1|rg=1|z=10000;1|t=20|rg=1|1=Susceptible to lava!|z=5000000;t|s=9999|r=2|rg=5|1=Lights up bulbs for each wire color|z=50000;t|s=9999|rg=5|1=Activates when a player steps on or off it;t|s=9999|rg=5|1=Activates when a player steps on or off it;t|s=9999|rg=5|1=Activates when a player steps on or off it;t|s=9999|rg=100|z=100;t|s=9999|rg=100|z=100;t|s=9999|rg=100|z=100;t|s=9999|rg=100|z=100;t|s=9999|rg=100|z=100;t|s=9999|rg=200|z=100;t|s=9999|rg=200|z=100;t|s=9999|rg=200|z=100;t|s=9999|rg=200|z=100;t|s=9999|rg=200|z=100;1|rg=1|1=For Capture the Gem. It drops when you die;t|s=9999|rg=1|1=Right Click to place or remove Large Rubies|z=500;t|s=9999|rg=1|1=Right Click to place or remove Large Sapphires|z=500;t|s=9999|rg=1|1=Right Click to place or remove Large Emeralds|z=500;t|s=9999|rg=1|1=Right Click to place or remove Large Topazes|z=500;t|s=9999|rg=1|1=Right Click to place or remove Large Amethysts|z=500;t|s=9999|rg=1|1=Right Click to place or remove Large Diamonds|z=500;t|s=9999|rg=1|1=Right Click to place or remove Large Ambers|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=5|1=Place this on logic gate lamps to randomize the activation|z=20000;t|s=9999|r=3|rg=1|z=100000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|z=500;t|s=9999|z=500;t|s=9999|rg=5|1=Activates when a projectile touches it|z=20000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;a1|r=3|rg=1|1=Fishing line will never break, decreases chance of bait consumption, increases fishing power by 10|z=150000;t|s=9999|rg=5|z=10000;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=25|1=Separates wire paths|2=Toggle lights with simultaneous crossed signals|z=200;t|s=9999|rg=5|1=Activates whenever occupied by water, deactivates otherwise;t|s=9999|rg=5|1=Activates whenever occupied by lava, deactivates otherwise;t|s=9999|rg=5|1=Activates whenever occupied by honey, deactivates otherwise;t|s=9999|rg=5|1=Activates whenever occupied by liquid, deactivates otherwise;av1|rg=1|z=20000;av1|rg=1|z=20000;4v1|rg=1|z=10000;4v1|rg=1|z=30000;5v1|rg=1|z=30000;6v1|rg=1|z=30000;t|s=9999|rg=100|1=Smells like bubblegum and happiness|z=100;t|s=9999|rg=100|1=Smells like lavender and enthusiasm|z=100;t|s=9999|rg=100|1=Smells like mint and glee|z=100;t|s=9999|tr=3|rg=100|1=Oddly durable enough to climb!|z=50;t|s=9999|tr=3|rg=100|1=Oddly durable enough to climb!|z=50;t|s=9999|tr=3|rg=100|1=Oddly durable enough to climb!|z=50;t|s=9999|rg=1|1=It never stops celebrating!|z=50000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|1=Beat the shindig out of it!|2=May contain a suprise!|z=10000;t|s=9999|r=3|rg=1|1=Balloons shall rain from the sky|z=200000;t|s=9999|rg=1|1=Tied down for everyones pleasure|z=2000;t|s=9999|rg=1|1=Wonder whats inside?|z=2000;t|s=9999|r=3|rg=3|1=Stuff your face. Stuff someone elses face. Whatever.|z=25000;w|s=9999|rg=400|1=Productivity up 200%;w|s=9999|rg=400|1=Falling sand you can safely watch;w|s=9999|rg=400|1=A lot cooler than a snow globe;t|s=9999|rg=100|1=Falling sand you can safely watch|z=5;t|s=9999|rg=100|1=A lot cooler than a snow globe;t|s=9999|rg=100|1=Prevents fall damage;4v1|r=9|rg=1|1=Become the Pedguin|2=Great for impersonating streamers!|z=15000;5v1|r=9|rg=1|1=Become the Pedguin|2=Great for impersonating streamers!|z=15000;6v1|r=9|rg=1|1=Become the Pedguin|2=Great for impersonating streamers!|z=15000;w|s=9999|rg=400|1=Smells like bubblegum and happiness;w|s=9999|rg=400|1=Smells like lavender and enthusiasm;w|s=9999|rg=400|1=Smells like mint and glee;4v1|r=9|rg=1|1=Enables your inner wingman|2=Great for impersonating streamers!|z=50000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;61|r=4|rg=1|1=Grants slow fall in exchange for your feet|z=50000;1|r=8|t=20|rg=1|1=Summons a rideable basilisk mount|z=250000;d1|r=2|d=16|t=18|k=4.5|rg=1|z=5000;4v1|r=3|rg=1|z=25000;5v1|r=3|rg=1|z=25000;6v1|r=3|rg=1|z=25000;41|r=5|D=6|rg=1|1=15% increased magic and summon damage|z=250000;51|r=5|D=12|rg=1|1=Increases maximum mana by 40|2=10% increased summon damage|3=Increases your max number of minions by 1|z=200000;61|r=5|D=8|rg=1|1=Increases maximum mana by 40|2=10% increased magic damage|3=Increases your max number of minions by 1|z=150000;m1|r=4|d=85|t=22|k=5|m=14|rg=1|z=50000;t|s=9999|rg=1|1=Nearby players get a bonus against: Sand Elemental|z=1000;a1|r=3|rg=1|1=Immunity to Petrification|z=100000;t|s=9999|rg=1|z=200;|s=9999|r=5|rg=3|z=50000;6v1|r=3|rg=1|z=25000;5v1|r=3|rg=1|z=25000;4v1|r=3|rg=1|z=25000;m1|r=4|c=20|d=38|t=12|k=6|m=17|rg=1|z=300000;r1|r=4|d=24|t=48|k=6.5|rg=1|z=250000;t|s=9999|rg=1|1=Nearby players get a bonus against: Sand Shark|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Bone Biter|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Flesh Reaver|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crystal Thresher|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Angry Tumbler|z=1000;|s=9999|rg=5|z=500;t|s=9999|r=3|rg=1|z=25000;at1|r=4|rg=1|z=100000;41|r=8|D=7|rg=1|1=Increases your max number of sentries by 1, 10% increased magic damage and reduces mana costs by 10%|z=150000;51|r=8|D=15|rg=1|1=20% increased summon damage and 10% increased magic damage|z=150000;61|r=8|D=10|rg=1|1=10% increased summon damage, 20% increased magic critical strike chance and movement speed|z=150000;41|r=8|D=13|rg=1|1=Increases your max number of sentries by 1 and increases your life regeneration|z=150000;51|r=8|D=27|rg=1|1=15% increased summon and melee damage|z=150000;61|r=8|D=18|rg=1|1=15% increased summon damage, 15% increased melee critical strike chance and movement speed|z=150000;41|r=8|D=7|rg=1|1=Increases your max number of sentries by 1 and increases ranged critical strike chance by 10%|z=150000;51|r=8|D=17|rg=1|1=20% increased summon and ranged damage and 10% chance to not consume ammo|z=150000;61|r=8|D=12|rg=1|1=10% increased summon damage and 20% increased movement speed|z=150000;41|r=8|D=8|rg=1|1=Increases your max number of sentries by 1 and increases melee speed by 20%|z=150000;51|r=8|D=22|rg=1|1=20% increased summon and melee damage|z=150000;61|r=8|D=16|rg=1|1=10% increased summon damage,|2=15% increased melee critical strike chance and 20% increased movement speed|z=150000;a1|r=5|rg=1|1=Increase your max number of sentries by 1|2=Increases summon damage by 10%|z=150000;a1|r=5|rg=1|1=Increase your max number of sentries by 1|2=Increases summon damage by 10%|z=150000;a1|r=5|rg=1|1=Increase your max number of sentries by 1|2=Increases summon damage by 10%|z=150000;a1|r=5|rg=1|1=Increase your max number of sentries by 1|2=Increases summon damage by 10%|z=150000;t|s=9999|r=3|rg=1|1=Can be used to store your items|2=Stored items can only be accessed by you|z=100000;t|s=9999|rg=1|1=Right Click to have more sentries|z=100000;t|s=9999|rg=1|z=100000;t|s=9999|r=3|rg=1|1=Holds the Eternia Crystal|2=Interact while carrying an Eternia Crystal to summon Etherias portals|3=Interact with the crystal to skip extra time between waves|z=10000;|s=9999|r=3|rg=50|1=Currency for trading with the Tavernkeep;sS1|r=3|d=17|t=30|k=3|m=5|rg=1|1=Summons a sentry|2=An average speed tower that shoots exploding fireballs|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=50000;sS1|r=5|d=42|t=30|k=3|m=10|rg=1|1=Summons a sentry|2=An average speed tower that shoots exploding fireballs|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=250000;sS1|r=8|d=88|t=30|k=3|m=15|rg=1|1=Summons a sentry|2=An average speed tower that shoots exploding fireballs|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=750000;r1|d=20|t=40|k=7|rg=1|z=500;|s=9999|1=Often used to manifest ones will as a physical form of defense;d1|r=5|d=95|t=20|k=6.5|rg=1|1=Right Click to guard with a shield|z=50000;sS1|r=3|d=30|t=30|k=4.7|m=5|rg=1|1=Summons a sentry|2=A slow but high damage tower that shoots piercing bolts|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=50000;sS1|r=5|d=74|t=30|k=4.7|m=10|rg=1|1=Summons a sentry|2=A slow but high damage tower that shoots piercing bolts|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=250000;sS1|r=8|d=156|t=30|k=4.7|m=15|rg=1|1=Summons a sentry|2=A slow but high damage tower that shoots piercing bolts|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=750000;d1|r=8|d=180|t=20|k=5.5|rg=1|1=Unleashes the hearts energy forward|z=250000;c|s=9999|r=3|rg=3|1=Place in the Eternia Crystal Stand to summon Etherias portals|z=2500;sS1|r=3|d=4|t=30|k=0.25|m=5|rg=1|1=Summons a sentry|2=An aura that repeatedly zaps enemies that go inside|3=Aura damage penetrates enemy defense|4=Hits quickly at the expense of 50% tag damage|5=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=50000;sS1|r=5|d=11|t=30|k=0.25|m=10|rg=1|1=Summons a sentry|2=An aura that repeatedly zaps enemies that go inside|3=Aura damage penetrates enemy defense|4=Hits quickly at the expense of 50% tag damage|5=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=250000;sS1|r=8|d=34|t=30|k=0.25|m=15|rg=1|1=Summons a sentry|2=An aura that repeatedly zaps enemies that go inside|3=Aura damage penetrates enemy defense|4=Hits quickly at the expense of 50% tag damage|5=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=750000;sS1|r=3|d=24|t=30|k=0.5|m=5|rg=1|1=Summons a sentry|2=A trap that explodes when enemies come near|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=50000;sS1|r=5|d=59|t=30|k=0.5|m=10|rg=1|1=Summons a sentry|2=A trap that explodes when enemies come near|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=250000;sS1|r=8|d=126|t=30|k=0.5|m=15|rg=1|1=Summons a sentry|2=A trap that explodes when enemies come near|3=Costs 10 Etherian Mana per use while defending an Eternia Crystal|z=750000;d1|r=5|d=50|t=30|k=7|rg=1|1=Charges power as it is swung to smash enemies|z=50000;d1|r=5|d=45|t=27|k=7|rg=1|1=Summons ghosts as it hits enemies|z=50000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Etherian Goblin Bomber|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Etherian Goblin|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Old Ones Skeleton|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Drakin|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Kobold Glider|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Kobold|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Wither Beast|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Etherian Wyvern|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Etherian Javelin Thrower|z=1000;t|s=9999|rg=1|1=Nearby players get a small bonus against: Etherian Lightning Bug|z=1000;1;1;1;1;1;m1|r=5|d=36|t=25|k=9|m=20|rg=1|1=Gotta wonder who stuck a tome of infinite wisdom on a stick...|2=Right Click to cast a powerful tornado|z=50000;1;r1|r=5|d=32|t=18|k=2|rg=1|1=Harnesses the power of undying flames|z=50000;1|r=3|t=20|rg=1|1=Summons a pet gato|z=100000;1|r=3|t=20|rg=1|1=Summons a pet flickerwick to provide light|z=100000;1|r=3|t=20|rg=1|1=Summons a pet dragon|z=100000;d1|r=8|d=140|t=30|k=5|rg=1|1=Right Click while holding for an alternate attack!|z=250000;r1|r=8|c=3|d=39|t=30|k=4.5|rg=1|1=Shoots splitting arrows, deals more damage to airborne enemies|z=250000;c|s=9999|r=8|rg=3|1=Right Click to open;c|s=9999|r=5|1=Right Click to open;c|s=9999|r=3|1=Right Click to open;4v1|rg=1|z=37500;4v1|rg=1|z=37500;4v1|rg=1|z=37500;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;at1|r=4|rg=1|z=100000;m1|r=8|d=100|t=20|k=7|m=14|rg=1|1=Splashes defense reducing miasma!|z=250000;41|r=8|D=20|rg=1|1=Increases your max number of sentries by 2 and increases summon and melee damage by 10%|z=150000;51|r=8|D=24|rg=1|1=30% increased summon damage and massively increased life regeneration|z=150000;61|r=8|D=24|rg=1|1=20% increased summon damage and melee critical strike chance and movement speed|z=150000;41|r=8|D=7|rg=1|1=Increases your max number of sentries by 2|2=15% increased summon & magic damage|z=150000;51|r=8|D=21|rg=1|1=25% increased summon damage and 10% increased magic damage|2=Reduces mana costs by 15%|z=150000;61|r=8|D=14|rg=1|1=20% increased summon damage and 25% increased magic critical strike chance|2=20% increased movement speed|z=150000;41|r=8|D=8|rg=1|1=Increases your max number of sentries by 2|2=10% increased summon damage and ranged critical strike chance|z=150000;51|r=8|D=24|rg=1|1=25% increased summon & ranged damage and 20% chance to not consume ammo|z=150000;61|r=8|D=16|rg=1|1=25% increased summon damage and 10% increased ranged critical strike chance|2=20% increased movement speed|z=150000;41|r=8|D=10|rg=1|1=Increases your max number of sentries by 2 and increases 20% melee & summon damage|z=150000;51|r=8|D=26|rg=1|1=20% increased summon damage and melee speed|2=5% increased melee critical strike chance|z=150000;61|r=8|D=18|rg=1|1=20% increased summon damage and melee critical strike chance|2=30% increased movement speed|z=150000;a1|r=8|rg=1|1=Allows flight and slow fall|2=Press Down to toggle hover|3=Press Up to deactivate hover|z=400000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=200;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=100000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;4v1|r=9|rg=1|1=Great for impersonating devs!|2=I didnt get this from the Grid|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=I didnt get this from the Grid|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|2=I didnt get this from the Grid|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=I didnt get this from the Grid|3=Allows flight and slow fall|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|2=To keep those luscious locks as gorgeous as ever|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=Bringing sexy back|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|2=There might be pasta in the pockets|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=Its full on! What does it mean?!|z=400000;av1|r=9|rg=1|1=Great for impersonating devs!|2=Brought to you by LeinCorp|z=250000;r1|r=10|d=50|t=6|k=10|rg=1|1=50% chance to not consume ammo|2=All good things end with a bang... or many!|z=500000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|1=Spider-sink, Spider-sink, does whatever a spider can...|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|1=Right Click when placed to display hats and helmets;|s=9999|r=3|z=75000;t|s=9999|rg=10|1=Right Click to open|z=5000;t|s=9999|r=2|rg=10|1=Right Click to open|z=25000;t|s=9999|r=3|rg=10|1=Right Click to open|z=100000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|rg=1|1=Activates when opened|z=500;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=5|rg=1|1=The wearer can run super fast|2=Increases jump speed and allows auto-jump|3=Increases fall resistance|z=100000;a1|r=5|rg=1|1=8% reduced mana usage|2=Automatically use mana potions when needed|3=Enemies are less likely to target you|z=500000;a1|r=5|D=8|rg=1|1=Increases melee knockback|2=12% increased melee speed|3=Enables auto swing for melee weapons|4=Increases the size of melee weapons|5=Enemies are more likely to target you|z=500000;a1|r=5|rg=1|1=Allows flight|2=The wearer can run super fast|3=Flowers grow on the grass you walk on|z=500000;a1|r=5|rg=1|1=Grants the ability to swim|2=Increases jump speed and allows auto-jump|3=Increases fall resistance|z=100000;a1|r=5|rg=1|1=Grants the ability to swim|2=Allows the ability to climb walls|3=Increases jump speed and allows auto-jump|4=Increases fall resistance|5=It aint easy being green|z=250000;a1|r=5|rg=1|1=Allows the ability to climb walls|2=Increases jump speed and allows auto-jump|3=Increases fall resistance|z=100000;a1|r=5|D=6|rg=1|1=Grants immunity to knockback|2=Puts a shell around the owner when below 50% life that reduces damage by 25%|3=Absorbs 25% of damage done to players on your team when above 25% life|z=400000;a1|r=5|D=10|rg=1|1=Grants immunity to knockback|2=Absorbs 25% of damage done to players on your team when above 25% life|3=Enemies are more likely to target you|z=500000;a1|r=5|rg=1|1=Provides 7 seconds of immunity to lava|2=Grants immunity to fire blocks|z=125000;a1|r=5|rg=1|1=8% reduced mana usage|2=Automatically use mana potions when needed|3=Increases pickup range for mana stars|z=200000;a1|r=5|rg=1|1=8% reduced mana usage|2=Automatically use mana potions when needed|3=Causes stars to fall after taking damage|4=Stars restore mana when collected|z=150000;a1|r=5|rg=1|1=Increases arrow damage by 10% and greatly increases arrow speed|2=20% chance not to consume arrows|3=Lights wooden arrows ablaze|4=Quiver in fear!|z=375000;a1|r=6|rg=1|1=Provides 7 seconds of immunity to lava|2=Grants immunity to fire blocks|3=Reduces damage from touching lava|z=250000;a1|r=5|rg=1|1=Grants immunity to fire blocks|2=Reduces damage from touching lava|z=150000;a1|r=5|rg=1|1=Increases view range for guns (Right Click to zoom out)|2=10% increased ranged damage and critical strike chance|3=Enemies are less likely to target you|4=Enemy spotted|z=500000;a1|r=5|rg=1|1=Increases arrow damage by 10% and greatly increases arrow speed|2=20% chance not to consume arrows|3=Enemies are less likely to target you|z=500000;a1|r=5|rg=1|1=Increases armor penetration by 5|2=Releases bees and douses the user in honey when damaged|z=150000;41|r=5|D=4|rg=1|1=Improves vision and provides light when worn|2=The darkness holds no secrets for you|z=100000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=An apple a day keeps Doctor Bones away!|z=10000;1|1=Medium improvements to all stats|2=Mmmm... pie.;c|s=9999|r=4|t=17|rg=5|1=Major improvements to all stats|2=Nothing is as Terrarian as apple pie.|z=30000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Make like a banana and split!|z=10000;c|s=9999|r=4|t=17|rg=5|1=Major improvements to all stats|2=Grilled to perfection!|z=50000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=This ones luck has run out.|z=10000;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=...but wait! It was 99 cents.|z=20000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Caution: may contain harpy.|z=20000;c|s=9999|r=3|t=17|rg=5|1=Medium improvements to all stats|2=Fresh from the oven|z=30000;c|s=9999|r=3|t=17|rg=5|1=Medium improvements to all stats|2=Its so fizzy!|z=20000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Look at that S Car Go!|z=10000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Sunny side up!|z=20000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Wheres the Ketchup!?|z=10000;c|s=9999|r=6|t=17|rg=5|1=Major improvements to all stats|2=(Au)some!|z=500000;c|s=9999|r=3|t=17|rg=5|1=Medium improvements to all stats|2=Wrath not included.|z=20000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Thatll keep you out of my birdfeeders...|z=10000;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=Hot diggity!|z=30000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Eat it before it melts!|z=20000;c|s=9999|r=4|t=17|rg=5|1=Major improvements to all stats|2=It brings the boys to the yard!|z=30000;c|s=9999|r=3|t=17|rg=5|1=Medium improvements to all stats|2=Its nach-yos, its mine!|z=20000;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=With pepperoni and extra cheese.|z=20000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|2=Betcha cant eat just one!|z=15000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Serving Size: 1 child.|z=10000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Better than chicken from a wall.|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=The other, other white meat.|z=5000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=I sea food, I eat it.|z=5000;c|s=9999|r=3|t=17|rg=5|1=Medium improvements to all stats|2=Po Boy are you in for a treat!|z=25000;c|s=9999|r=3|t=17|rg=5|1=Major improvements to all stats|2=Al dente!|z=20000;c|s=9999|r=4|t=17|rg=5|1=Major improvements to all stats|2=Well done with ketchup!|z=30000;a1|r=5|rg=1|1=Grants immunity to fire blocks|2=Provides 7 seconds of immunity to lava|z=375000;1|r=2|t=12|rg=1|1=A well-rounded club best for mid-range distances|2=Golf balls will carry a good distance with decent vertical loft|z=10000;t|s=9999|r=2|rg=1|1=Aim to sink your golf ball in the cup|2=Lets everyone know how well you did|z=10000;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;t|s=9999|rg=25|z=500;1|t=30|rg=1|1=Mows Pure and Hallowed grass|2=Mowed grass reduces enemy spawn chance|z=10000;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;avt|s=9999|r=3|rg=1|1=Sustain a bloody fraction of the Moon|z=50000;a1|rg=1|1=The wearer can run super fast, and even faster on sand|2=Walk without rhythm and you wont attract the worm|z=50000;a1|rg=1|1=Increases mining speed by 25%|2=Ancient problems require ancient solutions|z=50000;1|r=3|t=12|rg=1|1=Playable Instrument|2=These licks are spicy|z=10000;r1|r=3|d=8|t=17|k=5|z=100000;d1|d=8|t=18|k=4|tp=55|rg=1|z=15000;r1|r=3|d=60|t=18|k=5|rg=1|1=Sure, Brain, but where are you going to get enough stars for this?|z=500000;d1|d=14|t=28|k=6|rg=1|z=15000;m1|d=20|t=17|k=3|m=7|rg=1|z=15000;t|s=9999|rg=1|1=Badum, psh|z=100000;t|s=9999|rg=1|z=400;t|s=9999|rg=1|z=500;1|rg=1|z=25000;1|rg=1|1=Allows quick travel in water|2=Deal with it|z=50000;c|s=9999|t=15|rg=3|1=Hey! Listen!|z=50000;c|s=9999|t=15|rg=3|1=Hey! Listen!|z=50000;c|s=9999|t=15|rg=3|1=Hey! Listen!|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=10000;t|s=9999|rg=1|z=10000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=5000;t|s=9999|r=3|rg=1|1=Can be used to store your items|2=Stored items can only be accessed by you|3=Will contain items picked up by a void bag|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=2000;t|s=9999|r=2|rg=1|1=Right Click to place a golf ball on it|z=10000;t|s=9999|rg=100|z=500;t|s=9999|rg=100|1=Portals cannot be created on the surface of these blocks|z=100;1|r=2|t=12|rg=1|1=A specialized club for finishing holes|2=Golf balls will stay close to the ground over short distances for precision shots|z=10000;1|r=2|t=12|rg=1|1=A specialized club for sand pits or tall obstacles|2=Golf balls will gain tons of vertical loft but will not carry very far|z=10000;1|r=2|t=12|rg=1|1=A powerful club for long distances|2=Golf balls will carry very far, with little vertical loft|z=10000;1|r=4|rg=1|1=Returns your last hit Golf Ball to its previous position|2=Has a one stroke penalty|z=100000;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|1=How desperate are you?|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=100000;4v1|r=3|rg=1|z=25000;5v1|r=3|rg=1|z=25000;6v1|r=3|rg=1|z=25000;1|r=3|t=28|rg=1|1=Summons the void vault|2=Functions as an extended inventory when open|3=May pick up overflowing items when open|4=Right Click to close|5=This pocket dimension is out of this world!|z=100000;4v1|r=3|rg=1|z=25000;5v1|r=3|rg=1|z=25000;6v1|r=3|rg=1|z=25000;4v1|r=3|rg=1|z=25000;5v1|r=3|rg=1|z=25000;6v1|r=3|rg=1|z=25000;4v1|r=3|rg=1|z=25000;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=1|z=150;t|s=9999|rg=1|1=Used for special crafting|z=100000;1;d1|r=2|d=17|t=25|k=3|rg=1|1=Unleashes a dicing flurry|z=250000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;at1|r=4|rg=1|1=Brought to you by Xenon and DJ Sniper|z=100000;t|s=9999|rg=100|1=May break when stepped on;t|s=9999|rg=100|1=May break when stepped on;t|s=9999|rg=100|1=May break when stepped on;t|s=9999|rg=25|z=500;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;a1|r=2|rg=1|1=Can be hit with a golf club|z=10000;51|r=2|D=3|rg=1|1=Increases maximum mana by 60|2=Reduces mana usage by 13%|z=150000;1|t=20|k=7|rg=1|z=20000;d1|d=26|t=18|k=3|rg=1|z=27000;d1|r=4|d=48|t=16|k=3|rg=1|z=50000;w|s=9999|rg=400|z=800;t|s=9999|rg=5|1=Activates and breaks when a player steps on it|z=5000;1|t=90|rg=1|1=Summons rope snakes|z=50000;1|t=90|rg=1|1=If you listen closely, you can hear the ocean|z=50000;1|r=8|t=20|rg=1|1=Summons a rideable Golf Cart mount|z=500000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=500;s1|r=4|d=35|t=36|k=3|m=10|rg=1|1=Summons a sanguine bat to fight for you|z=250000;m1|r=4|d=34|t=33|k=1|m=20|rg=1|1=Summons blood thorns from the ground|z=200000;c|s=9999|r=2|t=45|rg=3|1=Summons the Blood Moon|2=What a horrible night to have a curse.;d1|r=4|d=55|t=40|k=6.5|rg=1|z=200000;s1|r=3|d=11|t=36|k=5|m=10|rg=1|1=Summons a vampire frog to fight for you|z=50000;c|s=9999|r=3|t=15|rg=3|1=Not to be confused with the elusive Gold Gold Goldfish|z=500000;4vt|s=9999|r=3|rg=1|1=Is it a gold bowl? Or a gold fish?|z=500000;t|s=9999|rg=1|1=Increases defense by 5 when placed nearby|z=100000;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;s1|d=7|t=36|k=4|m=10|rg=1|1=Summons a baby finch to fight for you|z=50000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Youll apricate this!|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Good source of potassium!|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=A vegan option for vampires|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Are you suggesting that coconuts can migrate?|z=10000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Smells like your father|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=When life gives you lemons...|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Goes great with pizza|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|z=10000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=150;d1|r=4|d=30|t=27|k=7|tx=30|th=80|rg=1|z=100000;avt|s=9999|r=9|rg=1|1=Harness a small amount of power from the Void|z=1250000;t|s=9999|rg=1|1=Right Click to change directions|z=2000;t|s=9999|rg=1|1=Right Click to change directions|z=2000;5v1|r=3|rg=1|1=I thought I told you to clean up your room!|z=50000;6v1|r=3|rg=1|1=I thought I told you to clean up your room!|z=50000;4v1|r=3|rg=1|z=500000;5v1|r=3|rg=1|z=500000;1|r=2|t=8|tf=25|rg=1|1=Increased chance to fish up enemies during a Blood Moon|z=100000;t|s=9999|rg=1|1=Right Click to place item on plate|z=150;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|r=3|rg=1|z=500000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|r=3|t=15|rg=3|z=500000;a1|rg=1|1=Hold Up to reach higher|z=25000;t|s=9999|rg=1|z=300;rc|s=9999|d=4|t=17|k=2|rg=1|z=5000;rc|s=9999|d=4|t=17|k=2|rg=1|z=5000;|s=9999|rg=2|1=Right Click to open|z=2500;1|rg=1|1=Prevents item pickups while locked|2=Right Click to unlock|3=You are over-encumbered|z=50000;m1|r=2|d=42|t=36|k=6|m=16|rg=1|1=It might be broken|z=170000;m1|r=5|d=100|t=36|k=6|m=16|rg=1|1=It might be broken|z=500000;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25;t|s=9999|rg=25|1=A sight to dwell upon and never forget;t|s=9999|rg=1|z=300;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;c|s=9999|t=15|rg=5|z=3750;t|s=9999|rg=1|z=300;c|s=9999|t=15|rg=5|z=5000;c|s=9999|r=3|t=15|rg=3|z=500000;c|s=9999|t=15|rg=5|z=2500;t|s=9999|rg=1;1|r=5|t=20|rg=1|1=Summons Estee|z=1000000;1|r=3|t=20|rg=1|1=Summons a Pet Sugar Glider|z=100000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|r=3|t=12|rg=1|1=Playable Instrument|2=Property of Dead Mans Sweater|z=10000;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=5000;t|s=9999|rg=1;t|s=9999|rg=25|1=A sight to dwell upon and never forget;t|s=9999|rg=25|1=A sight to dwell upon and never forget;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;t|s=9999|rg=1;r1|r=3|d=14|t=19|k=3|rg=1|1=Rains blood from the sky|2=Reign in Blood|z=50000;c|s=9999|r=2|t=45|rg=1|1=Increases the defense and strength of all villagers|2=Contains offensive and defensive fighting techniques;t|s=9999|rg=100|z=60;t|s=9999|rg=100|1=Can be placed in water|z=60;t|s=9999|rg=100|z=60;t|s=9999|rg=100|z=60;t|s=9999|rg=100|z=60;t|s=9999|rg=100|z=60;t|s=9999|rg=25|1=A sight to dwell upon and never forget;t|s=9999|rg=5|1=They hatin...;t|s=9999|rg=100|1=Breaks when fallen on|2=Watch your step;t|s=9999|rg=100|1=Only visible with Echo Sight|z=1000;1|rg=2|1=Caught in Desert;1|rg=2|1=Caught in Desert;c|s=9999|t=15|rg=5|z=5000;t|s=9999|rg=1;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=10000;t|s=9999|r=3|rg=1|z=500000;c|s=9999|r=2|t=15|rg=5|1=May drop valuable shinies when smashed!|z=2500;|s=9999|rg=3|z=750;|s=9999|rg=3|1=But it wasnt a rock!|z=5000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Delicious with a bit of butter|z=10000;a1|rg=1|1=Grants the ability to float in water|z=10000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;a1|r=5|rg=1|1=Enables Echo Sight, showing hidden blocks|z=100000;|s=9999|rg=5|1=Right Click to open|z=500;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Aw, shucks!|z=10000;|s=9999|rg=5|z=50000;|s=9999|rg=5|z=150000;|s=9999|rg=5|z=750000;t|s=9999|rg=1|z=200;t|s=9999|rg=200;t|s=9999|rg=1|z=40000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|r=3|t=15|rg=3|z=500000;t|s=9999|rg=1|z=50000;at1|r=4|rg=1|z=100000;t|s=9999|rg=100|1=Allows only liquids through|2=Can be toggled open or closed|3=Theyrrrre great!;c|s=9999|t=25|rg=99|1=A narrow explosion that will destroy most tiles|2=Explosion aims away from your position|z=1500;w|s=9999|rg=400;1|r=5|t=20|rg=1|1=Summons a Shark Pup|2=Doo, doo, doo, doo, doo, doo|z=50000;1|rg=1|z=50000;1|rg=1|z=25000;1|rg=1|1=Powered by Bacon!|z=50000;1|rg=1|z=25000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;t|s=9999|rg=1|z=30000;1|t=8|tf=30|rg=1|z=100000;1|rg=1|1=Provides 7 seconds of immunity to lava|z=50000;1|r=8|t=20|rg=1|1=Grants a witching spark of inspiration!|z=250000;rb|s=9999|d=50|k=4|rg=99|1=Will not destroy tiles|z=750;rb|s=9999|d=50|k=4|rg=99|1=Will destroy tiles|z=1500;rb|s=9999|d=40|k=4|rg=99|1=Spreads water on impact|z=5000;rb|s=9999|d=40|k=4|rg=99|1=Spreads lava on impact|z=5000;rb|s=9999|d=40|k=4|rg=99|1=Spreads honey on impact|z=5000;1|rg=1|1=The shroom goes vroom|z=50000;1|rg=1|z=50000;1|rg=1|z=50000;1|rg=1|z=50000;1|rg=1|z=50000;1|rg=1|z=50000;1|rg=1|z=50000;rb|s=9999|d=75|k=4|rg=99|1=Huge blast radius. Will not destroy tiles|z=500;rb|s=9999|d=75|k=4|rg=99|1=Huge blast radius. Will destroy tiles|z=1000;rb|s=9999|d=40|k=4|rg=99|1=Absorbs liquid on impact|z=5000;t1|rg=1|1=Places sandcastles|z=50000;t|s=9999|rg=1;t|s=9999|rg=1;d1|d=15|t=21|k=3|rg=1|1=Are you not entertained?!|z=15000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;t|s=9999|rg=1|z=300;1|rg=1|z=50000;1|rg=1|z=200000;1|r=10|rg=1|1=brrrrrow|z=500000;1|rg=1|1=All aboard the party wagon!|z=100000;1|rg=1|z=50000;1|rg=1|1=Steam powered!|z=100000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|r=3|rg=1|z=500000;c|s=9999|t=17|rg=20|1=Increases the Luck of the user|z=50000;c|s=9999|t=17|rg=20|1=Increases the Luck of the user|z=250000;c|s=9999|t=17|rg=20|1=Increases the Luck of the user|z=1250000;c|s=9999|t=15|rg=5|z=7500;t|s=9999|rg=1;c|s=9999|r=3|t=15|rg=3|z=500000;t|s=9999|r=3|rg=1|z=500000;t|s=9999|rg=1|1=Activates every half of a second|z=20000;t|s=9999|rg=1|1=Activates every fourth of a second|z=20000;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400|z=250;w|s=9999|rg=400|z=250;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400|z=250;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=1|1=Nearby players get a bonus against: The Bride|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Zombie Merman|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Wandering Eye Fish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Squid|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Eel|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hemogoblin Shark|z=1000;t|s=9999|rg=100|z=100;w|s=9999|rg=400;4v1|r=3|rg=1|z=25000;1|r=3|t=20|rg=1|1=Summons a baby red panda|z=1000000;1|r=3|t=20|rg=1|1=Summons a baby imp|2=He hasnt learned how to teleport yet!|z=100000;t|s=9999|rg=1|1=Billows out fog|z=40000;t|s=9999|rg=1|z=20000;t|s=9999|rg=50;4v1|rg=1|1=This chicken is raw!|z=25000;5v1|rg=1|z=25000;6v1|rg=1|z=25000;4v1|r=3|rg=1|z=20000;4v1|r=3|rg=1|z=20000;4v1|rg=1|z=30000;4v1|r=3|rg=1|z=25000;4v1|r=3|rg=1|1=*tips* Mlady|z=25000;av1|r=3|rg=1|1=Its a new day, yes it is!|z=25000;t|s=9999|rg=100|z=100;w|s=9999|rg=400;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;1|t=12|rg=1|1=A well-rounded club best for mid-range distances|2=Golf balls will carry a good distance with decent vertical loft|z=1000;1|t=12|rg=1|1=A specialized club for finishing holes|2=Golf balls will stay close to the ground over short distances for precision shots|z=1000;1|t=12|rg=1|1=A specialized club for sand pits or tall obstacles|2=Golf balls will gain tons of vertical loft but will not carry very far|z=1000;1|t=12|rg=1|1=A powerful club for long distances|2=Golf balls will carry very far, with little vertical loft|z=1000;1|r=3|t=12|rg=1|1=A well-rounded club best for mid-range distances|2=Golf balls will carry a good distance with decent vertical loft|z=100000;1|r=3|t=12|rg=1|1=A specialized club for finishing holes|2=Golf balls will stay close to the ground over short distances for precision shots|z=100000;1|r=3|t=12|rg=1|1=A specialized club for sand pits or tall obstacles|2=Golf balls will gain tons of vertical loft but will not carry very far|z=100000;1|r=3|t=12|rg=1|1=A powerful club for long distances|2=Golf balls will carry very far, with little vertical loft|z=100000;1|r=4|t=12|rg=1|1=A well-rounded club best for mid-range distances|2=Golf balls will carry a good distance with decent vertical loft|z=250000;1|r=4|t=12|rg=1|1=A specialized club for finishing holes|2=Golf balls will stay close to the ground over short distances for precision shots|z=250000;1|r=4|t=12|rg=1|1=A specialized club for sand pits or tall obstacles|2=Golf balls will gain tons of vertical loft but will not carry very far|z=250000;1|r=4|t=12|rg=1|1=A powerful club for long distances|2=Golf balls will carry very far, with little vertical loft|z=250000;t|s=9999|r=3|rg=1|z=10000;t|s=9999|r=3|rg=1|z=10000;t|s=9999|r=3|rg=1|z=10000;t|s=9999|rg=1|1=Nearby players get a bonus against: Dreadnautilus|z=1000;1|r=3|t=20|rg=1|1=Summons a baby harpy|2=Not for your everyday cockatiel|z=1000000;1|r=3|t=20|rg=1|1=Summons a fennec fox|2=It squeaks at a glorious 96kHz!|z=1000000;1|r=3|t=20|rg=1|1=Summons a pet butterfly|2=Only the best, most exquisite flower excrement!|z=1000000;at1|r=4|rg=1|z=100000;s1|r=8|d=41|t=36|k=4|m=10|rg=1|1=Summons a white tiger to fight for you|z=1000000;c|s=9999|t=19|rg=25|1=Toss in water up to 3 times to increase fishing power|2=Plankton!|z=2500;t|s=9999|rg=1|1=Said to bring good fortune and keep evil spirits at bay|z=50000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Hungry for Apples?|z=10000;c|s=9999|r=4|t=17|rg=5|1=Major improvements to all stats|2=Sugar. Water. Purple.|z=40000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=...make lemonade!|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Yellow and mellow|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Lifes a peach|z=10000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|2=If you like piña coladas and getting caught in the rain|z=20000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|2=Real smooth|z=20000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|2=Not really blood... or is it?|z=20000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|2=Come to the dark side, we have smoothies|z=20000;c|s=9999|r=3|t=17|rg=5|1=Medium improvements to all stats|2=Feel the rainbow, taste the crystal!|z=20000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=With 5% real fruit juice!|z=20000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|z=30000;t|s=9999|rg=1|1=U. One (Restored)|z=5000;t|s=9999|rg=1|1=J. Witzig (Restored)|z=5000;t|s=9999|rg=1|1=A. Dale|z=5000;t|s=9999|rg=1|1=C. Schneider|z=5000;t|s=9999|rg=1|1=C. Rohde|z=5000;t|s=9999|rg=1|1=X. Calder|z=5000;t|s=9999|rg=1|1=A. Dale|z=5000;t|s=9999|rg=1|1=J. Sterling|z=5000;t|s=9999|rg=1|1=Unearthed by C. Schneider|z=5000;t|s=9999|rg=1|1=Unearthed by C. Schneider|z=5000;t|s=9999|rg=1|1=S. Poirier|z=5000;t|s=9999|rg=1|1=J. Parker III|z=5000;t|s=9999|rg=1|1=C. Schneider|z=5000;t|s=9999|rg=1|1=C. Schneider|z=5000;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;t|s=9999|rg=100|z=500;w|s=9999|rg=400;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;4v1|r=3|rg=1|z=25000;5v1|r=3|rg=1|z=25000;6v1|r=3|rg=1|z=25000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=Ceci nest pas un club de golf.|2=V. Costa Moura|z=10000;|s=9999|r=3|rg=3|z=75000;|s=9999|r=3|rg=3|z=75000;5v1|r=3|rg=1|z=200000;6v1|r=3|rg=1|z=200000;4v1|r=3|rg=1|z=150000;w|s=9999|rg=400;|s=9999|rg=100|1=Fully illuminates the coated object|2=Can be combined with any other paint or coating|3=What a bright idea!|z=200;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;s1|d=14|t=30|k=1|rg=1|1=4 summon tag damage|2=Your summons will focus struck enemies|3=Die monster!|z=100000;1|t=12|rg=1|1=Playable next to Drum Set|2=The coffee is strong...and vulgar|z=5000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;s1|r=5|d=55|t=28|k=2|rg=1|1=9 summon tag damage|2=Your summons will focus struck enemies|3=Strike enemies to gain whip attack speed|z=230000;s1|r=8|c=10|d=180|t=35|k=11|rg=1|1=8 summon tag damage|2=12% summon tag critical strike chance|3=Your summons will focus struck enemies|z=300000;s1|r=8|d=100|t=27|k=3|rg=1|1=Your summons will focus struck enemies|2=Strike enemies with dark energy to gain whip attack speed|3=Dark energy jumps from enemies hit by summons|z=500000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;c|s=9999|t=25|rg=5|1=Released during certain ceremonies|z=100;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|3=This one cant wander too far|z=20000;1|t=30|rg=1|1=Kites can be flown on windy days|2=Reel it in with Right Click|z=20000;4v1|rg=1|z=100000;5v1|rg=1|z=100000;t|s=9999|rg=1|1=Nearby players get a bonus against: Angry Dandelion|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Gnome|z=1000;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|1=Life regen is increased when near a campfire;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=1000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;t|s=9999|rg=1|z=40000;1|r=3|t=20|rg=1|1=Summons little Plantero|z=500000;c|s=9999|t=25|rg=5|z=100;r1|r=3|d=14|t=55|k=6.5|rg=1|1=When 2 or 3 just doesnt cut it|z=350000;4v1|rg=1|z=100000;5v1|rg=1|z=100000;6v1|rg=1|z=100000;d1|r=2|d=15|t=22|k=5|rg=1|1=You will fall slower while holding this|z=100000;4v1|rg=1|z=100000;5v1|rg=1|z=100000;t|s=9999|rg=1;d1|d=12|t=22|k=3.5|rg=1|1=Digs in a bigger area than a pickaxe|2=Only digs up soft tiles|3=Can you dig it?|z=5000;t|s=9999|rg=1|z=2500;t|s=9999|rg=1|z=500;|s=9999|r=8|rg=1|1=Unlocks a Desert Chest in the dungeon;m1|r=5|c=20|d=85|t=12|k=1.5|m=12|rg=1|1=These chords are out of this world|z=500000;1|r=8|t=20|rg=1|1=Summons a rideable flamingo mount|z=200000;t|s=9999|rg=50;t|s=9999|rg=50;t|s=9999|rg=50;t|s=9999|rg=50;t|s=9999|rg=50;d1|r=10|c=10|d=190|t=35|k=6.5|z=1000000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=I am right here|z=400000;t|s=9999|r=8|rg=1|1=Seriously? THIS is what you used the Broken Hero Sword for?|z=150;4v1|r=9|rg=1|1=Great for impersonating devs!|2=Could this be the real Ghostar?|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=A fine dress handmade by a dragon|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|2=The journey of a thousand miles begins with one step|z=250000;1|r=3|t=20|rg=1|1=Summons a dynamite kitten|2=Its like yarn, but more exciting!|z=500000;1|r=3|t=20|rg=1|1=Summons a baby werewolf|z=300000;1|r=3|t=20|rg=1|1=Summons a pet shadow mimic|z=100000;4v1|r=2|rg=1|z=25000;5v1|r=2|rg=1|z=25000;4v1|r=2|rg=1|z=25000;5v1|r=2|rg=1|z=25000;6v1|r=2|rg=1|z=25000;c1|t=15|rg=1|1=Try to catch it!|z=20;av1|r=5|rg=1|z=150000;1|rg=1|z=10000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=Can you help me tie this on?|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|2=Bright idea|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=Fashionable and functional|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|2=Almost like pants|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|3=The holes cut down on weight.|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|2=Safety First|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|2=Max was a good boy.|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|2=They dont let me wear a loincloth anymore.|z=250000;a1|r=9|rg=1|1=Great for impersonating devs!|2=Allows flight and slow fall|z=400000;4v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;5v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;6v1|r=9|rg=1|1=Great for impersonating devs!|z=250000;s1|r=5|d=6|t=36|m=10|rg=1|1=Summons an Enchanted Dagger to fight for you|2=Ignores a substantial amount of enemy defense|3=Hits quickly at the expense of 25% tag damage|4=Dont let their small size fool you|z=50000;1|t=20|k=7|rg=1|1=Grapple onto trees like a real squirrel!|2=In the tree, part of the tree|z=20000;d1|r=5|d=80|t=36|k=2|rg=1|1=I can do this all day|z=350000;4vt|s=9999|r=3|rg=1;av1|rg=1|1=Applies dye to minions|z=100000;1|rg=1|1=Will dig through blocks and lay new track if carrying minecart tracks|2=Only digs when underground|z=500000;d1|d=23|t=20|k=7|rg=1|z=30000;rc|s=9999|r=2|t=20|rg=1|1=Toss it to change how trees look!|2=Time for a change of scenery|z=30000;rc|s=9999|r=2|t=20|rg=1|1=Toss it to change how the world looks!|2=Time for a change of scenery|z=30000;1|rg=1|1=Prevents you from hurting critters while in the inventory|z=50000;4v1|rg=1|z=30000;av1|rg=1|z=30000;4v1|rg=1|z=30000;av1|rg=1|z=30000;4v1|rg=1|z=30000;av1|rg=1|z=30000;4v1|rg=1|z=25000;av1|rg=1|1=Thats why they call me Thumper|z=30000;c|s=9999|t=15|rg=100|1=Hovers when thrown|2=Works when wet|z=75;1|r=3|t=20|rg=1|1=Summons a volt bunny|z=500000;|s=9999|r=3|rg=3|z=75000;4v1|rg=1;5v1|rg=1;6v1|rg=1;c|s=9999|r=6|rg=3|1=Right Click to open;t|s=9999|rg=1|z=50000;4v1|rg=1|z=37500;1|r=8|t=20|rg=1|1=Summons a rideable painted horse mount|z=250000;1|r=8|t=20|rg=1|1=Summons a rideable white horse mount|z=250000;1|r=8|t=20|rg=1|1=Summons a rideable dark horse mount|z=250000;d1|r=4|d=60|t=24|k=12|rg=1|1=Build momentum to increase attack power|2=Have at thee!|z=60000;d1|r=8|d=130|t=24|k=14|rg=1|1=Build momentum to increase attack power|z=500000;d1|r=5|d=90|t=24|k=13|rg=1|1=Build momentum to increase attack power|z=230000;1|r=8|t=20|rg=1|1=Summons a rideable pogo stick mount|2=Press Jump again in mid-air to do tricks!|z=250000;1|t=20|rg=1|1=Summons the Black Spot mount|2=Arrr! This be mutiny!|z=250000;1|t=20|rg=1|1=Summons a rideable tree mount|2=A wand crafted from the branch of a cursed tree.|z=250000;1|t=20|rg=1|1=Summons a rideable Santank mount|2=For the REALLY naughty ones.|z=250000;1|t=20|rg=1|1=Summons a rideable death goat mount|2=Brutal!|z=250000;1|t=20|rg=1|1=Summons a magic tome mount|2=A book said to be at its holders behest.|z=250000;1|t=20|rg=1|1=Summons a Slime Prince|2=A dessert fit for a king!|z=250000;1|t=20|rg=1|1=Summons a suspicious eye|2=Seems to have lost its look.|z=250000;1|t=20|rg=1|1=Summons the Eater of Worms|2=Itll give you worms!|z=250000;1|t=20|rg=1|1=Summons a spider brain|2=Pickled and shrunken, this brain can no longer hurt you.|z=250000;1|t=20|rg=1|1=Summons a small Skeletron|2=A skull with unimaginable power dulled.|z=250000;1|t=20|rg=1|1=Summons a honey bee|2=The secret ingredient for royal bees.|z=250000;1|t=20|rg=1|1=Summons a miniature tool of destruction|2=Its safe to operate this, right?|z=250000;1|t=20|rg=1|1=Summons miniature mechanical eyes|2=Two are better than one.|z=250000;1|t=20|rg=1|1=Summons a miniature Skeletron Prime|2=We can rebuild it.|z=250000;1|t=20|rg=1|1=Summons a newly sprouted Plantera|2=Get to the root of the problem.|z=250000;1|t=20|rg=1|1=Summons a toy golem to light your way|2=Power cells not included.|z=250000;1|t=20|rg=1|1=Summons a tiny Fishron|2=Brined to perfection.|z=250000;1|t=20|rg=1|1=Summons a baby phantasmal dragon|2=Contains a fragment of Phantasm energy.|z=250000;1|t=20|rg=1|1=Summons a Moonling|2=The forbidden calamari.|z=250000;1|t=20|rg=1|1=Summons a fairy princess to provide light|2=A glowing gemstone that houses a powerful fairy.|z=250000;1|t=20|rg=1|1=Summons a possessed Jack O Lantern|2=The flame cannot be put out!|z=250000;1|t=20|rg=1|1=Summons an Everscream sapling|2=Twinkle, Twinkle!|z=250000;1|t=20|rg=1|1=Summons a tiny Ice Queen|2=Fit for a queen!|z=250000;1|t=20|rg=1|1=Summons an alien skater|2=Kickflips are a lot easier in Zero-G!|z=250000;1|t=20|rg=1|1=Summons a baby ogre|2=No other uses besides smashing.|z=250000;1|t=20|rg=1|1=Summons Itsy Betsy|2=No fire sacrifices required!|z=250000;d1|r=2|d=25|t=15|k=3.5|rg=1|1=For fixing things, and breaking them|z=25000;1|r=4|t=90|rg=1|1=If you listen closely, you can hear screams|2=Watch your toes|z=50000;1|r=7|t=12|tr=2|rg=1|1=Contains an endless amount of lava|2=Can be poured out|z=500000;1|r=3|t=21|rg=1|1=For when things get too hot to handle|z=250000;av1|r=3|rg=1|1=Never get cold feet again|z=100000;a1|r=9|rg=1|1=Allows flight and slow fall|2=Hold Up to boost faster!|z=400000;c|s=9999|t=25|rg=99|1=A small explosion that will spread water|z=2500;c|s=9999|t=25|rg=99|1=A small explosion that will spread lava|z=2500;c|s=9999|t=25|rg=99|1=A small explosion that will spread honey|z=2500;c|s=9999|t=25|rg=99|1=A small explosion that will absorb liquid|z=2500;1|r=8|t=20|rg=1|1=Summons a rideable lava shark mount|2=Bloody hell!|z=250000;c|s=9999|r=2|t=45|rg=5|1=Use to adopt a cat for your town|2=Already have a cat?|3=Use additional licenses to activate the Pet Exchange Program!|4=Find the perfect fit for you and your cat!|z=50000;c|s=9999|r=2|t=45|rg=5|1=Use to adopt a dog for your town|2=Already have a dog?|3=Use additional licenses to activate the Pet Exchange Program!|4=Find the perfect fit for you and your dog!|z=50000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=5000;c|s=9999|t=15|rg=5|z=10000;t|s=9999|rg=1;c|s=9999|t=15|rg=5|z=10000;t|s=9999|rg=1;c|s=9999|r=2|t=15|rg=5|z=25000;t|s=9999|rg=1;t|s=9999|rg=5|z=3750;t|s=9999|rg=5|z=1875;t|s=9999|rg=5|z=5625;t|s=9999|rg=5|z=7500;t|s=9999|rg=5|z=11250;t|s=9999|rg=5|z=15000;t|s=9999|rg=5|z=15000;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=12500;t|s=9999|rg=1|z=20000;t|s=9999|rg=1|z=20000;c|s=9999|t=30|rg=20|1=Teleports you home and creates a portal|2=Use portal to return when you are done|3=Good for one round trip!|z=1000;t|s=9999|rg=25|z=10000;1|r=7|t=12|tr=2|rg=1|1=Capable of soaking up an endless amount of lava|z=500000;41|r=5|D=1|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 10%|z=250000;a1|r=7|rg=1|1=Allows flight|2=The wearer can run super fast|3=Leaves a trail of flames in your wake|z=600000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;|s=9999|r=2|rg=5|1=Right Click to open|2=Requires a Shadow Key|z=20000;t|s=9999|rg=1|1=No, you cant wear it on your head|z=10000;a1|r=7|rg=1|1=Allows fishing in lava|z=100000;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;41|r=5|D=24|rg=1|1=10% increased melee damage and critical strike chance|2=10% increased melee speed|z=250000;41|r=5|D=9|rg=1|1=15% increased ranged damage|2=8% increased ranged critical strike chance|z=250000;41|r=5|D=5|rg=1|1=Increases maximum mana by 100|2=12% increased magic damage and critical strike chance|z=250000;41|r=5|D=1|rg=1|1=Increases your max number of minions by 1|2=Increases summon damage by 10%|z=250000;51|r=5|D=15|rg=1|1=7% increased critical strike chance|z=200000;61|r=5|D=11|rg=1|1=7% increased damage|2=8% increased movement speed|z=150000;t|s=9999|r=3|rg=1|z=30000;t|s=9999|r=3|rg=1|z=30000;t|s=9999|r=3|rg=1|z=30000;t|s=9999|r=3|rg=1|z=30000;t|s=9999|r=3|rg=1|z=30000;t|s=9999|rg=25|z=10000;c|s=9999|t=25|rg=99|1=A small explosion that will spread dirt|z=500;c|s=9999|t=25|rg=99|1=A small explosion that will spread dirt|z=500;c|s=9999|r=2|t=45|rg=5|1=Use to adopt a bunny for your town|2=Already have a bunny?|3=Use additional licenses to activate the Pet Exchange Program!|4=Find the perfect fit for you and your bunny!|z=50000;s1|r=4|d=45|t=30|k=1.5|rg=1|1=6 summon tag damage|2=Your summons will focus struck enemies|3=Strike enemies to summon a friendly snowflake|4=Let me have some of that cool whip|z=200000;s1|r=4|d=37|t=30|k=2|rg=1|1=Your summons will focus struck enemies|2=Strike enemies with blazing energy|3=Blazing energy explodes from enemies hit by summons|z=150000;s1|r=3|d=18|t=30|k=1.5|rg=1|1=6 summon tag damage|2=Your summons will focus struck enemies|3=Strike enemies to gain whip attack speed|z=50000;s1|r=8|d=180|t=30|k=4|rg=1|1=20 summon tag damage|2=10% summon tag critical strike chance|3=Your summons will focus struck enemies|z=250000;rb|s=9999|d=9|k=4|rg=99|z=18;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|1=Teleport to another pylon when 2 villagers are nearby|2=You can only place one per type and in the matching biome|z=100000;t|s=9999|rg=1|z=40000;d1|r=8|c=10|d=80|t=18|k=4|rg=1|z=250000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|rg=1|z=50000;t|s=9999|r=9|rg=1|1=Teleport to another pylon|2=Can function anywhere|3=You must construct additional pylons|z=1000000;m1|r=8|d=50|t=36|k=2.5|m=23|rg=1|z=250000;r1|r=8|d=50|t=30|k=2|rg=1|z=250000;a1|r=9|rg=1|1=Allows flight and slow fall|2=Press Down to toggle hover|3=Press Up to deactivate hover|4=Hold Up to boost faster!|5=The more you know|z=500000;4v1|r=5|rg=1|1=It looks like a bunny, but its actually a bunny|z=150000;d1|r=10|c=10|d=190|t=30|k=6.5|rg=1|z=1000000;c|s=9999|r=6|rg=3|1=Right Click to open;t|s=9999|rg=1|z=50000;4v1|rg=1|z=37500;1|t=20|rg=1|1=Summons a Slime Princess|2=A dessert fit for a queen!|z=250000;c|s=9999|r=3|t=15|rg=3|1=Its wings are so delicate, you must be careful not to damage it...|z=250000;t|s=9999|rg=100|1=A Stone Slab variant that merges differently with nearby blocks|2=Favored by advanced builders;t|s=9999|rg=1|1=Wont be running away now...;t|s=9999|rg=1;t|s=9999|rg=1|1=Nearby players get a bonus against: Rock Golem|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Blood Mummy|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Spore Skeleton|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Spore Bat|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Antlion Larva|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Vicious Bunny|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Vicious Goldfish|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Vicious Penguin|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Corrupt Mimic|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Crimson Mimic|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Hallowed Mimic|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Moss Hornet|z=1000;t|s=9999|rg=1|1=Nearby players get a bonus against: Wandering Eye|z=1000;a1|rg=1|1=Allows flight and slow fall|z=2000;at1|r=4|rg=1|z=100000;1|r=5|t=20|k=7|rg=1|1=Teleports you to the location of the hook|z=250000;1|r=8|t=20|rg=1|1=Summons a rideable Winged Slime mount|z=250000;41|r=5|D=12|rg=1|1=5% increased critical strike chance|2=Reduces mana usage by 10%|z=100000;51|r=5|D=14|rg=1|1=5% increased damage|2=Reduces ammo usage by 10%|z=100000;61|r=5|D=10|rg=1|1=20% increased movement speed|2=10% increased melee speed|z=100000;at1|r=4|rg=1|z=100000;c|s=9999|t=15|rg=50|1=Filled with Party Girl bathwater|z=200;a1|r=6|rg=1|1=Releases volatile gelatin periodically that damages enemies|z=250000;c|s=9999|r=6|t=45|rg=3|1=Summons Queen Slime|z=50000;a1|rg=1|1=Grants infinite wing and rocket boot flight|2=Increases flight and jump mobility|z=500000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;t|s=9999|r=9|rg=1|1=Heeellllllo Terraria enthusiasts!|2=Great for chilling like a streamer!|z=25000;4v1|r=2|rg=1|z=100000;4v1|r=2|rg=1|z=100000;4v1|r=2|rg=1|z=100000;5v1|r=2|rg=1|z=100000;5v1|r=2|rg=1|z=100000;5v1|r=2|rg=1|z=100000;a1|r=7|rg=1|1=Allows flight, super fast running, and extra mobility on ice|2=8% increased movement speed|3=Provides the ability to walk on water, honey & lava|4=Grants immunity to fire blocks and 7 seconds of immunity to lava|5=Reduces damage from touching lava|z=750000;61|r=2|D=3|rg=1|1=Slightly increases mobility|2=These might be Steves|z=100000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;t|s=9999|r=2|rg=5|1=Right Click to open|z=50000;4v1|r=9|rg=1|1=You seem to have a problem with your green screen|2=Great for impersonating streamers!|z=15000;s1|r=5|d=90|t=36|k=4|m=10|rg=1|1=Summons an Enchanted Sword to fight for you|z=1000000;at1|r=4|rg=1|z=100000;5v1|r=2|rg=1|z=10000;t|s=9999|rg=1|z=1000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=A must-have for tea parties|z=20;a1|rg=1|1=Increases pickup range for items|z=150000;d1|d=9|t=45|k=4.6|rg=1|1=Can be upgraded with torches|z=100000;d1|d=9|t=45|k=4.6|rg=1|1=May the fire light your way|z=100000;1;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;at1|r=4|rg=1|z=100000;c|s=9999|r=2|t=17|rg=5|1=Minor improvements to all stats|2=For strong, healthy bones|z=10000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Hello darkness my old friend|z=10000;c|s=9999|r=4|t=30|rg=1|1=Unlocks an ability toggle to the left of the inventory|2=When enabled normal torches change according to your biome|z=100000;at1|r=4|rg=1|z=100000;4v1|r=2|rg=1|1=That right there is 100% genuine Ahamkara, trust!|2=Concept by SodaHunter|z=500;5v1|r=2|rg=1|1=Who knew a blight-weaving world-ender would have such good taste in fashion?|2=Concept by SodaHunter|z=500;6v1|r=2|rg=1|1=The horrors these boots have seen, or should I say, stepped on.|2=Concept by SodaHunter|z=500;4v1|r=2|rg=1|1=Your most loyal travel companion. The glowing orb is soft and welcoming.|2=Concept by crowflux|z=500;5v1|r=2|rg=1|1=Incredibly old, yet unnaturally durable. Who knows how long it traveled just to find you.|2=Concept by crowflux|z=500;6v1|r=2|rg=1|1=It constantly reminds you that there is more than one path to the top of the mountain.|2=Concept by crowflux|z=500;4v1|r=2|rg=1|1=May time itself with gentle hands|2=Guide you, who travel on...|3=Concept by DisRicardo|z=500;5v1|r=2|rg=1|1=...Despite the journeys bygone end...|2=Concept by DisRicardo|z=500;6v1|r=2|rg=1|1=...And passing of aeons!|2=Concept by DisRicardo|z=500;4v1|r=2|rg=1|1=When a cosmic ray penetrates a star cloud, that fantastic light...|2=Concept by yikescloud|z=500;5v1|r=2|rg=1|1=ID.170122 - RSS ZEPHYRUS III|2=Concept by yikescloud|z=500;6v1|r=2|rg=1|1=I am a duck QUACK-QUACK-QUACK|2=Concept by yikescloud|z=500;4v1|r=2|rg=1|1=Embodiment of the stars majesty, shiny!|2=Concept by R-MK|z=500;5v1|r=2|rg=1|1=As protective as glass!|2=Concept by R-MK|z=500;6v1|r=2|rg=1|1=Now you can wear shoes! Maybe!|2=Right Click to transform|3=Concept by R-MK|z=500;6v1|r=2|rg=1|1=Sadly, does not provide the ability to swim.|2=Right Click to transform|3=Concept by R-MK|z=500;4v1|r=2|rg=1|1=You cant see me behind the screen, Im half human and half machine...|2=Concept by Dr.Zootsuit|z=500;5v1|r=2|rg=1|1=How bad could business possibly be?|2=Concept by Dr.Zootsuit|z=500;6v1|r=2|rg=1|1=I cant decide... leather or suede?|2=Concept by Dr.Zootsuit|z=500;a1|r=8|rg=1|1=Fishing line will never break, decreases chance of bait consumption, increases fishing power by 10|2=Allows fishing in lava|z=200000;m1|r=5|d=70|t=25|k=5|m=18|rg=1|z=500000;t|s=9999|rg=5|z=250;t|s=9999|rg=5|z=250;51|r=2|D=1|rg=1|1=Increases summon damage by 5%|2=Increases your max number of minions by 1|z=125000;s1|r=3|d=8|t=36|k=2|m=5|rg=1|1=Summons a snow flinx to fight for you|z=25000;|s=9999|rg=15|1=Its so FLUFFY!|z=500;4v1|r=5|rg=1|z=500000;5v1|r=5|rg=1|z=500000;6v1|r=5|rg=1|z=500000;s1|r=2|d=27|t=30|k=2|rg=1|1=7 summon tag damage|2=Your summons will focus struck enemies|3=Performs better against multiple targets than most whips|4=This goes to eleven|z=75000;av1|r=5|rg=1|1=Causes your mouse cursor to have shifting rainbow colors|z=50000;av1|r=5|rg=1|z=1000000;av1|r=5|rg=1|z=1000000;5v1|r=5|rg=1|z=500000;6v1|r=5|rg=1|z=500000;av1|r=5|rg=1|z=500000;t|s=9999|r=5|rg=1|z=100000;t|s=9999|r=5|rg=1|z=100000;t|s=9999|r=5|rg=1|z=100000;t|s=9999|r=5|rg=1|z=100000;t|s=9999|rg=1|1=J. Hayes|z=100000;t|s=9999|rg=1|1=J. Hayes|z=100000;t|s=9999|rg=1|1=J. Hayes|z=100000;1|r=3|t=20|rg=1|1=Summons a cherished teddy bear|2=My childhood buddy - Bernie!|z=250000;1|r=3|t=20|rg=1|1=Summons a Glommer|2=The petals shimmer in the light|z=250000;1|t=20|rg=1|1=Summons a tiny Deerclops|2=You lookin at me? Are YOU lookin at ME?|z=250000;1|r=3|t=20|rg=1|1=Summons a small Pig Man|2=Gross. Its full of hairs.|z=50000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Tastes like hairs and meats with noodle.|z=5000;c|s=9999|r=2|t=17|rg=5|1=Medium improvements to all stats|2=Has a bit of a kick to it.|z=10000;d1|r=2|d=20|t=21|k=5.5|rg=1|1=Embeds damaging spikes in enemies|2=Never grab the pointy end.|z=25000;d1|r=2|c=10|d=27|t=15|k=5|tx=30|rg=1|1=I love Lucy!|z=75000;d1|r=4|d=57|t=20|k=6.5|rg=1|1=Grows more powerful the better fed you are|2=Defeating enemies temporarily improves healing|3=TIS A WEAPON O PIG BUTT!|z=50000;d1|r=2|d=36|t=45|k=5.5|rg=1|1=May heal user on hit|2=Maybe I could bat some bats with this.|z=12500;1|r=3|t=20|rg=1|1=Summons a living chest to store your items|2=Its looking into my soul.|z=100000;4v1|rg=1|1=It smells like prettiness.|z=500;a1|rg=1|1=Summons shadow hands to attack your foes|2=Ive got a headache just looking at it.|z=100000;4v1|rg=1|1=Dont get rain in your eye!|z=25000;5v1|rg=1|z=20000;6v1|rg=1|z=20000;av1|rg=1|1=This is human facial hair.|z=50000;av1|rg=1|1=This is human facial hair.|z=50000;av1|rg=1|1=This is human facial hair.|z=50000;a1|rg=1|1=Increases movement speed and acceleration|2=Provides light when worn|3=A brief light in my dark life.|z=50000;t|s=9999|rg=1|z=50000;4v1|rg=1|z=37500;t|s=9999|rg=1|z=50000;c|s=9999|r=3|rg=3|1=Right Click to open;at1|r=4|rg=1|z=100000;av1|rg=1|1=Allows the user to see the world differently|2=Forbidden Knowledge echoes from the radio...|z=50000;s1|r=3|d=6|t=36|k=2|m=10|rg=1|1=Summons a friendly ghost to fight for you|2=Its hauntingly beautiful.|z=25000;5v1|rg=1|z=20000;6v1|rg=1|z=20000;r1|r=2|d=20|t=15|k=1|rg=1|1=Converts bullets into random stuff|2=ALLOWS WIRELESS TRANSFER OF INJURY!|z=75000;m1|r=2|d=13|t=45|k=1|m=30|rg=1|1=Ignores 10 points of enemy Defense|2=What a pane... heh|z=75000;sS1|r=2|d=24|t=30|k=7.5|m=20|rg=1|1=Summons a sentry|2=Summons an arcane construct to shoot optic blasts at your enemies|3=Oh me oh my, look at that eye!|z=75000;c|s=9999|t=45|rg=3|1=Summons Deerclops;t|s=9999|rg=1|1=C.J. Lee|2=Adapted by J. T. Kjexrud|z=10000;t|s=9999|rg=1|1=C.J. Lee|2=Adapted by J. T. Kjexrud|z=10000;t|s=9999|rg=1|1=C.J. Lee|2=Adapted by J. T. Kjexrud|z=10000;t|s=9999|rg=1|1=C.J. Lee|2=Adapted by J. T. Kjexrud|z=10000;1|r=2|rg=1|z=25000;a1|rg=1|1=Increases mining speed by 25%|2=Increases block & wall placement speed|3=Increases block placement & tool range by 3|4=Increases pickup range for items|5=Automatically paints or coats placed objects|6=Hold Up to reach higher|z=400000;t|s=9999|rg=25|1=A sight to dwell upon and never forget;t|s=9999|rg=25|1=A sight to dwell upon and never forget;d1|r=2|d=15|t=17|k=5|rg=1|1=Best used for pranking townsfolk|2=Makes others smell like cilantro|z=17500;1|r=8|t=20|rg=1|1=Grants the wearer the power of the wolf|z=250000;1|t=20|rg=1|1=Summons both Slime Royals|2=A dessert to celebrate love|z=250000;c|s=9999|t=15|rg=5|z=5000;t|s=9999|rg=1;1|r=10|t=30|k=0.3|rg=1|1=Creates and destroys biomes when sprayed|2=Uses colored solution|3=33% chance to not consume ammo|z=2000000;t|s=9999|r=4|rg=5|z=30000;4v1|rg=1|z=25000;t|s=9999|r=2|rg=1|1=When placed in a home, prevents villagers from moving in|2=Smells like cilantro|z=5000;t|s=9999|r=2|rg=1|1=When placed in a home, prevents villagers from moving in|2=Only visible with Echo Sight|3=Smells like expired cilantro|z=5000;a1|rg=1|1=Increases fishing power by 10|z=25000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;a1|rg=1|1=Increases fishing power by 10|2=Your bobber now glows|z=50000;m1|c=10|d=15|t=26|m=2|rg=1|1=Shoots a little frost|z=7500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=2000;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=1500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=3000;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=200;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=300;t|s=9999|rg=200;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=150;t|s=9999|rg=1|z=500;t|s=9999|rg=1|z=150;c|s=9999|r=5|t=17|rg=20|1=Shows the location of infected blocks|z=1000;c|s=9999|t=15|rg=5|z=3750;t|s=9999|rg=1;t|s=9999|rg=25|z=150;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;t|s=9999|rg=1|1=S. Poirier|z=5000;t|s=9999|rg=1|1=C. Germaine|z=5000;t|s=9999|rg=1|1=W. Black|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=B. Hook|z=100000;t|s=9999|rg=1|1=C. Rohde|z=5000;t|s=9999|rg=1|1=A. Spinks|z=5000;t|s=9999|rg=1|1=J. Doppler|z=5000;t|s=9999|rg=1|1=T.T. Shabbick|z=5000;t|s=9999|rg=1|1=J. Witzig|z=5000;t|s=9999|rg=1|1=C. Germaine|z=100000;t|s=9999|rg=1|1=U. One|z=5000;t|s=9999|rg=1|1=T. Murphy|2=Im such a lizard, you dont even know my real name...|z=5000;t|s=9999|rg=1|1=J. Parker III|z=10000;t|s=9999|rg=1|1=T.T. Shabbick|z=5000;t|s=9999|rg=1|1=B. Witch|z=5000;t|s=9999|rg=1|1=C. Rohde|z=5000;t|s=9999|rg=1|1=B. Hook|z=25000;t|s=9999|rg=1|1=C. Rohde|z=5000;t|s=9999|rg=1|1=G. Groviar|z=5000;t|s=9999|rg=1|1=S. Grimson-Smith|z=5000;t|s=9999|rg=1|1=J. Parker III|z=5000;t|s=9999|rg=1|1=J. Witzig|z=5000;t|s=9999|rg=1|1=S. Gutierrez|z=5000;t|s=9999|rg=1|1=M. Koller|z=5000;t|s=9999|rg=1|1=A. Dale|z=30000;t|s=9999|rg=1|1=B. Witch|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=10000;t|s=9999|rg=1|1=M. User|z=5000;t|s=9999|rg=1|1=S. Grimson-Smith|z=5000;t|s=9999|rg=1|1=J. Parker III|2=In memory of R. N. Ross|z=5000;t|s=9999|rg=1|1=J. Parker III|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=C. Germaine|z=10000;t|s=9999|rg=1|1=C. Rohde|z=25000;t|s=9999|rg=1|1=B. Hook|z=10000;t|s=9999|rg=1|1=S. Grimson-Smith|z=5000;t|s=9999|rg=1|1=K. Tollenaar|z=5000;t|s=9999|rg=1|1=K. Tollenaar|z=25000;t|s=9999|rg=1|1=V. Costa Moura|z=10000;t|s=9999|rg=1|1=C. Rohde|z=5000;t|s=9999|rg=1|1=C. Rohde|z=25000;t|s=9999|rg=1|1=C. Rohde|z=5000;t|s=9999|rg=1|1=T.T. Shabbick|z=5000;t|s=9999|rg=1|1=X. Calder|z=5000;t|s=9999|rg=1|1=W. Spinks|z=25000;t|s=9999|rg=1|1=J. Parker III|2=Legends say the batteries died ages ago.|z=25000;t|s=9999|rg=1|1=J. T. Kjexrud|z=25000;t|s=9999|rg=1|1=V. Costa Moura|z=100000;t|s=9999|rg=1|1=J. Witzig|z=5000;t|s=9999|rg=1|1=C. Germaine|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;t|s=9999|rg=1|1=J. T. Kjexrud|z=5000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|2=Please Recycle|z=125;1|r=3|t=20|rg=1|1=Summons a Junimo|2=A mysterious fruit from another world. The flavor is like a dream...|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;c|s=9999|t=17|rg=5|1=Minor improvements to all stats|z=10000;41|D=2|rg=1;51|D=3|rg=1;61|D=2|rg=1;r1|d=10|t=25|rg=1|z=100;d1|d=9|t=30|k=5.5|th=45|rg=1|z=50;d1|d=13|t=17|k=5|rg=1|z=100;rc|s=9999|r=2|t=20|rg=1|1=Toss it to change how the moon looks!|2=Time for a change of scenery|z=30000;t|s=9999|r=2|rg=10|z=75000;t|s=9999|r=2|rg=10|z=12500;1|r=8|rg=1|z=50000;c|s=9999|r=5|t=30|rg=1|1=Permanently grants boosted speed and a defensive probe for minecarts|2=Free Mechanical Cart included!|z=100000;4v1|rg=1|z=25000;w|s=9999|rg=400|1=Only visible with Echo Sight|z=250;t|s=9999|rg=200|1=Only visible with Echo Sight|z=500;t|s=9999|rg=100|z=60;d1|r=3|d=24|t=25|k=3.75|rg=1|1=Summons killer bees after striking your foe|z=90000;dt1|r=4|d=20|k=5|tx=30|rg=1|1=Creates grass on dirt|2=Increases alchemy plant collection when used to gather|3=Plants acorns when cutting down trees|z=75000;t|s=9999|r=7|rg=1|1=Placing silt/slush/fossil piles into the extractinator turns them into something more useful|2=Place contaminated blocks into the extractinator to purify them|3=Other items placed inside may have interesting effects|z=100000;1|r=3|t=20|rg=1|1=Summons a blue chicken|2=A regular blue chicken egg|z=250000;d1|r=3|d=21|t=22|k=3|rg=1|1=Three Boomerangs are better than one|z=100000;t|s=9999|rg=1|1=Life regen is increased when near a campfire;c|s=9999|t=15|rg=5|z=3750;t|s=9999|rg=1;1|r=7|t=12|tr=2|rg=1|1=Contains an endless amount of honey|2=Can be poured out|z=500000;1|r=7|t=12|tr=2|rg=1|1=Capable of soaking up an endless amount of honey|z=500000;1|r=8|t=8|tr=3|rg=1|1=Capable of soaking up an endless amount of liquid|z=1500000;4v1|rg=1|z=25000;t|s=9999|rg=100|z=100;w|s=9999|rg=400;t|s=9999|rg=1|1=The Terraria Community|z=10000;1|rg=1|1=Prevents you from accidentally destroying the environment while in the inventory|z=50000;t|s=9999|rg=1|1=Yorai Omer|z=100000;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=3750;c|s=9999|t=15|rg=5|z=3750;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=1|z=300;t|s=9999|rg=30|z=300;t|s=9999|rg=30|z=100;t|s=9999|rg=1|1=Nullifies the peaceful benefits of towns|z=500;1|r=2|rg=1|1=Prevents you from hurting critters while in the inventory|2=Prevents you from accidentally destroying the environment while in the inventory|z=100000;t1|r=10|tr=3|rg=1|1=Used with materials to place matching rubble|2=Right Click to toggle placement size|3=Press Up/Down to cycle through styles|4=Not a piledriver nor a placeinator: Its a Rubblemaker|z=250000;1|r=3|t=28|rg=1|1=Summons the void vault|2=Functions as an extended inventory when open|3=May pick up overflowing items when open|4=Right Click to open|5=This pocket dimension is out of this world!|z=100000;c1|r=3|t=17|rg=1|1=Consume to permanently increase crafting station range|2=Legendary Bread that once reminded Teddy of home|z=100000;t|s=9999|rg=5|1=Highly volatile;c|s=9999|t=15|rg=5|1=Can be used to lock some chests;t1|r=10|tr=3|rg=1|1=Used with materials to place matching rubble|2=Right Click to toggle placement size|3=Press Up/Down to cycle through styles|4=Not a piledriver nor a placeinator: Its a Rubblemaker|z=250000;t1|r=10|tr=3|rg=1|1=Used with materials to place matching rubble|2=Right Click to toggle placement size|3=Press Up/Down to cycle through styles|4=Not a piledriver nor a placeinator: Its a Rubblemaker|z=250000;a1|r=8|rg=1|1=Allows the holder to quadruple jump|2=Increases jump height and negates fall damage|z=200000;1|r=3|t=20|rg=1|1=Summons Spiffo the Raccoon!|z=100000;1|r=3|t=20|rg=1|1=Summons a Caveling Gardener|2=Ancient energy in full bloom.|z=100000;|s=9999|r=3|rg=3|1=Summons ???|2=You really shouldnt;1|r=10|t=20|rg=1|1=Teleports you to the position of the mouse|z=500000;c|s=9999|r=6|t=45|rg=1|1=Increases the defense and strength of all villagers|2=Contains offensive and defensive fighting techniques, volume two!;c|s=9999|r=6|t=45|rg=1|1=Permanently boosts life regeneration|z=75000;c|s=9999|r=6|t=45|rg=1|1=Permanently increases defense|z=100000;c|s=9999|r=6|t=45|rg=1|1=Permanently increases mana regeneration|z=12500;c|s=9999|r=6|t=45|rg=1|1=Permanently increases luck|z=750000;c|s=9999|r=6|t=45|rg=1|1=Permanently increases fishing skill|z=500000;c|s=9999|r=6|t=45|rg=1|1=Permanently increases mining and building speed|z=25000;c|s=9999|r=6|t=45|rg=1|1=Permanently increases items sold by the Traveling Merchant|z=12500;|s=9999|rg=100|1=Renders coated objects visible only with Echo Sight|2=Can be combined with any other paint or coating|3=Its all clear to me now.|z=200;avt|s=9999|r=9|rg=1|1=Enables Echo Sight, showing hidden blocks|z=50000;1|r=2|rg=1|1=Releases poisonous gas when a container it is in is opened|z=15000;avt|s=9999|r=9|rg=1|1=Witness a glimpse of the Aethers power.|2=Can be used to manifest or suppress the Aether|z=50000;rb|s=9999|r=2|d=12|k=2|rg=99|1=Falls upwards|z=10;t|s=9999|rg=50;c|s=9999|r=5|t=15|rg=5|z=1250;t|s=9999|rg=1;t|s=9999|rg=1|1=Nearby players get a bonus against: Shimmer Slime|z=1000;t|s=9999|rg=100|z=60;a1|r=5|rg=1|1=Immunity to Darkness and Petrification|z=100000;a1|r=5|rg=1|1=Immunity to Shimmer Phasing|2=Hold Down to Phase while submerged in Shimmer|z=100000;1|rg=1;t|s=9999|rg=1|1=Life regen is increased when near a campfire;1|r=8|t=90|rg=1|1=Displays everything|2=Allows you to return home at will|3=Right Click to toggle destination|4=If you listen closely, you can hear something about your cars warranty|z=500000;1|r=8|t=90|rg=1|1=Displays everything|2=Allows you to return to spawn at will|3=Right Click to toggle destination|4=If you listen closely, you can hear something about your cars warranty|z=500000;1|r=8|t=90|rg=1|1=Displays everything|2=Allows you to travel to the ocean at will|3=Right Click to toggle destination|4=If you listen closely, you can hear something about your cars warranty|z=500000;1|r=8|t=90|rg=1|1=Displays everything|2=Allows you to travel to the underworld at will|3=Right Click to toggle destination|4=If you listen closely, you can hear something about your cars warranty|z=500000;at1|r=4|rg=1|z=100000;w|s=9999|rg=400|1=An egg-infested chunk of Spider wall that will spawn spiders;1|r=10|t=12|tr=2|rg=1|1=Contains an endless amount of Shimmer|2=Can be poured out|z=500000;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A cursed segment of Dungeon wall that will spawn monsters;w|s=9999|rg=400|1=A dangerous slab of sand wall that will spawn monsters;w|s=9999|rg=400|1=A dangerous slab of sand wall that will spawn monsters;w|s=9999|rg=400|1=An ancient segment of Temple wall that will spawn Lihzahrds;rb|s=9999|d=1|k=1.5|rg=99|1=Exposes nearby treasure|z=150;rb|s=9999|d=1|k=1.5|rg=99|z=7;rb|s=9999|d=1|k=1.5|rg=99|z=7;rb|s=9999|d=1|k=1.5|rg=99|z=7;t|s=9999|r=7|rg=1|1=Allows time to fast forward to dusk one day per week|z=150000;d1|r=5|d=50|t=23|k=4.75|rg=1|1=Its Waffle Time!|z=150000;t|s=9999|r=5|rg=5|z=75;t|s=9999|r=2|rg=5|z=75000;4v1|rg=1|1=The Blue Traktor is coming|2=Great for impersonating streamers!|z=25000;5v1|r=3|rg=1|1=Property of Raynebro|z=10000;6v1|r=3|rg=1|1=Property of Raynebro|z=10000;t|s=9999|rg=1|1=C. Paninie|z=5000;t|s=9999|rg=1|1=C. Paninie|z=5000;4v1|r=3|rg=1|1=Property of Raynebro|z=10000;1|rg=1|1=Prevents item pickups while locked|2=Right Click to lock|3=You are over-encumbered|z=50000;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Desert|z=1500;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Snow|z=1500;b|s=9999|r=3|rg=99|1=Used by the Clentaminator|2=Spreads the Forest|z=1500;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=200;t|s=9999|rg=50;w|s=9999|rg=200;1|t=20|rg=1|1=Now with 20% more dirt!|z=1000;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;t|s=9999|r=9|rg=100|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;w|s=9999|r=9|rg=400|1=A forbidden building material from beyond;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;t|s=9999|rg=100;w|s=9999|rg=400;1|r=8|t=90|rg=1|1=Displays everything|2=Right Click to toggle destination|3=If you listen closely, you can hear something about your cars warranty|z=500000;c|s=9999|t=15|rg=30|1=Causes saplings to instantly grow into trees|z=50;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;t|s=9999|rg=100;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;w|s=9999|rg=400;1|r=3|t=32|rg=1|1=Rotate Left/Right to steer & Press Up to accelerate|2=First rule of Flight Club, we dont talk about Flight Club|z=100000;a1|r=3|rg=1|1=Allows wearer to see through their drone camera|2=Chonky Fishron RC Systems|z=100000".split(";");
terra_data_TdNPC.count = 688;
terra_data_TdNPC.$name = ";Blue Slime;Demon Eye;Zombie;Eye of Cthulhu;Servant of Cthulhu;Eater of Souls;Devourer Head;Devourer Body;Devourer Tail;Giant Worm Head;Giant Worm Body;Giant Worm Tail;Eater of Worlds Head;Eater of Worlds Body;Eater of Worlds Tail;Mother Slime;Merchant;Nurse;Arms Dealer;Dryad;Skeleton;Guide;Meteor Head;Fire Imp;Burning Sphere;Goblin Peon;Goblin Thief;Goblin Warrior;Goblin Sorcerer;Chaos Ball;Angry Bones;Dark Caster;Water Sphere;Cursed Skull;Skeletron Head;Skeletron Hand;Old Man;Demolitionist;Bone Serpent Head;Bone Serpent Body;Bone Serpent Tail;Hornet;Man Eater;Undead Miner;Tim;Bunny;Corrupt Bunny;Harpy;Cave Bat;King Slime;Jungle Bat;Doctor Bones;The Groom;Clothier;Goldfish;Snatcher;Corrupt Goldfish;Piranha;Lava Slime;Hellbat;Vulture;Demon;Blue Jellyfish;Pink Jellyfish;Shark;Voodoo Demon;Crab;Dungeon Guardian;Antlion;Spike Ball;Dungeon Slime;Blazing Wheel;Goblin Scout;Bird;Pixie;Wandering Eye;Armored Skeleton;Mummy;Dark Mummy;Light Mummy;Corrupt Slime;Wraith;Cursed Hammer;Enchanted Sword;Mimic;Unicorn;Wyvern Head;Wyvern Legs;Wyvern Body;Wyvern Tail Start;Wyvern Tail;Wyvern Tail End;Giant Bat;Corruptor;Digger;Digger;Digger;World Feeder;World Feeder;World Feeder;Clinger;Angler Fish;Green Jellyfish;Werewolf;Bound Goblin;Bound Wizard;Goblin Tinkerer;Wizard;Clown;Skeleton Archer;Goblin Archer;Vile Spit;Wall of Flesh;Wall of Flesh Eye;The Hungry;The Hungry (detached);Leech Head;Leech Body;Leech Tail;Chaos Elemental;Slimer;Gastropod;Bound Mechanic;Mechanic;Retinazer;Spazmatism;Skeletron Prime;Prime Cannon;Prime Saw;Prime Vice;Prime Laser;Zombie;Wandering Eye;The Destroyer Head;The Destroyer Body;The Destroyer Tail;Illuminant Bat;Illuminant Slime;Probe;Possessed Armor;Toxic Sludge;Santa Claus;Snowman Gangsta;Mister Stabby;Snow Balla;NPCName.None3;Ice Slime;Penguin;Penguin;Ice Bat;Lava Bat;Giant Flying Fox;Giant Tortoise;Ice Tortoise;Wolf;Red Devil;Arapaima;Vampire;Vampire;Truffle;Frozen Zombie;Frankenstein;Black Recluse;Wall Creeper;Wall Creeper;Swamp Thing;Undead Viking;Corrupt Penguin;Ice Elemental;Pigron;Pigron;Rune Wizard;Crimera;Herpling;Angry Trapper;Moss Hornet;Derpling;Steampunker;Crimson Axe;Pigron;Face Monster;Floaty Gross;Crimslime;Spiked Ice Slime;Snow Flinx;Zombie;Zombie;Zombie;Zombie;Demon Eye;Demon Eye;Demon Eye;Demon Eye;Demon Eye;Lost Girl;Nymph;Armored Viking;Lihzahrd;Lihzahrd;Zombie;Skeleton;Skeleton;Skeleton;Spiked Jungle Slime;Moth;Icy Merman;Dye Trader;Party Girl;Cyborg;Bee;Bee;Pirate Deckhand;Pirate Corsair;Pirate Deadeye;Pirate Crossbower;Pirate Captain;Cochineal Beetle;Cyan Beetle;Lac Beetle;Sea Snail;Squid;Queen Bee;Raincoat Zombie;Flying Fish;Umbrella Slime;Flying Snake;Painter;Witch Doctor;Pirate;Goldfish;Hornet;Hornet;Hornet;Hornet;Hornet;Jungle Creeper;Jungle Creeper;Black Recluse;Blood Crawler;Blood Crawler;Blood Feeder;Blood Jelly;Ice Golem;Rainbow Slime;Golem;Golem Head;Golem Fist;Golem Fist;Golem Head;Angry Nimbus;Eyezor;Parrot;Reaper;Spore Zombie;Spore Zombie;Fungo Fish;Anomura Fungus;Mushi Ladybug;Fungi Bulb;Giant Fungi Bulb;Fungi Spore;Plantera;Planteras Hook;Planteras Tentacle;Spore;Brain of Cthulhu;Creeper;Ichor Sticker;Rusty Armored Bones;Rusty Armored Bones;Rusty Armored Bones;Rusty Armored Bones;Blue Armored Bones;Blue Armored Bones;Blue Armored Bones;Blue Armored Bones;Hell Armored Bones;Hell Armored Bones;Hell Armored Bones;Hell Armored Bones;Ragged Caster;Ragged Caster;Necromancer;Necromancer;Diabolist;Diabolist;Bone Lee;Dungeon Spirit;Giant Cursed Skull;Paladin;Skeleton Sniper;Tactical Skeleton;Skeleton Commando;Angry Bones;Angry Bones;Angry Bones;Blue Jay;Cardinal;Squirrel;Mouse;Raven;Slime;Bunny;Hoppin Jack;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Scarecrow;Headless Horseman;Ghost;Demon Eye;Demon Eye;Zombie;Zombie;Zombie;Skeleton;Skeleton;Skeleton;Mourning Wood;Splinterling;Pumpking;Pumpking;Hellhound;Poltergeist;Zombie;Zombie;Slime;Slime;Slime;Slime;Bunny;Zombie Elf;Zombie Elf;Zombie Elf;Present Mimic;Gingerbread Man;Yeti;Everscream;Ice Queen;Santa-NK1;Elf Copter;Nutcracker;Nutcracker;Elf Archer;Krampus;Flocko;Stylist;Webbed Stylist;Firefly;Butterfly;Worm;Lightning Bug;Snail;Glowing Snail;Frog;Duck;Duck;Duck;Duck;Scorpion;Scorpion;Traveling Merchant;Angler;Duke Fishron;Detonating Bubble;Sharkron;Sharkron;Truffle Worm;Truffle Worm;Sleeping Angler;Grasshopper;Chattering Teeth Bomb;Cultist Archer;Cultist Archer;Brain Scrambler;Ray Gunner;Martian Officer;Bubble Shield;Gray Grunt;Martian Engineer;Tesla Turret;Martian Drone;Gigazapper;Scutlix Gunner;Scutlix;Martian Saucer;Martian Saucer Turret;Martian Saucer Cannon;Martian Saucer;Moon Lord's Head;Moon Lords Hand;Moon Lords Core;Martian Probe;True Eye of Cthulhu;Moon Leech Clot;Milkyway Weaver Head;Milkyway Weaver Body;Milkyway Weaver Tail;Star Cell;Mini Star Cell;Flow Invader;NPCName.StardustJellyfishSmall;Twinkle Popper;Twinkle;Stargazer;Crawltipede Head;Crawltipede Body;Crawltipede Tail;Drakomire;Drakomire Rider;Sroller;Corite;Selenian;Nebula Floater;Brain Suckler;Vortex Pillar;Evolution Beast;Predictor;Storm Diver;Alien Queen;Alien Hornet;Alien Larva;Vortexian;Zombie;Frozen Zombie;Zombie;Zombie;Zombie;Zombie;Zombie;Mysterious Tablet;Lunatic Devotee;Lunatic Cultist;Lunatic Cultist;Tax Collector;Gold Bird;Gold Bunny;Gold Butterfly;Gold Frog;Gold Grasshopper;Gold Mouse;Gold Worm;Skeleton;Skeleton;Skeleton;Skeleton;Skeleton Merchant;Phantasm Dragon;Phantasm Dragon;Phantasm Dragon;Phantasm Dragon;Phantasm Dragon;Phantasm Dragon;Butcher;Creature from the Deep;Fritz;Nailhead;Vicious Bunny;Vicious Goldfish;Psycho;Deadly Sphere;Dr. Man Fly;The Possessed;Vicious Penguin;Goblin Summoner;Shadowflame Apparition;Corrupt Mimic;Crimson Mimic;Hallowed Mimic;Jungle Mimic;Mothron;Mothron Egg;Baby Mothron;Medusa;Hoplite;Granite Golem;Granite Elemental;Enchanted Nightcrawler;Grubby;Sluggy;Buggy;Target Dummy;Blood Zombie;Drippler;Flying Dutchman;Dutchman Cannon;Stardust Pillar;Crawdad;Crawdad;Giant Shelly;Giant Shelly;Salamander;Salamander;Salamander;Salamander;Salamander;Salamander;Salamander;Salamander;Salamander;Nebula Pillar;Giant Antlion Charger;Giant Antlion Swarmer;Dune Splicer Head;Dune Splicer Body;Dune Splicer Tail;Tomb Crawler Head;Tomb Crawler Body;Tomb Crawler Tail;Solar Flare;Solar Pillar;Drakanian;Solar Fragment;Martian Walker;Ancient Vision;Ancient Light;Ancient Doom;Ghoul;Vile Ghoul;Tainted Ghoul;Dreamer Ghoul;Lamia;Lamia;Sand Poacher;Sand Poacher;Basilisk;Desert Spirit;Tortured Soul;Spiked Slime;The Bride;Sand Slime;Red Squirrel;Gold Squirrel;Bunny;Sand Elemental;Sand Shark;Bone Biter;Flesh Reaver;Crystal Thresher;Angry Tumbler;???;Eternia Crystal;Mysterious Portal;Tavernkeep;Betsy;Etherian Goblin;Etherian Goblin;Etherian Goblin;Etherian Goblin Bomber;Etherian Goblin Bomber;Etherian Goblin Bomber;Etherian Wyvern;Etherian Wyvern;Etherian Wyvern;Etherian Javelin Thrower;Etherian Javelin Thrower;Etherian Javelin Thrower;Dark Mage;Dark Mage;Old Ones Skeleton;Old Ones Skeleton;Wither Beast;Wither Beast;Drakin;Drakin;Kobold;Kobold;Kobold Glider;Kobold Glider;Ogre;Ogre;Etherian Lightning Bug;Unconscious Man;Antlion Charger;Antlion Swarmer;Antlion Larva;Pink Fairy;Green Fairy;Blue Fairy;Zombie Merman;Wandering Eye Fish;Golfer;Golfer;Zombie;Zombie;Gold Goldfish;Gold Goldfish;Windy Balloon;Dragonfly;Dragonfly;Dragonfly;Dragonfly;Dragonfly;Dragonfly;Gold Dragonfly;Seagull;Seagull;Ladybug;Gold Ladybug;Maggot;Pupfish;Grebe;Grebe;Rat;Owl;Water Strider;Gold Water Strider;Explosive Bunny;Dolphin;Turtle;Jungle Turtle;Dreadnautilus;Blood Squid;Hemogoblin Shark;Blood Eel;Blood Eel;Blood Eel;Gnome;Sea Turtle;Seahorse;Gold Seahorse;Angry Dandelion;Ice Mimic;Blood Mummy;Rock Golem;Maggot Zombie;Zoologist;Spore Bat;Spore Skeleton;Empress of Light;Cat;Dog;Amethyst Squirrel;Topaz Squirrel;Sapphire Squirrel;Emerald Squirrel;Ruby Squirrel;Diamond Squirrel;Amber Squirrel;Amethyst Bunny;Topaz Bunny;Sapphire Bunny;Emerald Bunny;Ruby Bunny;Diamond Bunny;Amber Bunny;Hell Butterfly;Lavafly;Magma Snail;Bunny;Queen Slime;Crystal Slime;Bouncy Slime;Heavenly Slime;Prismatic Lacewing;Pirates Curse;Princess;The Torch God;Chaos Ball;Vile Spit;Golden Slime;Deerclops;Stinkbug;Nerdy Slime;Scarlet Macaw;Blue Macaw;Toucan;Yellow Cockatiel;Gray Cockatiel;Shimmer Slime;Faeling;Cool Slime;Elder Slime;Clumsy Slime;Diva Slime;Surly Slime;Mystic Slime;Squire Slime;Old Shaking Chest;Clumsy Balloon Slime;Mystic Frog".split(";");
terra_data_TdNPC.meta = "|h5|s7;|h25|d7|D2|s1;|h60|d18|D2|s2;|h45|d14|D6|s3;|h2800|d15|D12|s4;|h8|d12|D0|s5;|h40|d22|D8|s5;|h100|d31|D2|s6;|h100|d16|D6|s6;|h100|d13|D10|s6;|h30|d8|D0|s6;|h30|d4|D4|s6;|h30|d4|D6|s6;|h150|d22|D2|s6;|h150|d13|D4|s6;|h150|d11|D8|s6;|h90|d20|D7|s1;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h60|d20|D8|s3;ft|h250|d10|D15|s7;|h26|d40|D6|s5;|h70|d30|D16|s8;|h1|d30|D0|s9;|h60|d12|D4|s3;|h80|d20|D6|s3;|h110|d25|D8|s3;|h40|d20|D2|s8;|h1|d20|D0|s9;|h80|d26|D8|s3;|h50|d20|D2|s8;|h1|d20|D0|s9;|h40|d35|D6|s10;|h4400|d32|D10|s11;|h600|d20|D14|s12;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h300|d36|D12|s6;|h300|d20|D18|s6;|h300|d16|D18|s6;|h48|d26|D12|s5;|h110|d34|D10|s13;|h70|d22|D9|s3;|h200|d20|D4|s8;|h5|s7;|h70|d20|D4|s3;|h100|d25|D8|s14;|h16|d13|D2|s14;|h2000|d40|D10|s15;|h34|d20|D4|s14;|h500|d20|D10|s3;|h200|d14|D8|s3;ft|h250|d10|D15|s7;|h5|s16;|h60|d25|D10|s13;|h100|d30|D6|s16;|h30|d25|D2|s16;|h50|d15|D10|s1;|h46|d35|D8|s14;|h40|d15|D4|s17;|h120|d32|D8|s14;|h34|d25|D4|s18;|h70|d30|D6|s18;|h300|d40|D2|s16;|h140|d32|D8|s14;|h40|d20|D10|s3;|h9999|d1000|D9999|s11;|h45|d10|D6|s19;|h100|d32|D100|s20;|h150|d30|D7|s1;|h100|d24|D100|s21;|h80|d20|D6|s3;|h5|s24;|h150|d55|D20|s22;|h150|d55|D20|s22;|h260|d40|D28|s3;|h130|d50|D16|s3;|h180|d60|D18|s3;|h200|d55|D18|s3;|h170|d55|D20|s1;|h160|d65|D16|s22;|h200|d80|D18|s23;|h200|d80|D18|s23;|h500|d80|D30|s25;|h400|d65|D30|s26;|h4000|d80|D10|s6;|h4000|d40|D20|s6;|h4000|d40|D20|s6;|h4000|d40|D20|s6;|h4000|d40|D20|s6;|h4000|d40|D20|s6;|h100|d45|D16|s14;|h230|d60|D32|s5;|h200|d45|D10|s6;|h200|d28|D20|s6;|h200|d26|D30|s6;|h500|d70|D36|s6;|h500|d55|D40|s6;|h500|d40|D44|s6;|h320|d70|D30|s13;|h90|d80|D22|s16;|h120|d80|D30|s18;|h350|d70|D38|s3;f|h250|d10|D15|s0;f|h250|d10|D15|s0;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h800|d60|D25|s3;|h210|d45|D14|s3;|h80|d20|D6|s3;|h1|d65|D0|s9;|h8000|d50|D12|s27;|h8000|d50|D0|s28;|h240|d30|D10|s29;|h80|d30|D6|s2;|h60|d26|D2|s6;|h60|d22|D6|s6;|h60|d18|D10|s6;|h370|d40|D30|s3;|h60|d45|D20|s14;|h220|d60|D22|s22;f|h250|d10|D15|s0;ft|h250|d10|D15|s7;|h20000|d45|D10|s30;|h23000|d50|D10|s31;|h28000|d47|D24|s32;|h7000|d30|D23|s35;|h9000|d56|D38|s33;|h9000|d52|D34|s34;|h6000|d29|D20|s36;|h40|d15|D5|s3;|h300|d40|D20|s2;|h80000|d70|D0|s37;|h80000|d55|D30|s37;|h80000|d40|D35|s37;|h200|d75|D30|s14;|h180|d70|D30|s1;|h200|d50|D20|s5;|h260|d55|D28|s3;|h150|d50|D18|s1;ft|h250|d10|D15|s7;|h200|d50|D20|s38;|h240|d65|D26|s38;|h220|d55|D22|s38;|h220|d55|D22|s38;|h30|d8|D4|s1;|h5|s7;|h5|s7;|h30|d18|D6|s14;|h160|d50|D16|s14;|h220|d80|D24|s14;|h470|d80|D30|s39;|h400|d55|D28|s39;|h300|d65|D30|s26;|h600|d50|D40|s14;|h200|d75|D30|s16;|h750|d60|D32|s14;|h750|d80|D24|s3;ft|h250|d10|D15|s7;|h50|d16|D8|s3;|h350|d65|D18|s3;|h350|d90|D40|s3;|h80|d30|D10|s3;|h80|d30|D10|s40;|h450|d70|D26|s3;|h70|d24|D10|s3;|h70|d20|D4|s3;|h200|d55|D20|s22;|h210|d70|D16|s2;|h210|d70|D16|s2;|h600|d200|D30|s8;|h40|d22|D8|s5;|h220|d65|D26|s41;|h300|d100|D30|s13;|h220|d70|D22|s5;|h300|d80|D26|s41;ft|h250|d10|D15|s7;|h200|d80|D18|s23;|h210|d70|D16|s2;|h70|d25|D10|s3;|h240|d65|D18|s22;|h200|d60|D26|s1;|h60|d12|D8|s1;|h70|d26|D12|s3;|h50|d16|D8|s3;|h40|d13|D6|s3;|h45|d13|D8|s3;|h45|d16|D4|s3;|h65|d18|D4|s2;|h60|d16|D2|s2;|h50|d18|D2|s2;|h60|d20|D0|s2;|h60|d14|D4|s2;|h250|d10|D30|s42;|h300|d35|D16|s3;|h280|d50|D28|s3;|h400|d38|D20|s3;|h400|d60|D30|s3;|h38|d12|D4|s3;|h55|d20|D12|s3;|h65|d18|D8|s3;|h60|d22|D8|s3;|h65|d28|D8|s1;|h1000|d70|D28|s5;|h280|d60|D30|s3;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h20|d20|D5|s5;|h10|d15|D2|s5;|h300|d35|D17|s3;|h450|d50|D22|s3;|h225|d30|D14|s3;|h350|d35|D20|s3;|h3000|d70|D30|s3;|h40|d20|D10|s3;|h40|d20|D10|s3;|h40|d20|D10|s3;|h40|d20|D10|s3;|h30|d20|D2|s18;|h3400|d30|D8|s43;|h50|d16|D8|s3;|h20|d9|D4|s44;|h35|d10|D5|s1;|h260|d85|D28|s14;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h5|s7;|h50|d22|D16|s5;|h42|d28|D12|s5;|h38|d30|D14|s5;|h42|d32|D6|s5;|h38|d34|D4|s5;|h400|d100|D28|s3;|h400|d100|D28|s40;|h350|d100|D40|s40;|h60|d30|D8|s3;|h60|d30|D8|s40;|h150|d50|D20|s16;|h150|d75|D20|s18;|h4000|d60|D32|s3;|h400|d85|D26|s1;|h15000|d72|D26|s45;|h25000|d64|D20|s46;|h10000|d59|D28|s47;|h10000|d59|D28|s47;|h16000|d80|D32|s48;|h300|d50|D24|s49;|h1000|d50|D30|s3;|h100|d80|D12|s5;|h700|d80|D22|s22;|h180|d40|D10|s3;|h220|d38|D16|s3;|h140|d90|D20|s18;|h230|d38|D24|s3;|h220|d60|D16|s3;|h90|d24|D4|s13;|h300|d70|D20|s13;|h1|d80|D0|s50;|h30000|d50|D14|s51;|h4000|d60|D24|s52;|h1000|d60|D20|s53;|h1|d70|D0|s50;|h1250|d30|D14|s54;|h100|d20|D10|s55;|h340|d55|D20|s22;|h550|d70|D34|s3;|h400|d55|D50|s3;|h450|d70|D40|s3;|h400|d75|D28|s3;|h500|d45|D50|s3;|h350|d65|D34|s3;|h550|d45|D50|s3;|h500|d85|D54|s3;|h400|d70|D32|s3;|h450|d65|D48|s3;|h500|d40|D54|s3;|h500|d75|D34|s3;|h400|d40|D20|s8;|h450|d35|D28|s8;|h300|d50|D18|s8;|h450|d35|D24|s8;|h200|d50|D12|s8;|h250|d60|D10|s8;|h1000|d90|D42|s3;|h200|d70|D30|s56;|h400|d60|D20|s10;|h5000|d100|D50|s3;|h400|d60|D28|s3;|h400|d60|D28|s3;|h400|d60|D28|s3;|h70|d34|D6|s3;|h70|d28|D12|s3;|h120|d24|D14|s3;|h5|s24;|h5|s24;|h5|s7;|h5|s7;|h35|d12|D2|s17;|h25|d7|D2|s1;|h5|s7;|h175|d80|D20|s1;|h500|d60|D18|s3;|h400|d52|D14|s3;|h600|d78|D16|s3;|h650|d66|D14|s3;|h450|d52|D26|s3;|h500|d60|D18|s3;|h400|d52|D14|s3;|h600|d78|D16|s3;|h650|d66|D14|s3;|h450|d52|D26|s3;|h5000|d130|D40|s26;|h50|d15|D4|s22;|h75|d16|D6|s2;|h60|d20|D4|s2;|h40|d20|D6|s3;|h60|d15|D8|s3;|h34|d20|D14|s3;|h115|d23|D0|s3;|h65|d18|D10|s3;|h70|d22|D10|s3;|h14000|d120|D34|s57;|h1200|d100|D32|s3;|h26000|d50|D40|s58;|h5000|d65|D14|s59;|h1800|d80|D38|s26;|h1250|d90|D44|s22;|h45|d14|D6|s3;|h45|d14|D6|s3;|h25|d7|D2|s1;|h23|d6|D2|s1;|h29|d8|D3|s1;|h22|d5|D1|s1;|h5|s7;|h600|d65|D18|s3;|h700|d52|D24|s3;|h500|d78|D14|s3;|h900|d100|D32|s25;|h750|d90|D26|s3;|h3500|d140|D50|s3;|h13000|d110|D38|s57;|h34000|d120|D38|s60;|h18000|d120|D56|s61;|h1200|d60|D28|s62;|h1800|d80|D26|s3;|h1800|d100|D42|s3;|h900|d70|D30|s3;|h2500|d100|D40|s3;|h450|d75|D8|s63;ft|h250|d10|D15|s7;f|h250|d10|D15|s0;|h5|s64;|h5|s65;f|h5|s66;|h5|s64;|h5|s67;|h5|s67;|h5|s7;|h5|s7;|h5|s68;|h5|s7;|h5|s68;|h5|s7;|h5|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h60000|d100|D50|s69;|h1|d100|D0|s70;|h100|d100|D100|s71;|h100|d120|D100|s71;|h5|s66;|h5|s6;f|h250|d10|D15|s0;f|h5|s1;|h200|d120|D30|s41;|h210|d45|D14|s3;|h210|d45|D14|s3;|h350|d50|D25|s3;|h350|d50|D25|s3;|h300|d75|D50|s3;|h1000|d75|D20|s72;|h750|d80|D30|s3;|h400|d40|D34|s3;|h200|d10|D40|s73;|h300|d60|D16|s74;|h600|d75|D38|s3;|h350|d65|D30|s75;|h600|d85|D30|s3;|h100|d50|D100|s75;|h5000|d60|D20|s75;|h3500|d60|D20|s75;|h10000|d80|D0|s76;|h45000|D50|s79;|h25000|D40|s78;|h50000|D70|s77;|h500|d5|D5|s80;|h100|d60|D0|s81;|h400|s82;|h1200|d80|D10|s6;|h1200|d80|D10|s6;|h1200|d80|D10|s6;|h300|d120|D50|s85;|h300|d70|D0|s95;|h1500|d70|D38|s96;|h1500|d70|D38|s96;|h800|d70|D40|s3;|h200|d80|D10|s26;|h700|d80|D34|s3;|h10000|d120|D1000|s6;|h10000|d80|D1000|s6;|h10000|d50|D0|s6;|h800|d55|D32|s3;|h800|d80|D28|s75;|h700|d80|D34|s39;|h600|d70|D26|s74;|h800|d90|D30|s3;|h1300|d75|D20|s97;|h330|d70|D34|s85;|h20000|D20|s94;|h850|d90|D46|s26;|h700|d80|D30|s3;|h800|d100|D40|s3;|h1000|d100|D44|s3;|h500|d75|D20|s3;|h200|d50|D6|s3;|h700|d90|D34|s3;|h45|d14|D6|s3;|h50|d16|D8|s3;|h50|d16|D8|s3;|h40|d13|D6|s3;|h45|d13|D8|s3;|h45|d16|D4|s3;|h38|d12|D4|s3;|h400|s83;|h400|s83;|h32000|d50|D42|s84;|h10000|D35|s84;ft|h250|d10|D15|s7;|h5|s24;|h5|s7;|h5|s65;|h5|s7;f|h5|s1;|h5|s7;f|h5|s66;|h60|d20|D8|s3;|h55|d20|D12|s3;|h65|d18|D8|s3;|h60|d22|D8|s3;f|h250|d10|D30|s7;|h10000|d100|D15|s6;|h10000|d50|D30|s6;|h10000|d50|D30|s6;|h10000|d50|D30|s6;|h10000|d50|D30|s6;|h10000|d50|D30|s6;|h700|d70|D30|s3;|h400|d60|D22|s3;|h270|d70|D14|s3;|h4000|d100|D34|s3;|h75|d21|D5|s3;|h110|d31|D7|s16;|h550|d70|D40|s3;|h350|d100|D80|s85;|h500|d65|D24|s3;|h600|d68|D28|s3;|h75|d21|D5|s3;|h2000|d80|D26|s3;|h180|d50|D18|s86;|h3500|d90|D34|s87;|h3500|d90|D34|s87;|h3500|d90|D34|s87;|h3500|d90|D34|s87;|h6000|d80|D30|s88;|h200|D30|s89;|h700|d50|D14|s90;|h400|d30|D20|s3;|h70|d22|D10|s3;|h110|d30|D18|s3;|h40|d24|D8|s91;f|h5|s66;f|h5|s66;f|h5|s66;f|h5|s66;|h1000|s92;|h75|d20|D8|s3;|h50|d28|D14|s22;|h50|D100|s93;|h2000|d30|D20|s75;|h20000|D20|s94;|h50|d28|D6|s3;|h50|d28|D6|s3;|h50|d16|D12|s39;|h50|d16|D12|s39;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h65|d18|D10|s3;|h20000|D20|s94;|h110|d38|D16|s3;|h90|d34|D12|s44;|h500|d58|D18|s6;|h500|d54|D28|s6;|h500|d50|D34|s6;|h60|d18|D0|s6;|h60|d7|D12|s6;|h60|d7|D14|s6;|h1|d100|D0|s9;|h20000|D20|s94;|h1000|d80|D28|s3;|h1|d120|D0|s99;|h2000|d60|D40|s3;|h2000|d90|D30|s86;|h400|d120|D0|s100;|h500|d30|D0|s101;|h180|d50|D26|s3;|h250|d60|D30|s3;|h220|d64|D32|s3;|h300|d54|D32|s3;|h350|d52|D28|s3;|h350|d52|D28|s3;|h320|d66|D24|s3;|h320|d66|D24|s40;|h270|d65|D34|s3;|h220|d40|D20|s8;|h400|d14|D20|s3;|h50|d14|D5|s1;|h200|d14|D8|s3;|h50|d15|D5|s1;|h5|s7;|h5|s7;|h5|s7;|h5000|d40|D30|s102;|h360|d50|D20|s103;|h380|d60|D24|s103;|h400|d64|D22|s103;|h450|d54|D26|s103;|h50|d30|D6|s26;|h10|d30|D10|s104;f|h1000|d30|D14|s105;|h5|D20|s106;ft|h250|d10|D15|s7;|h50000|d80|D38|s110;|h30|d18|D14|s107;|h170|d46|D20|s107;|h560|d70|D28|s107;|h50|d26|D16|s107;|h200|d55|D26|s107;|h700|d75|D34|s107;|h60|d30|D4|s108;|h180|d75|D16|s108;|h600|d100|D30|s108;|h60|d30|D18|s107;|h300|d60|D28|s107;|h1000|d80|D38|s107;|h800|d40|D18|s109;|h4000|d90|D38|s109;|h25|d18|D12|s107;|h480|d70|D22|s107;|h500|d50|D30|s107;|h1400|d80|D40|s107;|h900|d60|D30|s107;|h3000|d90|D40|s107;|h260|d60|D26|s107;|h800|d80|D32|s107;|h170|d50|D16|s108;|h580|d80|D32|s108;|h5000|d70|D34|s107;|h13000|d90|D40|s107;|h500|d80|D36|s111;f|h250|d10|D15|s0;|h80|d25|D10|s3;|h60|d29|D8|s44;|h30|d10|D2|s3;|h5|s112;|h5|s112;|h5|s112;|h400|d40|D20|s3;|h300|d35|D18|s44;ft|h250|d10|D15|s7;f|h250|d10|D15|s0;|h45|d14|D6|s3;|h45|d14|D6|s3;|h5|s16;|h5|s7;|h1|s113;|h5|s114;|h5|s114;|h5|s114;|h5|s114;|h5|s114;|h5|s114;|h5|s114;|h5|s7;|h5|s68;|h5|s115;|h5|s115;f|h5|s66;|h5|s16;|h5|s7;|h5|s68;|h5|s7;|h5|s24;|h5|s116;|h5|s116;|h5|s7;|h5|s16;|h5|s7;|h5|s7;|h7000|d55|D24|s117;|h750|d60|D16|s5;|h5000|d70|D30|s107;|h6000|d90|D0|s6;|h6000|d60|D30|s6;|h6000|d50|D40|s6;|h25|d10|D0|s3;|h5|s7;|h5|s118;|h5|s118;|h50|d15|D0|s119;|h500|d80|D30|s25;|h180|d60|D18|s3;|h1000|d85|D35|s3;|h45|d14|D6|s3;ft|h250|d10|D15|s7;|h16|d13|D2|s14;|h60|d20|D8|s3;|h70000|d80|D50|s120;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s7;|h5|s65;|h5|s64;|h5|s67;ft|h250|d10|D15|s7;|h18000|d60|D26|s121;|h150|d40|D35|s1;|h150|d40|D35|s1;|h120|d50|D30|s14;|h5|s65;|h500|d75|D22|s122;ft|h250|d10|D15|s7;|h20|d10|D15|s7;|h1|d20|D0|s9;|h1|d65|D0|s9;|h300|d5|D5|s1;|h7000|d20|D10|s123;|h5|s115;ft|h250|d10|D15|s7;|h5|s24;|h5|s24;|h5|s24;|h5|s24;|h5|s24;|h80|d20|D5|s1;|h5|s64;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;ft|h250|d10|D15|s7;f|h250|D10|s1;|h1|s125;|h5|s7".split(";");
terra_data_TdRecipe.meta = "8x3:23+9/w;974x3:8x3+664;974x3:8x3+833;974x3:8x3+834;974x3:8x3+835;4383x3:8x3+3272;4383x3:8x3+3274;4383x3:8x3+3275;4383x3:8x3+3338;4384x3:8x3+275;4385x3:8x3+61;4385x3:8x3+833;4385x3:8x3+3274;4386x3:8x3+836;4386x3:8x3+835;4386x3:8x3+3275;4387x3:8x3+409;4387x3:8x3+834;4387x3:8x3+3338;4388x25:8x25+331;5293x3:8x3+183;3114x3:3111+9/w;433x3:8x3+173;523x33:8x33+522;1333x33:8x33+1332;3045x10:8x10+662;427x10:8x10+177;428x10:8x10+178;429x10:8x10+179;432x10:8x10+180;430x10:8x10+181;431x10:8x10+182;1245x20:8x20+999;5378x33:931x33+522;5379x10:931x10+662;5377:931+3002;966:9x10+8x5/w;3048:9x10+974x5/w;3047:9x10+433x5/w;3046:9x10+523x5/w;3049:9x10+1333x5/w;3050:9x10+3045x5/w;3723:9x10+2274x5/w;3724:9x10+3004x5/w;4689:9x10+4383x5/w;4690:9x10+4384x5/w;4691:9x10+4385x5/w;4692:9x10+4386x5/w;4693:9x10+4387x5/w;4694:9x10+4388x5/w;5299:183x10+5293x5;5357:9x10+5353x5/w;2751x20:2701x20+522@125;2752x20:2701x20+433@125;2753x20:2701x20+664x10@125;2754x20:2701x20+1332@125;2755x20:2701x20+2274x2@125;985:965x10;3005:2996x10;3078x3:150;3080:3078x10;3077x30:225@86;3079:3077x10;2590x5:353x5+23+225+8;1130:168+2431@16;2586x5:168x5+23;235:166+23;2896:167+23;3116x2:168x2+3111;3115:166+3111;3547:167+3111;4423:166+3380;4908:166+2x25;4909:4908+23;4909:235+2x25;1338:2019+167;286x5:282x5+23;3112x5:282x5+3111;3191:2002+75;2243x2:170@17;2244:170@17;351:170@17;353:351@94;357:5+261@96;3195:3192+3193+3194@96;1787:1725x10@17;5092:68x8@96;5092:1330x8@96;5093:2121x2@96;4033:2121@96;4032:2123@96;4032:2122@96;4032:4374@96;4031:2015@96;4031:2017@96;4031:2016@96;4031:2205@96;4031:4359@96;4024:2018@96;4024:3563@96;4014:2019@96;4019:2006@96;4022:2889@96;4022:2890@96;4022:2892@96;4022:2894@96;4022:3564@96;4022:2893@96;4022:2895@96;4022:2891@96;4022:4274@96;4022:4340@96;4022:4362@96;4022:4482@96;4022:4419@96;2425:2290@96;2425:2297@96;2425:2299@96;2427:2300@18;2427:2298@18;2427:2301@18;2427:4401@18;2426:2316@96;4403:4402@96;5009:126@622;4614:4009+31@96;4617:4283+31+593@96;4615:4023x2+31@96;4616:4291+31@96;4618:4293+31@96;4619:4294+4287+31@96;4620:4292+4294+31@96;4621:4285+4296+31@96;4622:4284+4289+31@96;4624:4009x2+31@96;4625:4009x3+356@96;4623:4297+4288+31@96;4034:2303x2@96;4034:2317x2@96;4034:2305x2@96;4034:2304x2@96;4034:2313x2@96;4034:2318x2@96;4034:2312x2@96;4034:2306x2@96;4034:2319x2@96;4034:2314x2@96;4034:2302x2@96;4034:2315x2@96;4034:2307x2@96;4034:2310x2@96;4034:2309x2@96;4034:2321x2@96;4034:2311x2@96;968:967+9/w;31x2:170@17;126:31/q;1134:31/h;422x10:126x10+501x2+369;423x10:126x10+370+59;3477x10:126x10+1246+2171;28x2:5+23x2+31x2@13;227:5+183+3111+31@13;188:28x2+183@13;499x3:126x3+501x3+502@13;3544x4:499x4+3457+3458+3459+3456@13;189:110x2+183@13;2209x15:500x15+75+502x3+526@13;2756:126+313+314+315+317+316+2358+318@13;5099:313+314+315+317+316+2358+318;288:126+318+317+173@13;289:126+313+5@13;290:126+315+276@13;291:126+317+275@13;292:126+313+11@13;292:126+313+700@13;293:126+314+313+75@13;294:126+314+316+75@13;295:126+313+315+320@13;296:126+315+314+13@13;296:126+315+314+702@13;297:126+315+314@13;298:126+313+183@13;299:126+313+315@13;300:126+316+68@13;300:126+316+1330@13;301:126+316+276@13;302:126+317+319@13;303:126+313+38@13;304:126+313+315+319@13;305:126+318+316+315+320@13;2354:126+1127+317@13;2356:126+999+314+2358+317@13;2325:126+315+2358+314@13;2326:126+154+316+2358@13;2329:126+2358+150x10@13;2355:126+317+275@13;2322:126+323+315@13;2327:126+2358+317@13;2323:126+2305+313@13;2324:126+2304+313@13;2328:126+2311+314@13;2344:126+2313+314@13;2345:126+2310+314+2358+317@13;2346:126+2303+315@13;2348:126+2312+2315x2+318@13;2347:126+2319+316@13;2349:126+2318+316@13;2350:126+2309+313@13;2997x3:126x3+2309+315@13;2351:126+2317+318@13;2352:126+2307+2358@13;2353:126+2321+316@13;2359:126+2306+2358@13;4477:126+317+4361+4412@13;4478:126+317+4361+4413@13;4479:126+317+4361+4414@13;4870:2350+2315@13;5211:126+318+315+314+62x5@13;1359:126+209@243;1354:126+174x3@243;1340:126+1339x5@243;1355:126+1348x5@243;1356:126+1332x2@243;1353:126+522x2@243;1357:126+1346x5@243;1358:126+1345x5@243;5068:225x10+5070x8+19x8@86;5068:225x10+5070x8+706x8@86;5069:5070x6+19x10@18;5069:5070x6+706x10@18;5120:5070x3+56x5+38@26;5120:5070x3+880x5+38@26;3092:520x15@18;3091:521x15@18;949x15:593;3103:40x3996@125;3104:97x3996@125;40x25:9+3@18/w;41x10:40x10+8;988x10:40x10+974;51x10:40x10+75;47x5:40x5+69@16;47x5:40x5+1330@16;265x100:40x100+175@16;545x150:40x150+522@134;1334x150:40x150+1332@134;516x200:40x200+501x3+526@134;1341x35:40x35+1339@134;1235x150:1006@134;1310x100:209;3009x100:502;3010x100:522;3011x100:1332;234x70:97x70+117@16;278x70:97x70+21@16;4915x70:97x70+705@16;515x100:97x100+502@134;546x150:97x150+522@134;1335x150:97x150+1332@134;1179x60:97x60+1006@134;1302x50:1432x50+1344@18;1349x50:1432x50+1345@18;1350x50:1432x50+1346@18;1351x50:1432x50+1347@18;1352x50:1432x50+1348@18;1342x50:1432x50+1339@18;4447:4459/q;4448:4459/l;4449:4459/h;4459:4447;4459:4448;4459:4449;4824:4827/q;4825:4827/l;4826:4827/h;4827:4824;4827:4825;4827:4826;4457x100:773x100+1552@247;4458x100:774x100+1552@247;67x5:60@13;2886x5:2887@13;5438:5395x3+154x3+172x3@13;287x50:279x50+67;287x50:279x50+2886;94x2:9;9:94x2;4416x2:129;129:4416x2;2518x2:2504;2504:2518x2;2566x2:2503;2503:2566x2;632x2:620;620:632x2;631x2:619;619:631x2;913x2:911;911:913x2;633x2:621;621:633x2;2744x2:276;276:2744x2;1702x2:170;170:1702x2;1796x2:1725;1725:1796x2;1818x2:1729;1729:1818x2;634x2:154;154:634x2;2549x2:183;183:2549x2;2581x2:762;762:2581x2;2627x2:1344;1344:2627x2;2628x2:824;824:2628x2;2629x2:9@304;9:2629x2@304;2630x2:1125;1125:2630x2;1457x2:192;192:1457x2;3144x2:3100;3100:3144x2;3146x2:3087;3087:3146x2;3145x2:3066;3066:3145x2;2822x2:2860;2860:2822x2;3903x2:3234;3234:3903x2;3945x2:4139;4139:3945x2;3905x2:2260;2260:3905x2;3906x2:1101;1101:3906x2;3907x2:763;763:3907x2;3957x2:3955;3955:3957x2;3908x2:664;664:3908x2;4159x2:4229;4229:4159x2;4180x2:4230;4230:4180x2;4201x2:4231;4231:4201x2;4222x2:4232;4232:4222x2;4311x2:4051;4051:4311x2;4580x2:4564;4564:4580x2;5162x2:5306;5306:5162x2;5183x2:3738;3738:5183x2;5204x2:5215;5215:5204x2;5292x2:4392;4392:5292x2;1384x2:134;134:1384x2;1386x2:137;137:1386x2;1385x2:139;139:1385x2;1389x2:9@300;9:1389x2@300;1388x2:145@300;145:1388x2@300;1418x2:9@300;9:1418x2@300;1387x2:717@300;717:1387x2@300;1431:31+75;1993:31+1992;2005:31+2004;4848:31+4847;5351:31+5350;4695:31+520;4696:31+521;4697:31+575;4698:31+549;4699:31+548;4700:31+547;1859:29+85x4;344:225x5+8@18;342:8+9x3@18/w;341:22x3+170x2+8@16/i;347:154x10+8@18;3782x3:3186x3+169@125/s;3182:3186@125/q;3184:3186@125/l;3185:3186@125/h;2693:170@125/q;2169x4:2693@18;2693:2169x4@18;2694:170@125/l;2170x4:2694@18;2694:2170x4@18;2787:170@125/h;2788x4:2787@18;2787:2788x4@18;3754:170+169@125;3752x4:3754@18;3754:3752x4@18;3755:170+593@125;3753x4:3755@18;3755:3753x4@18;4277x10:170x10+75@125;4279x4:4277@18;4277:4279x4@18;4278x10:170x10+75@125;4280x4:4278@18;4278:4280x4@18;5291x4:4392@18;4392:5291x4@18;4490x4:4640@18;4640:4490x4@18;4491x4:4641@18;4641:4491x4@18;4492x4:4642@18;4642:4492x4@18;4493x4:4643@18;4643:4493x4@18;4494x4:4644@18;4644:4494x4@18;4495x4:4645@18;4645:4495x4@18;4647x4:4646@18;4646:4647x4@18;4496x4:4349@18;4349:4496x4@18;4497x4:4350@18;4350:4497x4@18;4498x4:4351@18;4351:4498x4@18;4499x4:4352@18;4352:4499x4@18;4500x4:4353@18;4353:4500x4@18;4503x4:150@18;150:4503x4@18;4529x4:62@18;62:4529x4@18;4531x4:62@18;62:4531x4@18;4530x4:195@18;195:4530x4@18;4532x4:195@18;195:4532x4@18;3340x4:3272@18;3272:3340x4@18;3341x4:3274@18;3274:3341x4@18;3342x4:3275@18;3275:3342x4@18;3343x4:3338@18;3338:3343x4@18;3344x4:3276@18;3276:3344x4@18;3345x4:3277@18;3277:3345x4@18;3346x4:3339@18;3339:3346x4@18;3348x4:3347@18;3347:3348x4@18;663x4:662@18;662:663x4@18;2695:1345+170@125;2696x4:2695@18;2695:2696x4@18;2697:1345+170@125;2698x4:2697@18;2697:2698x4@18;3748:3743+3744+3745;4090x4:2625@283;4090x4:4071@283;4090x4:4072@283;4090x4:4073@283;4090x4:2626@283;4090x4:275@283;148:105@125/q;148:713@125/q;5322:57x3+8@18;5322:1257x3+8@18;5323:4767+5309@18;5295:213+3506+331x12+210x3@18;5295:213+3500+331x12+210x3@18;752x4:751@18;751:752x4@18;222:133x5@17;350:133x4@17;356:133x2@17;4326:133x2@17;170:169x2@17/s;392x4:170@18;170:392x4@18;1267x20:392x20+181@18;1268x20:392x20+180@18;1269x20:392x20+177@18;1270x20:392x20+179@18;1271x20:392x20+178@18;4260x20:392x20+999@18;1272x50:392x50+181+180+177+179+178@18;1970x20:170x20+181@18;2679x4:1970@18;1970:2679x4@18;2680x4:1970@18;1970:2680x4@18;1971x20:170x20+180@18;2689x4:1971@18;1971:2689x4@18;2690x4:1971@18;1971:2690x4@18;1972x20:170x20+177@18;2687x4:1972@18;1972:2687x4@18;2688x4:1972@18;1972:2688x4@18;1973x20:170x20+179@18;2683x4:1973@18;1973:2683x4@18;2684x4:1973@18;1973:2684x4@18;1974x20:170x20+178@18;2685x4:1974@18;1974:2685x4@18;2686x4:1974@18;1974:2686x4@18;1975x20:170x20+182@18;2681x4:1975@18;1975:2681x4@18;2682x4:1975@18;1975:2682x4@18;1976x20:170x20+999@18;2677x4:1976@18;1976:2677x4@18;2678x4:1976@18;1976:2678x4@18;4238x2:134@283;4239x2:137@283;4240x2:139@283;135x4:134@283;134:135x4@283;1379x4:134@283;134:1379x4@283;1378x4:134@283;134:1378x4@283;138x4:137@283;137:138x4@283;1383x4:137@283;137:1383x4@283;1382x4:137@283;137:1382x4@283;140x4:139@283;139:140x4@283;1381x4:139@283;139:1381x4@283;1380x4:139@283;139:1380x4@283;2119:3@283;2433x4:2119@18;2119:2433x4@18;4962:3@283;2120:169@283;2173x5:3x5+12@283;2432x4:2173@18;2173:2432x4@18;2692x5:3x5+699@283;2691x4:2692@18;2692:2691x4@18;775:3x2+23@217;1102x4:1101@18;1101:1102x4@18;129:3x2@17;130x4:129@18;129:130x4@18;4415:129x6@283;131:133x2@17;132x4:131@18;131:132x4@18;145x5:3x5+12@17;146x4:145@18;145:146x4@18;3951x5:3x5+11@17;3952x4:3951@18;3951:3952x4@18;3953x5:3x5+700@17;3954x4:3953@18;3953:3954x4@18;144x4:143@18;143:144x4@18;143x5:3x5+14@17;142x4:141@18;141:142x4@18;141x5:3x5+13@17;717x5:3x5+699@17;720x4:717@18;717:720x4@18;721x4:718@18;718:721x4@18;718x5:3x5+701@17;722x4:719@18;719:722x4@18;719x5:3x5+702@17;214x5:3x5+174@17;3067x4:214@18;214:3067x4@18;4533x4:174@18;174:4533x4@18;4534x4:174@18;174:4534x4@18;4535x4:174@18;174:4535x4@18;4536x4:174@18;174:4536x4@18;192x5:3x5+173@17;330x4:192@18;192:330x4@18;4507x4:173@18;173:4507x4@18;606x4:577@18;577:606x4@18;594:593x2@18;595x4:594@18;594:595x4@18;4489x4:593@18;593:4489x4@18;883:664x2@18;4506x4:664@18;664:4506x4@18;884x4:883@18;883:884x4@18;587x4:586@18;586:587x4@18;592x4:591@18;591:592x4@18;607:169@17;608x4:607@18;607:608x4@18;4051:3271@17;4053x4:4051@18;4051:4053x4@18;3273x4:3271@18;3271:3273x4@18;4565x4:4564@18;4564:4565x4@18;4547:4564@106;4564:4547@106;4548x4:4547@18;4547:4548x4@18;412:409x2@17;417x4:412@18;412:417x4@18;4488x4:409@18;409:4488x4@18;4525x4:409@18;409:4525x4@18;4526x4:409@18;409:4526x4@18;4527x4:409@18;409:4527x4@18;4528x4:409@18;409:4528x4@18;609:61x2@17;610x4:609@18;609:610x4@18;4486x4:61@18;61:4486x4@18;4513x4:61@18;61:4513x4@18;4514x4:61@18;61:4514x4@18;4515x4:61@18;61:4515x4@18;4516x4:61@18;61:4516x4@18;4050:836x2@17;4052x4:4050@18;4050:4052x4@18;4509x4:836@18;836:4509x4@18;4517x4:836@18;836:4517x4@18;4518x4:836@18;836:4518x4@18;4519x4:836@18;836:4519x4@18;4520x4:836@18;836:4520x4@18;413:3+172@17;418x4:413@18;413:418x4@18;414:3+176@17;419x4:414@18;414:419x4@18;611x10:424+133x10@17;615x4:611@18;611:615x4@18;612x10:424+169x10@17;616x4:612@18;612:616x4@18;613x10:424+3x10+255@17;617x4:613@18;613:617x4@18;614x10:424+3x10@17;618x4:614@18;614:618x4@18;3100x5:3x5+116@17;3101x4:3100@18;3100:3101x4@18;2793x5:880+836x5@17;2790x4:2793@18;2793:2790x4@18;415x5:3x5+364@17;420x4:415@18;415:420x4@18;416x5:3x5+365@17;421x4:416@18;416:421x4@18;604x5:3x5+366@17;605x4:604@18;604:605x4@18;1589x5:3x5+1104@17;1590x4:1589@18;1589:1590x4@18;1591x5:3x5+1105@17;1592x4:1591@18;1591:1592x4@18;1593x5:3x5+1106@17;1594x4:1593@18;1593:1594x4@18;2792x5:3x5+947@17;2789x4:2792@18;2792:2789x4@18;2794x25:3x25+1552@17;2791x4:2794@18;2794:2791x4@18;3461x5:3x5+3460@17;3472x4:3461@18;3461:3472x4@18;5409x4:5401@18;5401:5409x4@18;5410x4:5402@18;5402:5410x4@18;5411x4:5403@18;5403:5411x4@18;5412x4:5404@18;5404:5412x4@18;5413x4:5405@18;5405:5413x4@18;5414x4:5406@18;5406:5414x4@18;5415x4:5407@18;5407:5415x4@18;5416x4:5408@18;5408:5416x4@18;5418x4:5417@18;5417:5418x4@18;5420x4:5419@18;5419:5420x4@18;5422x4:5421@18;5421:5422x4@18;5424x4:5423@18;5423:5424x4@18;5426x4:5425@18;5425:5426x4@18;5428x4:5427@18;5427:5428x4@18;5436x4:5435@18;5435:5436x4@18;5434x4:5433@18;5433:5434x4@18;5432x4:5431@18;5431:5432x4@18;5430x4:5429@18;5429:5430x4@18;5439x10:4354+133x10@17;5440x10:4389+133x10@17;5441x10:4377+133x10@17;5442x10:4378+133x10@17;5443x10:5127+133x10@17;5444x10:5128+133x10@17;5397x4:5349@18;5349:5397x4@18;5398:5349+3@17;5399x4:5398@18;5398:5399x4@18;5445x4:5439@18;5439:5445x4@18;5446x4:5440@18;5440:5446x4@18;5447x4:5441@18;5441:5447x4@18;5448x4:5442@18;5442:5448x4@18;5449x4:5443@18;5443:5449x4@18;5450x4:5444@18;5444:5450x4@18;3573x5:3458+3x5@412;3574x5:3456+3x5@412;3575x5:3457+3x5@412;3576x5:3459+3x5@412;3234x5:3x5+502@133;3238x4:3234@18;3234:3238x4@18;2435x5:3x5+275/q;5306x10:3x10+275+2625/q;5307x4:5306@18;5306:5307x4@18;5396x4:5395@18;5395:5396x4@18;577x5:56+61x5@17;176:2/q;4487x4:176@18;176:4487x4@18;30x4:2@18;2:30x4@18;4501x4:2@18;2:4501x4@18;4510x4:2@18;2:4510x4@18;4511x4:2@18;2:4511x4@18;4521x4:2@18;2:4521x4@18;4522x4:2@18;2:4522x4@18;4523x4:2@18;2:4523x4@18;4524x4:2@18;2:4524x4@18;26x4:3@18;3:26x4@18;4502x4:3@18;3:4502x4@18;4512x4:3@18;3:4512x4@18;4537x4:3@18;3:4537x4@18;4538x4:3@18;3:4538x4@18;4539x4:3@18;3:4539x4@18;4540x4:3@18;3:4540x4@18;1723x4:9@304;9:1723x4@304;3584x4:9@304;9:3584x4@304;93x4:9@18;9:93x4@18;623x4:620@18;620:623x4@18;622x4:619@18;619:622x4@18;927x4:911@18;911:927x4@18;624x4:621@18;621:624x4@18;2505x4:2503@18;2503:2505x4@18;2506x4:2504@18;2504:2506x4@18;5216x4:5215@18;5215:5216x4@18;764x4:183@18;183:764x4@18;1726x4:1725@18;1725:1726x4@18;1728x4:1727@18;1727:1728x4@18;1730x4:1729@18;1729:1730x4@18;3751x4:1344@18;1344:3751x4@18;2861x4:2860@18;2860:2861x4@18;3760x4:3736@18;3736:3760x4@18;3761x4:3737@18;3737:3761x4@18;3762x4:3738@18;3738:3762x4@18;3239:9x8+22x4@18/wi;3240:9x12+22x4@283/wi;25:9x6@18;34:9x4@18;48:9x8+22x2@18/i;2827:9x6+206@18;32:9x8@18;36:9x10;333:154x4+9x15+149@106;224:9x15+225x5@106;334:9x16@106;354:9x20+149x10@106;2519:2504x14@106;2520:2504x15+225x5@106;2521:2504x8@106;2536:2504x20+149x10@106;2522:2504x5+8x3@18;2523:2504x4+8@18;2524:2504x4@18;2525:2504x4+8x4+85@16;2526:2504x8+22x2@18/i;2601:22x3+170x6+2504x10@106/i;2528:2504x6@18;2529:2504x16@106;2533:8+2504x3@18;2530:2504x6+8@18;2531:154x4+2504x15+149@106;2527:2504x5+225x2@106;2850:2504x6+206@18;4118:2504x6@106;2532:2504x8@18;2534:2504x10;4717x2:2503@106;2552:2503x14@106;2553:2503x15+225x5@106;2554:2503x20+149x10@106;2555:2503x5+974x3@18;2556:2503x4+974@18;2557:2503x4@18;2558:2503x4+974x4+85@16;2559:2503x8+22x2@18/i;2560:22x3+170x6+2503x10@106/i;2561:2503x6@18;2562:2503x16@106;2563:974+2503x3@18;2564:2503x6+974@18;2565:154x4+2503x15+149@106;858:2503x5+225x2@106;2852:2503x6+206@18;4119:2503x6@106;677:2503x8@18;673:2503x10;4718x2:620@106;2597:22x3+170x6+620x10@106/i;651:620x6@18;629:620x4@18;626:620x8+22x2@18/i;2829:620x6+206@18;639:620x8@18;636:620x10;642:154x4+620x15+149@106;645:620x15+225x5@106;648:620x16@106;2026:620x20+149x10@106;2077:620x14@106;2050:620x4+8@18;2038:620x6+8@18;2060:620x4+8x4+85@16;2087:8+620x3@18;2098:620x5+8x3@18;2399:620x5+225x2@106;4097:620x6@106;650:619x6@18;628:619x4@18;2593:22x3+170x6+619x10@106/i;625:619x8+22x2@18/i;2828:619x6+206@18;638:619x8@18;635:619x10;641:154x4+619x15+149@106;644:619x15+225x5@106;647:619x16@106;2021:619x20+149x10@106;2073:619x14@106;2033:619x6+8@18;2046:619x4+8@18;2056:619x4+8x4+85@16;2083:8+619x3@18;2093:619x5+8x3@18;2398:619x5+225x2@106;4096:619x6@106;2604:22x3+170x6+911x10@106/i;912:911x6@18;915:911x4@18;914:911x8+22x2@18/i;2835:911x6+206@18;917:911x8@18;916:911x10;919:154x4+911x15+149@106;920:911x15+225x5@106;2127:911x14@106;2136:911x20+149x10@106;918:911x16@106;2142:911x4+8x4+85@16;2150:911x5+8x3@18;2146:911x6+8@18;2132:8+911x3@18;2154:911x4+8@18;2401:911x5+225x2@106;4105:911x6@106;2602:22x3+170x6+621x10@106/i;652:621x6@18;630:621x4@18;627:621x8+22x2@18/i;2830:621x6+206@18;640:621x8@18;637:621x10;643:154x4+621x15+149@106;646:621x15+225x5@106;649:621x16@106;2027:621x20+149x10@106;2078:621x14@106;2039:621x6+8@18;2051:621x4+8@18;2061:621x4+8x4+85@16;2088:8+621x3@18;2099:621x5+8x3@18;2400:621x5+225x2@106;4098:621x6@106;5279:5215x20@18;5280:5215x30@18;5281:5215x25@18;5284:5215x7@18;5283:5215x8@18;5282:5215x10@18;5190:5215x14@106;5191:5215x15+225x5@106;5192:5215x20+149x10@106;5193:5215x16@106;5194:5215x5+8x3@18;5195:5215x4+8@18;5196:5215x4@18;5197:5215x4+8x4+85@16;5198:5215x8+22x2@18/i;5199:5215x10+22x3+170x6@106/i;5200:5215x6@18;5201:8+5215x3@18;5202:5215x6+8@18;5203:5215x15+154x4+149@106;5205:5215x6+206@18;5206:5215x5+225x2@106;5207:5215x8@18;5208:5215x10;5210:5215x6@106;4721x2:183@106;2537:183x14@106;2538:183x15+225x5@106;2539:183x8@106;2540:183x20+149x10@106;2541:183x5+8x3@18;2542:183x4+8@18;810:183x4@18;2543:183x4+8x4+85@16;2544:183x8+22x2@18/i;2599:22x3+170x6+183x10@106/i;818:183x6@18;2545:183x16@106;2547:8+183x3@18;2546:183x6+8@18;2548:154x4+183x15+149@106;2413:183x5+225x2@106;2851:183x6+206@18;4103:183x6@106;2550:183x8@18;814:183x10;2567:762x14@220;2568:762x15+225x5@220;2569:762x20+149x10@220;2570:762x5+8x3@220;2571:762x4+8@220;2572:762x4@220;2573:762x4+8x4+85@220;2574:762x8+22x2@220/i;2575:22x3+170x6+762x10@220/i;2576:762x6@220;2577:762x16@220;2578:8+762x3@220;2579:762x6+8@220;2580:154x4+762x15+149@220;2582:762x5+225x2@220;2853:762x6+206@220;4120:762x6@220;2583:762x8@220;815:762x10@220;3159:3100x14@106;3162:3100x15+225x5@106;3165:3100x20+149x10@106;3168:3100x5+8x3@18;3171:3100x4+8@18;3174:3100x4@18;3177:3100x4+8x4+85@16;3180:3100x8+22x2@18/i;3126:22x3+170x6+3100x10@106/i;3129:3100x6@18;3132:3100x16@106;3135:8+3100x3@18;3138:3100x6+8@18;3141:154x4+3100x15+149@106;3150:3100x5+225x2@106;3147:3100x6+206@18;4141:3100x6@106;3153:3100x8@18;3156:3100x10;3066:3081@18;3083x4:3066@18;3066:3083x4@18;3082x4:3081@18;3081:3082x4@18;4554x2:3066@106;3160:3066x14@106;3163:3066x15+225x5@106;3166:3066x20+149x10@106;3169:3066x5+8x3@18;3172:3066x4+8@18;3175:3066x4@18;3178:3066x4+8x4+85@16;3181:3066x8+22x2@18/i;3127:22x3+170x6+3066x10@106/i;3130:3066x6@18;3133:3066x16@106;3136:8+3066x3@18;3139:3066x6+8@18;3142:154x4+3066x15+149@106;3151:3066x5+225x2@106;3148:3066x6+206@18;4123:3066x6@106;3154:3066x8@18;3157:3066x10;3087:3086@18;3089x4:3087@18;3087:3089x4@18;3088x4:3086@18;3086:3088x4@18;4719x2:3087@106;3161:3087x14@106;3164:3087x15+225x5@106;3167:3087x20+149x10@106;3170:3087x5+8x3@18;3173:3087x4+8@18;3176:3087x4@18;3179:3087x4+8x4+85@16;3125:3087x8+22x2@18/i;3128:22x3+170x6+3087x10@106/i;3131:3087x6@18;3134:3087x16@106;3137:8+3087x3@18;3140:3087x6+8@18;3143:154x4+3087x15+149@106;3152:3087x5+225x2@106;3149:3087x6+206@18;4122:3087x6@106;3155:3087x8@18;3158:3087x10;2810:2860x14@106;2811:2860x15+225x5@106;2817:2860x20+149x10@106;2825:2860x5+8x3@18;2818:2860x4+8@18;2812:2860x4@18;2813:2860x4+8x4+85@16;2814:2860x8+22x2@18/i;2809:22x3+170x6+2860x10@106/i;2815:2860x6@18;2816:2860x16@106;2819:8+2860x3@18;2820:2860x6+8@18;2821:154x4+2860x15+149@106;2823:2860x5+225x2@106;2855:2860x6+206@18;4121:2860x6@106;2824:2860x8@18;2826:2860x10;3895:3234x35@106;3897:3234x40+225x5@106;3917:3234x50+149x10@106;3893:3234x10+8x3@18;3890:3234x8+8@18;3889:3234x10@18;3894:3234x10+8x4+85@16;3884:3234x20+22x2@18/i;3898:22x3+3234x25@106/i;3888:3234x15@18;3911:3234x40@106;3892:8+3234x6@18;3891:3234x15+8@18;3915:154x4+3234x40+149@106;3918:3234x12+225x2@106;4124:3234x15@106;3896:3234x15+206@18;3920:3234x20@18;3909:3234x25;4139x10:150x10+2607@18;4140x4:4139@18;4139:4140x4@18;3931:4139x14@106;3932:4139x15+225x5@106;3933:4139x20+149x10@106;3934:4139x16@106;3935:4139x5+8x3@18;3936:4139x4+8@18;3937:4139x4@18;3938:4139x4+8x4+85@16;3939:4139x8+22x2@18/i;3940:4139x10+22x3+170x6@106/i;3941:4139x6@18;3942:8+4139x3@18;3943:4139x6+8@18;3944:4139x15+154x4+149@106;3946:4139x6+206@18;3947:4139x5+225x2@106;3948:4139x8@18;3949:4139x10;4125:4139x6@106;3955:61x2@218;3975:3955x10@499/w;3956x4:3955@18;3955:3956x4@18;3967:3955x6@499/w;3963:3955x4@499/w;3965:3955x8+22x2@499/wi;3974:3955x8@499/w;3972:3955x6+206@499/w;3970:3955x6+8@499/w;3962:3955x4+8@499/w;3969:3955x3+8@499/w;3961:3955x5+8x3@499/w;3959:3955x15+225x5@499/w;3968:3955x16@499/w;3960:3955x20+149x10@499/w;3966:22x3+170x6+3955x10@499/wi;3973:3955x5+225x2@499/w;3971:154x4+3955x15+149@499/w;3958:3955x14@499/w;3964:3955x4+8x4+85@499/w;4126:3955x6@499;4229x10:3x10+3458@412;4233x4:4229@18;4229:4233x4@18;4145:4229x14@412;4146:4229x15+225x5@412;4147:4229x20+149x10@412;4148:4229x16@412;4149:4229x5+8x3@412;4150:4229x4+8@412;4151:4229x4@412;4152:4229x4+8x4+85@412;4153:4229x8+22x2@412/i;4154:4229x10+22x3+170x6@412/i;4155:4229x6@412;4156:8+4229x3@412;4157:4229x6+8@412;4158:4229x15+154x4+149@412;4160:4229x6+206@412;4161:4229x5+225x2@412;4162:4229x8@412;4163:4229x10@412;4165:4229x6@412;4230x10:3x10+3456@412;4234x4:4230@18;4230:4234x4@18;4166:4230x14@412;4167:4230x15+225x5@412;4168:4230x20+149x10@412;4169:4230x16@412;4170:4230x5+8x3@412;4171:4230x4+8@412;4172:4230x4@412;4173:4230x4+8x4+85@412;4174:4230x8+22x2@412/i;4175:4230x10+22x3+170x6@412/i;4176:4230x6@412;4177:8+4230x3@412;4178:4230x6+8@412;4179:4230x15+154x4+149@412;4181:4230x6+206@412;4182:4230x5+225x2@412;4183:4230x8@412;4184:4230x10@412;4186:4230x6@412;4231x10:3x10+3457@412;4235x4:4231@18;4231:4235x4@18;4187:4231x14@412;4188:4231x15+225x5@412;4189:4231x20+149x10@412;4190:4231x16@412;4191:4231x5+8x3@412;4192:4231x4+8@412;4193:4231x4@412;4194:4231x4+8x4+85@412;4195:4231x8+22x2@412/i;4196:4231x10+22x3+170x6@412/i;4197:4231x6@412;4198:8+4231x3@412;4199:4231x6+8@412;4200:4231x15+154x4+149@412;4202:4231x6+206@412;4203:4231x5+225x2@412;4204:4231x8@412;4205:4231x10@412;4207:4231x6@412;4232x10:3x10+3459@412;4236x4:4232@18;4232:4236x4@18;4208:4232x14@412;4209:4232x15+225x5@412;4210:4232x20+149x10@412;4211:4232x16@412;4212:4232x5+8x3@412;4213:4232x4+8@412;4214:4232x4@412;4215:4232x4+8x4+85@412;4216:4232x8+22x2@412/i;4217:4232x10+22x3+170x6@412/i;4218:4232x6@412;4219:8+4232x3@412;4220:4232x6+8@412;4221:4232x15+154x4+149@412;4223:4232x6+206@412;4224:4232x5+225x2@412;4225:4232x8@412;4226:4232x10@412;4228:4232x6@412;4720x2:4051@106;4298:4051x14@106;4299:4051x15+225x5@106;4300:4051x20+149x10@106;4301:4051x16@106;4302:4051x5+8x3@18;4303:4051x4+8@18;4304:4051x4@18;4305:4051x4+8x4+85@16;4267:4051x8+22x2@18/i;4306:4051x10+22x3+170x6@106/i;4307:4051x6@18;4308:8+4051x3@18;4309:4051x6+8@18;4310:4051x15+154x4+149@106;4312:4051x6+206@18;4313:4051x5+225x2@106;4314:4051x8@18;4315:4051x10;4316:4051x6@106;4566:4564x14@106;4567:4564x15+225x5@106;4568:4564x20+149x10@106;4569:4564x16@106;4570:4564x5+8x3@18;4571:4564x4+8@18;4572:4564x4@18;4573:4564x4+8x4+85@16;4574:4564x8+22x2@18/i;4575:4564x10+22x3+170x6@106/i;4576:4564x6@18;4577:8+4564x3@18;4578:4564x6+8@18;4579:4564x15+154x4+149@106;4581:4564x6+206@18;4582:4564x5+225x2@106;4583:4564x8@18;4584:4564x10;4586:4564x6@106;5148:5306x14@106;5149:5306x15+225x5@106;5150:5306x20+149x10@106;5151:5306x16@106;5152:5306x5+8x3@18;5153:5306x4+8@18;5154:5306x4@18;5155:5306x4+8x4+85@16;5156:5306x8+22x2@18/i;5157:5306x10+22x3+170x6@106/i;5158:5306x6@18;5159:8+5306x3@18;5160:5306x6+8@18;5161:5306x15+154x4+149@106;5163:5306x6+206@18;5164:5306x5+225x2@106;5165:5306x8@18;5166:5306x10;5168:5306x6@106;5169:3738x14@106;5170:3738x15+225x5@106;5171:3738x20+149x10@106;5172:3738x16@106;5173:3738x5+8x3@18;5174:3738x4+8@18;5175:3738x4@18;5176:3738x4+8x4+85@16;5177:3738x8+22x2@18/i;5178:3738x10+22x3+170x6@106/i;5179:3738x6@18;5180:8+3738x3@18;5181:3738x6+8@18;5182:3738x15+154x4+149@106;5184:3738x6+206@18;5185:3738x5+225x2@106;5186:3738x8@18;5187:3738x10;5189:3738x6@106;171:9x6@18/w;4710:9x6@18/w;1447x4:9@18;9:1447x4@18;2210x4:619@18;619:2210x4@18;2211x4:620@18;620:2211x4@18;2212x4:621@18;621:2212x4@18;2213x4:911@18;911:2213x4@18;2507x4:2503@18;2503:2507x4@18;2508x4:2504@18;2504:2508x4@18;5217x4:5215@18;5215:5217x4@18;1448x4:704@16;704:1448x4@16;2333x4:22@16;22:2333x4@16;4424x4:22@283;22:4424x4@283;4667x4:4564@18;4564:4667x4@18;3665:48+530x10@283;3666:306+530x10@283;3667:328+530x10@283;3668:625+530x10@283;3669:626+530x10@283;3670:627+530x10@283;3671:680+530x10@283;3672:681+530x10@283;3673:831+530x10@283;3674:838+530x10@283;3675:914+530x10@283;3676:952+530x10@283;3677:1142+530x10@283;3678:1298+530x10@283;3679:1528+530x10@283;3680:1529+530x10@283;3681:1530+530x10@283;3682:1531+530x10@283;3683:1532+530x10@283;3684:2230+530x10@283;3685:2249+530x10@283;3686:2250+530x10@283;3687:2526+530x10@283;3688:2544+530x10@283;3689:2559+530x10@283;3690:2574+530x10@283;3691:2612+530x10@283;3692:2613+530x10@283;3693:2614+530x10@283;3694:2615+530x10@283;3695:2616+530x10@283;3696:2617+530x10@283;3697:2618+530x10@283;3698:2619+530x10@283;3699:2620+530x10@283;3700:2748+530x10@283;3701:2814+530x10@283;3702:3180+530x10@283;3703:3125+530x10@283;3704:3181+530x10@283;3886:3884+530x10@283;3887:3885+530x10@283;3950:3939+530x10@283;3976:3965+530x10@283;4164:4153+530x10@283;4185:4174+530x10@283;4206:4195+530x10@283;4227:4216+530x10@283;4266:4265+530x10@283;4268:4267+530x10@283;4585:4574+530x10@283;4713:4712+530x10@283;5167:5156+530x10@283;5188:5177+530x10@283;5209:5198+530x10@283;2340x50:22+9@16/wi;2492:2340+542@16/p;479x4:3+9@106/w;480x2:9@106/w;3202:9x20+1727x50@106/w;498:9x20@106/w;1989:9x20@106/w;3977:9x16@106/w;2699:9x10@106/w;3270:9x6@106/w;5137:5132@18;5138:5132@18;343:9x9+22@106/wi;359:22x3+170x6+9x10@106/i;352:9x14@106/w;5008:133x12+154x12@17;332:9x12@106/w;2114:9x12+22x3@106/wi;2115:9x12+22x3@106/wi;2116:9x12+22x3@106/wi;2117:9x12+22x3@106/wi;2118:9x12+22x3@106/wi;1706:9x4@106/w;1714:9x8@106/w;1715:9x8@106/w;335:9x8@106/w;2397:9x5+225x2@106;363:9x10+22x2+85@18/wi;5012:5011+8x99;5147:3069+974x99;55:284+75;5298:55+4764+670@18;2289:9x8@18;727:9x20@18;728:9x30@18;729:9x25@18;24:9x7@18;196:9x8@18;39:9x10@18;3278:9x10+150x20@18/w;3283:3278+502x15+520x10@134;733:620x20@18;734:620x30@18;735:620x25@18;2509:2503x20@18;2510:2503x30@18;2511:2503x25@18;2745:2503x7@18;2746:2503x8@18;2747:2503x10@18;2512:2504x20@18;2513:2504x30@18;2514:2504x25@18;2517:2504x7@18;2516:2504x8@18;2515:2504x10@18;656:620x7@18;657:620x8@18;658:620x10@18;730:619x20@18;731:619x30@18;732:619x25@18;653:619x7@18;654:619x8@18;655:619x10@18;924:911x20@18;925:911x30@18;926:911x25@18;921:911x7@18;922:911x8@18;923:911x10@18;736:621x20@18;737:621x30@18;738:621x25@18;659:621x7@18;660:621x8@18;661:621x10@18;1832:1729x200@18;1833:1729x300@18;1834:1729x250@18;2263x4:2260@18;2260:2263x4@18;2264x4:2260@18;2260:2264x4@18;2265:2260x6@18;2228:2260x4@18;2230:2260x8+22x2@18/i;3916:154x4+2260x15+149@106;3912:2260x16@106;3919:2260x5+225x2@106;2849:2260x6+206@18;4117:2260x6@106;2259:2260x8@18;2229:2260x10;2231:2260x15+225x5@106;2237:22x3+170x6+2260x10@106/i;2233:2260x20+149x10@106;2232:2260x14+22x2@106/i;2226:2260x6+8@18;2236:2260x4+8@18;2224:2260x4+8x4@18;2225:8+2260x3@18;2227:2260x5+8x3@18;2235:2260x2@18;2234:2260x2@18;2596:22x3+170x6+9x10@304/i;806:9x4@304;831:9x8+22x2@304/i;819:9x6@304;3914:9x16@304;2833:9x6+206@304;829:9x8@304;2139:9x15+225x5@304;2245:154x4+9x15+149@304;2135:9x20+149x10@304;2126:9x14@304;2145:9x6+8@304;2153:9x4+8@304;2141:9x4+8x4+85@304;2131:8+9x3@304;2149:9x5+8x3@304;2636:9x5+225x2@304;2633:9x10@304;4099:9x6@304;2239:22x3+170x16@302/i;1703:170x4@302;2748:170x8+22x2@302/i;1709:170x6@302;2639:170x16@302;2842:170x6+206@302;1713:170x8@302;1719:170x15+225x5@302;2254:154x4+170x15+149@302;2025:170x20+149x10@302;2075:170x14@302;2037:170x6+8@302;2048:170x4+8@302;2065:170x4+8x4+85@302;2085:8+170x3@302;2097:170x5+8x3@302;2414:170x5+225x2@302;4112:170x6@302;2632:170x10@302;1127:1125@17;1707:1125x4@308;1711:1125x6@308;2844:1125x6+206@308;1717:1125x8@308;2251:1125x10@308;1721:1125x15+225x5@308;2255:154x4+1125x15+149@308;2124:1125x14@308;2249:1125x8+22x2@308/i;2240:22x3+170x6+1125x10@308/i;2023:1125x20+149x10@308;2035:1125x6+8@308;2648:1125x4+8@308;2058:1125x4+8x4+85@308;2095:1125x5+8x3@308;2129:8+1125x3@308;2257:1125@308;2395:1125x16@308;2411:1125x5+225x2@308;4113:1125x6@308;1924:1872x6@18;1925:1872x4@18;1926:1872x8@18;824x25:3x25+75@305;825x4:824@18;824:825x4@18;826:824x4@305;2606:22x3+170x6+824x10@305/i;838:824x8+22x2@305/i;3899:22x3+170x6+824x15@305/i;837:824x6@305;2834:824x6+206@305;830:824x8@305;2029:824x20+149x10@305;2070:824x15+225x5@305;2080:824x14@305;2042:824x6+8@305;2053:824x4+8@305;2063:824x4+8x4+85@305;2090:8+824x3@305;2102:824x5+8x3@305;2384:154x4+824x15+149@305;2394:824x16@305;2410:824x5+225x2@305;2631:824x10@305;4104:824x6@305;765:751@305/q;3756:751@305;2595:22x3+170x6+1101x10@303/i;1143:1101x4@303;1137:1101x6@303;2836:1101x6+206@303;1144:1101x8@303;1142:1101x8+22x2@303/i;2030:1101x20+149x10@303;2069:1101x15+225x5@303;2079:1101x14@303;2041:1101x6+8@303;2052:1101x4+8@303;2062:1101x4+8x4+85@303;2089:8+1101x3@303;2101:1101x5+8x3@303;2385:154x4+1101x15+149@303;2396:1101x16@303;2416:1101x5+225x2@303;4106:1101x6@303;2848:664x6+206@306;2248:664x8@306;2635:664x5+225x2@306;2252:664x10@306;2031:664x20+149x10@306;2247:154x4+664x15+149@306;2068:664x15+225x5@306;2076:664x14@306;681:664x8+22x2@306/i;2594:22x3+170x6+664x10@306/i;2044:664x6@306;3913:664x16@306;2040:664x6+974@306;2049:664x4+974@306;2059:664x4+974x4+85@306;2086:974+664x3@306;2100:664x5+974x3@306;2288:664x4@306;4111:664x6@306;1708:1344x4@307;2649:1344x4+8@307;2655:1344x4+8x4+85@307;1712:1344x6@307;2638:1344x16@307;2845:1344x6+206@307;1718:1344x8@307;2253:1344x10@307;1722:1344x15+225x5@307;2256:154x4+1344x15+149@307;2125:1344x14@307;2250:1344x8+22x2@307/i;2241:22x3+170x6+1344x10@307/i;2024:1344x20+149x10@307;2036:1344x6+8@307;2096:1344x5+8x3@307;2130:8+1344x3@307;2412:1344x5+225x2@307;4114:1344x6@307;894:276x20@18;895:276x30@18;896:276x25@18;881:276x10@18;882:276x15@18;750x4:276@18;276:750x4@18;816:276x6@18;807:276x4@18;2616:276x8+22x2@18/i;2592:22x3+170x6+276x10@106/i;812:276x10;2020:276x20+149x10@106;2066:276x15+225x5@106;2072:276x14@106;2032:276x6+8@18;2045:276x4+8@18;2055:276x4+8x4+85@16;2082:8+276x3@18;2092:276x5+8x3@18;2382:154x4+276x15+149@106;2392:276x16@106;2408:276x5+225x2@106;2854:276x6+206@18;2743:276x8@18;4100:276x6@106;2661:1725x14@106;2669:1725x15+225x5@106;2670:1725x20+149x10@106;2668:1725x5+8x3@18;2603:22x3+170x6+1725x10@106/i;1793:1725x6@18;2637:1725x16@106;1792:1725x4@18;2656:1725x4+8x4+85@16;2619:1725x8+22x2@18/i;2671:154x4+1725x15+149@106;2846:1725x6+206@18;1794:1725x8@18;1795:1725x10;1813:1725x6+8@18;2643:8+1725x3@18;2641:1725x6+8@18;1808:1725x4+8@18;2054:1725x4+8@18;4115:1725x6@106;1812:1725x12+8x4@18;2415:1725x5+225x2@106;1731:1725x20@18;1732:1725x30@18;1733:1725x25@18;2605:22x3+170x6+1729x10@106/i;1815:1729x6@18;1814:1729x4@18;2620:1729x8+22x2@18/i;2847:1729x6+206@18;1816:1729x8@18;1817:1729x10;2028:1729x20+149x10@106;2071:1729x15+225x5@106;2081:1729x14@106;2043:1729x6+8@18;2650:1729x4+8@18;2064:1729x4+8x4+85@16;2091:8+1729x3@18;2103:1729x5+8x3@18;2383:154x4+1729x15+149@106;2393:1729x16@106;2409:1729x5+225x2@106;4116:1729x6@106;763:836x2@218;770x4:763@18;763:770x4@18;2598:22x3+170x6+763x10@301/i;817:763x6@301;2640:763x16@301;809:763x4@301;2617:763x8+22x2@301/i;813:763x10@301;2832:763x6+206@301;828:763x8@301;2246:154x4+763x15+149@301;2022:763x20+149x10@301;2067:763x15+225x5@301;2074:763x14@301;2034:763x6+8@301;2047:763x4+8@301;2057:763x4+8x4+85@301;2084:8+763x3@301;2094:763x5+8x3@301;2634:763x5+225x2@301;4102:763x6@301;762:23@220;769x4:762@18;762:769x4@18;767:762+664@220;3113:3111@220;1126x4:1124@18;1124:1126x4@18;768x4:154@300;154:768x4@300;820:154x6@300;2615:154x8+22x2@300/i;2591:22x3+170x6+154x10@300/i;808:154x4@300;811:154x10@300;2831:154x6+206@300;827:154x8@300;2138:154x20+149x10@300;2140:154x15+225x5@300;2128:154x14@300;2144:154x4+8x4+85@300;2152:154x5+8x3@300;2134:8+154x3@300;2148:154x6+8@300;2381:154x19+149@300;2391:154x16@300;4101:154x6@300;2407:154x5+225x2@300;2618:173x6+174x2+22x2@18/i;2840:173x4+174x2+206@18;4110:173x4+174x2@106;2613:139x8+22x2@18/i;2839:139x6+206@18;4109:139x6@106;2614:134x8+22x2@18/i;2837:134x6+206@18;4107:134x6@106;2612:137x8+22x2@18/i;2838:137x6+206@18;4108:137x6@106;361:362x10+9x5@86/w;225:150x7@86;337:225x3@86;338:225x3@86;339:225x3@86;340:225x3@86;255:195x3@86;247:225x20+255x3@86;248:225x20+255x3@86;249:225x20+255x3@86;3773:225x15+3794x5@86;3774:225x15+3794x5@86;3775:225x15+3794x5@86;240:225x20+254x3@86;241:225x20+254x3@86;4132:225x20+981x3@86;4133:225x20+981x3@86;4134:225x20+981x3@86;4128:225x20+254x3@86;4129:225x20+254x3@86;4130:225x20+254x3@86;4652:225x20+255x3@86;4653:225x20+255x3@86;4654:225x20+255x3@86;5045:1330x10+154x10@86;5046:225x20+1330x10+1050@86;5047:225x20+1330x10+1050@86;5048:133x10+1992x3@86;5049:225x20+1992x3@86;5050:225x20+1992x3@86;5051:225x10+154x10@86;5052:225x20+68x10+1050@86;5053:225x20+68x10+1050@86;5054:170x20+2x10+313@86;5055:225x20+2x15@86;5056:225x20+2x15@86;5057:275x15+75x5@86;5058:225x20+75x5+1037@86;5060:225x20+75x5+1037@86;5061:170x10+530x10@86;5062:225x20+1016@86;5063:225x20+1016@86;5102:225x20@86;5103:225x20@86;5115:225x20@86;5116:225x20@86;262:225x20@86;3266:225x10+173x20+86x5@77;3267:225x10+173x20+86x10@77;3268:225x10+173x20+86x5@77;3266:225x10+173x20+1329x5@77;3267:225x10+173x20+1329x10@77;3268:225x10+173x20+1329x5@77;1282:262+181x10@86;1283:262+180x10@86;1284:262+177x10@86;1285:262+179x10@86;1286:262+178x10@86;1287:262+182x10@86;4256:262+999x10@86;4242:3989+1050@228;4243:3989+1015@228;4244:3989+2874@228;4245:3989+1013@228;4246:3989+1011@228;4247:3989+1010@228;4248:3989+1008@228;4249:3989+1018@228;4250:3989+1016@228;4251:3989+1007@228;4252:3989+1014@228;4253:3989+1012@228;4254:3989+1017@228;4255:3989+1009@228;3306:150x30@86;3293:3306+1007@228;3294:3306+1008@228;3295:3306+1009@228;3296:3306+1010@228;3297:3306+1011@228;3298:3306+1012@228;3299:3306+1013@228;3300:3306+1014@228;3301:3306+1015@228;3302:3306+1016@228;3303:3306+1017@228;3304:3306+1018@228;3308:3306+1050@228;3305:3306+2874@228;3307:3306+1066@228;3366:3306+3334+3309@114;3366:3306+3334+3310@114;3366:3306+3334+3311@114;3366:3306+3334+3312@114;3366:3306+3334+3313@114;3366:3306+3334+3314@114;259:68x5@18;252:259x15@18;253:259x15@18;978:803+981x3@18;979:804+981x3@18;980:805+981x3@18;3365:129x10@18;4075:22x4@16/i;4064:9x12@106/w;4065:9x12+225x3@106/w;4859:4858+313;4860:4858+314;4861:4858+317;4862:4858+2358;4863:4858+315;4864:4858+316;4865:4858+316;4866:4858+318;4867:4858+8x3;4852:27+181;4851:27+180;4853:27+177;4854:27+179;4855:27+178;4856:27+182;4857:27+999;4869:4868x3;3364:129x10+9x4+8x2@18/w;33:3x20+9x4+8x3@18/w;360:3x50@18;2702:3x50@283;2703:3x50@283;2704:3x50@283;2705:3x50@283;2706:3x50@283;2707:3x50@283;2708:3x50@283;2709:3x50@283;2710:3x50@283;2711:3x50@283;2712:3x50@283;2713:3x50@283;2714:3x50@283;2715:3x50@283;2716:3x50@283;2717:3x50@283;2718:3x50@283;2719:3x50@283;2720:3x50@283;2721:3x50@283;2722:3x50@283;2723:3x50@283;2724:3x50@283;2725:3x50@283;2726:3x50@283;2727:3x50@283;2728:3x50@283;2729:3x50@283;2730:3x50@283;2731:3x50@283;2732:3x50@283;2733:3x50@283;2734:3x50@283;2735:3x50@283;2736:3x50@283;2737:3x50@283;444:3x50+261x5@283;3653:3x50+2002x5@283;3651:3x50+2018x5@283;3652:3x50+1998x5@283;3654:3x50+1992x5@283;3655:3x50+2157x5@283;3656:3x50+2006x5@283;3658:3x50+2003x5@283;3659:3x50+2123x5@283;3660:3x50+2205x5@283;3661:3x50+2121x5@283;3662:3x50+3194x5@283;445:3x50+2019x5@283;464:3x50+2015x5@283;3657:3x50+2740x5@283;4342:3x50+4334x5@283;4360:3x50+4359x5@283;4397:3x50+4395x5@283;4466:3x50+4464x5@283;5317:3x50+5212x5@283;5318:3x50+5311x5@283;5319:3x50+5312x5@283;20:12x3@17;3509:20x8+9x4@16/w;3506:20x6+9x3@16/w;3505:20x8+9x3@16/w;3508:20x6@16;3507:20x5@16;3504:20x7@16;739:20x10+181x8@16;89:20x12@16;80:20x20@16;76:20x16@16;15:20x10+85@14,15;106:20x4+8x4+85@16;703:699x3@17;3503:703x8+9x4@16/w;3500:703x6+9x3@16/w;3499:703x8+9x3@16/w;3502:703x6@16;3501:703x5@16;3498:703x7@16;740:703x10+180x8@16;687:703x12@16;688:703x20@16;689:703x16@16;707:703x10+85@14,15;710:703x4+8x4+85@16;22:11x3@17;35:22x5@18;2291:22x8@16/i;1:22x10+9x3@16/w;10:22x8+9x3@16/w;7:22x8+9x3@16/w;4711:22x12+9x3@16/wi;4:22x8@16;6:22x6@16;99:22x7@16;90:22x15@16;81:22x25@16;77:22x20@16;704:700x3@17;716:704x5@18;3497:704x10+9x3@16/w;3494:704x8+9x3@16/w;3493:704x8+9x3@16/w;3496:704x8@16;3495:704x6@16;3492:704x7@16;690:704x15@16;691:704x25@16;692:704x20@16;205:22x2@16/i;5364:3467x10+3031@412;5304:3032+4872+5303@114;1140:22x4@16;1139:704x4@16;2172:9x12+22x8@16/wi;2194:22x18+8x8@16/i;348:22x8@16/i;336:22x14@16/i;358:22x6@16/i;4127:182x6@106;4731:358+1570@16;2841:22x3+206@16/i;345:22x10+9x2@16/wi;85x15:22@16/i;5328:85x2+154x5@16;4422:22@16/i;21:14x4@17;3515:21x10+9x4@16/w;3512:21x8+9x3@16/w;3511:21x8+9x3@16/w;3514:21x8@16;3513:21x6@16;3510:21x7@16;741:21x10+177x8@16;91:21x15@16;82:21x25@16;78:21x20@16;16:21x10+85@14,15;107:21x4+8x4+85@16;705:701x4@17;3491:705x10+9x4@16/w;3488:705x8+9x3@16/w;3487:705x8+9x3@16/w;3490:705x8@16;3489:705x6@16;3486:705x7@16;742:705x10+179x8@16;693:705x15@16;694:705x25@16;695:705x20@16;708:705x10+85@14,15;711:705x4+8x4+85@16;19:13x4@17;3521:19x10+9x4@16/w;3518:19x8+9x3@16/w;3517:19x8+9x3@16/w;3520:19x8@16;3519:19x6@16;3516:19x7@16;743:19x10+178x8@16;92:19x20@16;83:19x30@16;79:19x25@16;17:19x10+85@14,15;264:19x5+178@16;108:19x4+8x4+85@16;105:19+8@18;3117:19x2+3114@18;349:19x5+8x3@18;706:702x4@17;3485:706x10+9x4@16/w;3482:706x8+9x3@16/w;3481:706x8+9x3@16/w;3484:706x8@16;3483:706x6@16;3480:706x7@16;744:706x10+182x8@16;696:706x20@16;697:706x30@16;698:706x25@16;709:706x10+85@14,15;715:706x5+178@16;712:706x4+8x4+85@16;713:706+8@18;3117:706x2+3114@18;714:706x5+8x3@18;355:225x20+19x30@16;355:225x20+706x30@16;57:56x3@17;2293:57x8@16;44:57x8@16;45:57x10@16;46:57x10@16;102:57x15+86x10@16;101:57x25+86x20@16;100:57x20+86x15@16;103:57x12+86x6@16;104:57x10+86x5@16;3279:57x12@16;5107:57x12+180x5@16;1257:880x3@17;2421:1257x8@16;796:1257x8@16;799:1257x10@16;795:1257x10@16;792:1257x15+1329x10@16;793:1257x25+1329x20@16;794:1257x20+1329x15@16;798:1257x12+1329x6@16;797:1257x10+1329x5@16;801:1257x10+1329x5@16;3280:1257x12@16;5107:1257x12+180x5@16;84:85x3+118@16;1236:181x15@16;1237:180x15@16;1238:177x15@16;1239:179x15@16;1240:178x15@16;1241:182x15@16;4257:999x15@16;1522:181x15@16;1523:180x15@16;1524:177x15@16;1525:179x15@16;1526:178x15@16;1527:182x15@16;3643:999x15@16;3648:181x5+3x10@283;3647:180x5+3x10@283;3646:179x5+3x10@283;3645:177x5+3x10@283;3644:178x5+3x10@283;3649:182x5+3x10@283;3650:999x5+3x10@283;117:116x3@17;198:117x15+177x10@16;199:117x15+178x10@16;200:117x15+179x10@16;201:117x15+181x10@16;202:117x15+182x10@16;203:117x15+180x10@16;4258:117x15+999x10@16;3764:198+502x25@134;3765:199+502x25@134;3766:200+502x25@134;3767:201+502x25@134;3768:202+502x25@134;3769:203+502x25@134;4259:4258+502x25@134;204:117x20@16;127:117x20@16;197:98+117x20+75x5@16;123:117x10@16;124:117x20@16;125:117x15@16;4059:3380x12+9x4@16/w;3378x20:3380@16;3379x30:3380@16;3377:3380x15+999x8@16;3374:3380x15@16;3375:3380x25@16;3376:3380x20@16;151:154x40+150x40@18;152:154x60+150x50@18;153:154x50+150x45@18;5074:154x90+150x55@18;190:209x12+331x15+210x3@16;191:331x6+209x9@16;185:331x12+210x3@16;3281:620x8+209x12+210+331x9@16;4913:209x15+210x3+331x12@16;228:331x8@16;229:331x16+209x10@16;230:331x8+210x2@16;2364:2431x14@16;2361:2431x8@16;2362:2431x12@16;2363:2431x10@16;5294:2431x14@16;175:174x3+173@77;119:175x10+55@16;120:175x15@16;121:175x20@16;122:175x20@16;217:175x15@16;219:175x10+164@16;2365:175x17@16;231:175x10@16;232:175x20@16;233:175x15@16;4821:175x15+1991@77;5129:3484+5132x5/h;5129:3520+5132x5/h;273:46+155+190+121@26;273:795+155+190+121@26;675:273+547x20+548x20+549x20@134;674:368+1006x24@134;757:675+674+1570@134;4956:757+3063+3065+2880+1826+3018+65+1123+989+3507@134;389:527+528+521x7+520x7@134;381:364x3@17;372:381x10@16;373:381x10@16;371:381x10@16;374:381x20@16;375:381x15@16;385:381x15@16;776:381x15@16;383:381x10@16;991:381x10@16;435:381x10@16;483:381x8@16;537:381x10@16;1184:1104x3@17;1205:1184x12@16;1206:1184x12@16;1207:1184x12@16;1208:1184x24@16;1209:1184x18@16;1189:1184x18@16;1188:1184x18@16;1190:1184x12@16;1222:1184x12@16;1187:1184x12@16;1185:1184x10@16;1186:1184x12@16;382:365x4@17;377:382x10@134;378:382x10@134;376:382x10@134;379:382x20@134;380:382x15@134;386:382x15@134;777:382x15@134;384:382x10@134;992:382x10@134;436:382x10@134;484:382x8@134;390:382x10@134;525:382x10@16;1191:1105x4@17;1210:1191x12@134;1211:1191x12@134;1212:1191x12@134;1213:1191x24@134;1214:1191x18@134;1196:1191x18@134;1195:1191x18@134;1197:1191x12@134;1223:1191x12@134;1194:1191x12@134;1192:1191x10@134;1193:1191x12@134;1220:1191x12@16;391:366x4@133;401:391x12@134;402:391x12@134;400:391x12@134;403:391x24@134;404:391x18@134;388:391x18@134;778:391x18@134;387:391x12@134;993:391x12@134;481:391x12@134;482:391x12@134;406:391x12@134;524:366x30+221@134;1198:1106x4@133;1215:1198x13@134;1216:1198x13@134;1217:1198x13@134;1218:1198x26@134;1219:1198x20@134;1203:1198x20@134;1202:1198x20@134;1204:1198x13@134;1224:1198x13@134;1201:1198x13@134;1199:1198x13@134;1200:1198x13@134;1221:1106x30+221@134;2551:2607x16@16;2366:2607x24@16;2370:2607x8@16;2371:2607x16@16;2372:2607x12@16;684:1198x10+2161@134;685:1198x20+2161@134;686:1198x16+2161@134;684:391x10+2161@134;685:391x20+2161@134;686:391x16+2161@134;4911:520x8+521x8+2161@134;3788:534+527x2+521x10@134;3787:113+528x2+520x16@134;3779:3795+3783x2+521x12@134;3776:391x10+3783@134;3777:391x20+3783@134;3778:391x16+3783@134;3776:1198x10+3783@134;3777:1198x20+3783@134;3778:1198x16+3783@134;559:1225x12@134;553:1225x12@134;558:1225x12@134;4873:1225x12@134;551:1225x24@134;552:1225x18@134;4896:1225x12@26;4897:1225x12@26;4898:1225x12@26;4899:1225x12@26;4900:1225x24@26;4901:1225x18@26;579:1225x18+547+548+549@134;990:1225x18+547+548+549@134;578:1225x12@134;368:1225x12@134;550:1225x12@134;4790:1225x12@134;4678:1225x12@134;4060:1225x12+197@134;1006:947x5@133;1002:1006x12@134;1001:1006x12@134;1003:1006x12@134;1004:1006x24@134;1005:1006x18@134;1231:1006x18@134;1230:1006x18@134;1232:1006x18@134;1233:1006x18@134;1262:1006x18@134;1234:1006x18@134;1229:1006x12@134;1227:1006x12@134;1226:1006x12@134;1228:1006x12@134;2188:1308+1006x14@134;5296:1006x18+997@134;1316:1006x12+1328@134;1317:1006x24+1328@134;1318:1006x18+1328@134;2199:2218x4+1316@134;2200:2218x8+1317@134;2201:2218x8+1317@134;2202:2218x6+1318@134;1552:1006+183x15@247;1546:1552x12@134;1547:1552x12@134;1548:1552x12@134;1549:1552x24@134;1550:1552x18@134;2176:1552x18@134;3261x2:1006x2+1508@133;2189:3261x12@134;1503:3261x12@134;1504:3261x24@134;1505:3261x18@134;1506:3261x18@134;1507:3261x18@134;1543:3261x8@134;1544:3261x8@134;1545:3261x8@134;3467:3460x4@412;3567x333:3467@412;3568x333:3467@412;4318:3460x25@412;3572:3457x6+3458x6+3459x6+3456x6@412;3458:3456+3457+3459@412;3539:3458x15@412;2763:3458x10+3467x8@412;2764:3458x20+3467x16@412;2765:3458x15+3467x12@412;2786:3458x12+3467x10@412;2784:3458x12+3467x10@412;3522:3458x14+3467x12@412;3473:3458x18@412;3543:3458x18@412;3456:3458+3457+3459@412;3536:3456x15@412;2757:3456x10+3467x8@412;2758:3456x20+3467x16@412;2759:3456x15+3467x12@412;2776:3456x12+3467x10@412;2774:3456x12+3467x10@412;3523:3456x14+3467x12@412;3475:3456x18@412;3540:3456x18@412;3457:3458+3456+3459@412;3537:3457x15@412;2760:3457x10+3467x8@412;2761:3457x20+3467x16@412;2762:3457x15+3467x12@412;2781:3457x12+3467x10@412;2779:3457x12+3467x10@412;3524:3457x14+3467x12@412;3476:3457x18@412;3542:3457x18@412;3459:3458+3456+3457@412;3538:3459x15@412;3381:3459x10+3467x8@412;3382:3459x20+3467x16@412;3383:3459x15+3467x12@412;3466:3459x12+3467x10@412;3464:3459x12+3467x10@412;3525:3459x14+3467x12@412;3474:3459x18@412;3531:3459x18@412;533:98+324+319x5+548x20@134;561:1225x20+520x15+548x25@134;506:22x20+324+547x20@134/i;2535:236+38x2+1225x12+549x20@134;494:508+502x20+521x8+549x15@134;425:507+501x25+520x8+549x10@134;2343:22x15+9x10@16/wi;5125:2343+215@16;5288:5125+4731@16;4468:2343+2218x8@16;4451:2343+1522@16;4452:2343+1523@16;4453:2343+1524@16;4454:2343+1525@16;4455:2343+1526@16;4456:2343+1527@16;4467:2343+3643@16;4745:22x5+9x10+68x10@16/wi;4745:22x5+9x10+1330x10@16/wi;5289:3354+3355+3356@134;2768:3467x40+1006x40+1552x40+3261x40+175x40+117x40@134;5131:4797+4960;495:502x10+526x2+501x10+520x8+549x15@134;493:320x10+575x20+520x15@134;492:320x10+575x20+521x15@134;761:575x20+501x99@134;785:575x20+1516@134;749:575x20+1611@134;786:575x20+1517@134;821:575x20+1518@134;822:575x20+1519@134;1165:575x20+1520@134;1515:575x20+1521@134;1797:575x20+1811@134;1830:575x20+1831@134;823:575x20+3261x10@134;2280:575x20+2218x8@134;1866:575x20+1552x18@134;3468:3458x14+3467x10@412;3469:3456x14+3467x10@412;3470:3457x14+3467x10@412;3471:3459x14+3467x10@412;250:261+126;4398:4373+126;2439:2436+126;2440:2437+126;2441:2438+126;2178:1994+31;2179:1995+31;2180:1996+31;2181:1997+31;2182:1998+31;2183:1999+31;2184:2000+31;2185:2001+31;4327:4334+31;4328:4335+31;4329:4336+31;4330:4337+31;4331:4338+31;4332:4339+31;5133:2208+5132;4846:31+4845;4964:31+4961;4655:31+4068;4656:31+4069;4657:31+4070;2208:170x16@17;2162:2208+2019;2163:2208+2018;3565:2208+3563;2206:2208+2205;2165:2208+2123;2164:2208+2122;2166:2208+2015;2167:2208+2016;2168:2208+2017;5213:2208+5212;5301:2208+5300;5314:2208+5311;5315:2208+5312;5316:2208+5313;2190:2208+2121;2174:2208+2006;2175:2208+2007;2186:2208+2157;2187:2208+2156;2191:2208+2003;4376:2208+4375;2207:2208+2002;4364:2208+4363;2741:2208+2740;4380:2208+4361;4461:2208+4464;4462:2208+4465;4473:2208+4374;4474:2208+4359;4475:2208+4418;4481:2208+4480;4396:2208+4395;4850:2208+4849;4963:2208+2673;4882:2208+4838;4883:2208+4839;4884:2208+4840;4885:2208+4841;4886:2208+4842;4887:2208+4843;4888:2208+4844;4889:2208+4831;4890:2208+4832;4891:2208+4833;4892:2208+4834;4893:2208+4835;4894:2208+4836;4895:2208+4837;4483:2208+4482;4476:2208+4419;4275:4274+126;3072:2891+31;4333:4340+31;3070:2208+2889;3071:2208+2890;3566:2208+3564;3073:2208+2892;3074:2208+2893;3075:2208+2894;3076:2208+2895;4399:2208+4362;3254:2208+3191;3255:2208+3194;3256:2208+3192;3257:2208+3193;1085:1073x2@228;1086:1074x2@228;1087:1075x2@228;1088:1076x2@228;1089:1077x2@228;1090:1078x2@228;1091:1079x2@228;1092:1080x2@228;1093:1081x2@228;1094:1082x2@228;1095:1083x2@228;1096:1084x2@228;1007x2:1115@228;1008x2:1114@228;1009x2:1110@228;1010x2:1112@228;1011x2:1108@228;1012x2:1107@228;1013x2:1116@228;1014x2:1109@228;1015x2:1111@228;1016x2:1118@228;1017x2:1117@228;1018x2:1113@228;1050x2:1119@228;1031:1007+1008+1009@228;1033:1009+1010+1011@228;1035:1013+1014+1015@228;1063:1031x2@228;1064:1033x2@228;1065:1035x2@228;1032:1031+1050@228;1034:1033+1050@228;1036:1035+1050@228;3550:1031+1037@228;3551:1033+1037@228;3552:1035+1037@228;1068:1008+1009+1010@228;1069:1012+1013+1014@228;1070:1016+1017+1018@228;1066:1068+1069+1070@228;1067:1066x2@228;1019:1007+1050@228;1020:1008+1050@228;1021:1009+1050@228;1022:1010+1050@228;1023:1011+1050@228;1024:1012+1050@228;1025:1013+1050@228;1026:1014+1050@228;1027:1015+1050@228;1028:1016+1050@228;1029:1017+1050@228;1030:1018+1050@228;2875:2874+1050@228;1038:1007+1037@228;1039:1008+1037@228;1040:1009+1037@228;1041:1010+1037@228;1042:1011+1037@228;1043:1012+1037@228;1044:1013+1037@228;1045:1014+1037@228;1046:1015+1037@228;1047:1016+1037@228;1048:1017+1037@228;1049:1018+1037@228;2876:2874+1037@228;1051:1007+1037@228;1052:1008+1037@228;1053:1009+1037@228;1054:1010+1037@228;1055:1011+1037@228;1056:1012+1037@228;1057:1013+1037@228;1058:1014+1037@228;1059:1015+1037@228;1060:1016+1037@228;1061:1017+1037@228;1062:1018+1037@228;2877:2874+1037@228;3559:1037+1050@228;3557:1037+1050@228;3558:1037x2@228;3562:3561+3111x10@228;3535:3533+502x20@228;3526:126+3458x10@228;3528:126+3456x10@228;3527:126+3457x10@228;3529:126+3459x10@228;3530:126+3467x5@228;2750:117x20+501x10+520x10@134;394:187+268@114;1860:394+1303@114;1861:1860+950@114;395:17+18+393@114;395:709+18+393@114;3036:3120+3037+3096@114;3121:3102+3099+3119@114;3122:3095+3118+3084@114;3123:395+3036+3121+3122@114;50:170x10+19x8+182x3@17;50:170x10+706x8+182x3@17;3124:3123+50@114;3124:3123+3199@114;5437:3124+4263+4819@114;4000:555+2219@114;4001:555+532@114;3996:2423+976@114;3994:2423+187@114;3995:3994+976@114;3995:3996+187@114;3997:938+1253@114;3998:938+3016@114;4008:88+3109@114;3992:897+3016@114;4006:1321+3015@114;4005:1858+3015@114;3991:555+3015@114;4007:3212+1132@114;3990:3200+2423@114;4002:1321+1322@114;3993:405+3017@114;396:158+193@114;397:156+193@114;1613:397+1612@114;1724:53+215@114;399:53+159@114;1163:987+159@114;983:857+159@114;1863:1724+159@114;3241:3201+3225@114;1250:399+158@114;1251:1163+158@114;1252:983+158@114;3250:1863+158@114;3251:1249+158@114;3252:3241+158@114;1164:399+1163+983@114;5331:1164+158@114;5331:399+1163+983+158@114;5331:1250+1163+983@114;5331:1251+399+983@114;5331:1252+399+1163@114;1249:159+1132@114;857:53+3783@125;987:53+2161@125;405:54+128@114;405:1579+128@114;405:3200+128@114;405:4055+128@114;898:405+212+285@114;1862:898+950@114;5000:1862+908@114;193:173x20@17;3999:193+906@114;4004:193+1323@114;4003:4004+906@114;4003:3999+1323@114;4003:3999+4004@114;4038:906+193@114;907:863+193@114;908:907+906+1323@114;908:4038+863+1323@114;908:4038+907+1323@114;908:4003+907@114;908:4003+863@114;4874:4822+405@114;555:223+189@114;3034:3033+855@114;3035:3034+854@114;897:536+211@114;936:897+935@114;1343:1322+936@114;1864:1845+1167@114;982:111+49@114;1595:982+216@114;2221:2219+1595@114;2220:2219+935@114;860:49+535@114;1865:899+900@114;861:485+497@114;3110:1865+861@114;862:532+554@114;1247:1132+532@114;1578:1132+1290@114;976:953+975@114;984:976+977+963@114;3061:2214+2215+2216+2217@114;5126:3061+4056+5010+4341@114;3721:2373+2375+2374@114;5064:3721+4881@114;5140:5139+75x5@114;5144:5140+4389x5@114;5142:5140+4377x5@114;5141:5140+4354x5@114;5146:5140+5128x5@114;5145:5140+5127x5@114;5143:5140+4378x5@114;901:886+892@114;902:887+885@114;903:889+893@114;904:890+891@114;5354:888+3781@114;1612:901+902+903+904+5354@114;935:490+548x5+549x5+547x5@114;935:491+548x5+549x5+547x5@114;935:489+548x5+549x5+547x5@114;935:2998+548x5+549x5+547x5@114;1301:935+1248@114;1858:1300+1301@114;518:531+502x20+520x15@101;519:531+522x20+521x15@101;1336:531+1332x20+521x15@101;37:38x2@18,15;266:324+323x10+180x5@17;237:236x2@18,15;109:75x5;3625:509+851+850+3612+510@114;3611:3625+3619+2799+530x60@114;3620:849x50+22x10+530x10@16/i;511:3+530;512:26x4+530;3617:171+22x4+530x4@16/i;581:22x10+530x2@16/i;582:22x10+530x2@16/i;583:17+530@16;583:709+530@16;584:16+530@16;584:708+530@16;585:15+530@16;585:707+530@16;3632:542+22x2+530@114/ip;3630:542+22x2+530@114/ip;3626:542+22x2+530@114/ip;3631:542+22x2+530@114/ip;3613:520x5+22+530@134/i;3614:521x5+22+530@134/i;3615:549+22+530@134/i;3726:1344x5+3182+530@134/i;3727:1344x5+3184+530@134/i;3728:1344x5+3185+530@134/i;3729:1344x5+3182+3184+3185+530@134/i;5135:539+2607x2@18;580:167x3+530;5327:167x3+343;540:3x6@283;5383:540+3111x5@283;5384:540+29@283;4390:276x6@283;5066:1124x5@283;5067:3271x5+323@283;5286:29@283;5287:109@283;5320:28@283;5321:110@283;5345:4392x20+530x6+129x10@283;3393:3391+3392@86;3391:3392+3393@86;3392:3391+3393@86;4391:664@283;1290:111+29@114;111:1290+109@114;2193:4142+521x10@18;4142:2193+521x10@18;4355:3x50+540x5@283;4640:181+3@283;4641:180+3@283;4642:177+3@283;4643:179+3@283;4644:178+3@283;4645:182+3@283;4646:999+3@283;565:562+563+564+566+567+568+569+570+571+572+573+574@114;4356:4078+4080+4081+4082+4357+4358+4421+4606+5006+4979+4985+4990@114;4992:1603+1602+4079+4077+1607+4991@114;4237:562+2860x25@18;43:38x6@26;4131:154x30+331x15+86x30@26;4131:154x30+331x15+1329x30@26;4076:154x15+331x8+1329x15@26;4076:154x15+331x8+86x15@26;70:67x30+68x15@26;1331:2886x30+1330x15@26;1133:1125x5+209+1124x5+1134;560:23x20+264@26;560:23x20+715@26;544:38x3+22x5+520x6@134/i;556:68x6+22x5+521x6@134/i;556:1330x6+22x5+521x6@134/i;557:154x30+22x5+520x3+521x3@134/i;5334:544+557+556@134;1844:1725x30+1508x5+1225x10@134;1958:225x20+1508x5+547x5@134;2767:2766x8@134;3601:3458x12+3456x12+3457x12+3459x12@412;5104:5105;5104:5106;5105:5106;71x100:72;72:71x100;72x100:73;73:72x100;73x100:74;74:73x100".split(";");
wiki_Wiki.rxAbsolute = new RegExp("^https?://","");
wiki_Wiki.title = "";
wiki_WikiPage.nameMapLq = new haxe_ds_StringMap();
wiki_state_WikiState.__valid = (function($this) {
	var $r;
	var d = [-5,6,-6,12,4,-4,5,11,-58,3,6,-6,-8,11,0,6,5,-58,-1,9,-4,-3];
	var i = 0;
	var r = "";
	while(i < 22) {
		var r1 = stringCharCode(d[(function($this) {
			var $r;
			i = i + 1;
			$r = i - 1;
			return $r;
		}($this))] + 105);
		r += r1;
	}
	var i = r;
	var o = window;
	var arr;
	var p = i.split("/");
	var k = 0;
	while(true) {
		arr = p[k++];
		if(!(arr != null)) {
			break;
		}
		o = o[arr];
	}
	arr = o;
	var d = [-46,-57,-57,17,-7,4,-58,-5,-5,-57];
	var i1 = 0;
	var r = "";
	while(i1 < 10) {
		var r1 = stringCharCode(d[(function($this) {
			var $r;
			i1 = i1 + 1;
			$r = i1 - 1;
			return $r;
		}($this))] + 104);
		r += r1;
	}
	i = r;
	k = arr.indexOf(i);
	if(k < 0) {
		var d = [-53,-64,-64,10,-10,-3,-3,0,8,-14,-9,5,-10,3,-3,-6,-9,-10,-65,-6,5,-12,-7,-65,-6,0,-64];
		var i1 = 0;
		var r = "";
		while(i1 < 27) {
			var r1 = stringCharCode(d[(function($this) {
				var $r;
				i1 = i1 + 1;
				$r = i1 - 1;
				return $r;
			}($this))] + 111);
			r += r1;
		}
		i = r;
		k = arr.indexOf(i);
	}
	if(k < 0) {
		var d = [-59,-70,-70,-18,-6,-8,-8,-6,-7,-17,-20,-1,-20,-2,-1,-6,-3,-20,-14,-16,-71,-14,-6,-6,-14,-9,-16,-20,-5,-12,-2,-71,-18,-6,-8,-70,-12,-1,-18,-13,-12,-6,-70];
		var i1 = 0;
		var r = "";
		while(i1 < 43) {
			var r1 = stringCharCode(d[(function($this) {
				var $r;
				i1 = i1 + 1;
				$r = i1 - 1;
				return $r;
			}($this))] + 117);
			r += r1;
		}
		i = r;
		k = arr.indexOf(i);
	}
	if(k < 0) {
		var d = "hebe4#";
		var r = "";
		var i1 = 0;
		var c;
		while(i1 < 6) {
			c = HxOverrides.cca(d,i1++);
			r += stringCharCode(c & -16 | (c & 15) + i1 * 6 + 8 & 15);
		}
		i = r;
		k = arr.indexOf(i);
	}
	$r = k < 8;
	return $r;
}(this));
wiki_WikiIcon.NONE = new wiki_WikiIcon("nitems.png",0,0);
wiki_WikiNPC.count = 0;
wiki_WikiNPC.list = [];
wiki_WikiNPC.idMap = new haxe_ds_IntMap();
wiki_WikiNPC.nameMap = new haxe_ds_StringMap();
wiki_WikiNPC.nameMapLq = new haxe_ds_StringMap();
wiki_WikiNPC.nameListLq = [];
wiki_Wiki.main();
})(typeof window != "undefined" ? window : typeof global != "undefined" ? global : typeof self != "undefined" ? self : this);
