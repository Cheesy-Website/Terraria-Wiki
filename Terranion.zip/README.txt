Terranion is a mini-wiki for Terraria.

Although it does not offer Cool Trivia or up to 20 ad banners/affiliate links per page,
it can show you item stats, creature stats, recipes, and various other useful information.

== How to use ==

Open index.html in your web browser of choice.
The tool should work roughly the same as the online version (https://yal.cc/r/terranion/).